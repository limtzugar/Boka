import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { db } from '@/lib/db';
import { getFamily } from '@/lib/family-service';
import { ensureFamilySeeded } from '@/lib/auto-seed';
import {
  ensureDocumentsDir,
  getDocumentFilePath,
  extractText,
  detectFileType,
  isSupportedFileType,
  getMaxUploadSize,
} from '@/lib/document-service';

export const runtime = 'nodejs';
export const maxDuration = 60;

// ─────────────────────────────────────────────────────────
// POST /api/documents/upload
// FormData: { file: Blob, title?: string, tags?: string (JSON array) }
// ─────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file');
    const title = (formData.get('title') as string) || '';
    const tagsStr = (formData.get('tags') as string) || '[]';

    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Brak pliku' }, { status: 400 });
    }

    if (file.size > getMaxUploadSize()) {
      return NextResponse.json({ error: `Plik za duży (max ${getMaxUploadSize() / 1024 / 1024}MB)` }, { status: 413 });
    }

    const fileType = detectFileType(file.name);
    if (!isSupportedFileType(fileType)) {
      return NextResponse.json({ error: `Nieobsługiwany typ pliku: ${fileType}` }, { status: 400 });
    }

    await ensureFamilySeeded();
    const family = await getFamily();
    ensureDocumentsDir();

    // Create DB record first to get ID
    const doc = await db.legalDocument.create({
      data: {
        familyId: family.id,
        title: title.trim() || file.name.replace(/\.[^.]+$/, ''),
        fileName: file.name,
        fileType,
        fileSize: file.size,
        tags: tagsStr,
      },
    });

    // Save file to disk
    const filePath = getDocumentFilePath(doc.id, fileType);
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    fs.writeFileSync(filePath, buffer);

    // Extract text (PDF parse or OCR)
    const extraction = await extractText(filePath, fileType);

    // Update DB with extracted text
    await db.legalDocument.update({
      where: { id: doc.id },
      data: {
        documentText: extraction.text,
        ocrConfidence: extraction.confidence,
        ocrEngine: extraction.engine,
      },
    });

    return NextResponse.json({
      id: doc.id,
      title: doc.title,
      fileName: doc.fileName,
      fileType,
      fileSize: file.size,
      textLength: extraction.text.length,
      ocrEngine: extraction.engine,
      ocrConfidence: extraction.confidence,
      textPreview: extraction.text.slice(0, 500),
    });
  } catch (err) {
    console.error('[/api/documents/upload] error:', err);
    return NextResponse.json(
      { error: 'Błąd uploadu', details: err instanceof Error ? err.message : 'unknown' },
      { status: 500 }
    );
  }
}
