import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeCliCommand, interpretCliOutput } from '@/lib/mcp-service';
import { ensureFamilySeeded } from '@/lib/auto-seed';
import { getFamily } from '@/lib/family-service';

export const runtime = 'nodejs';
export const maxDuration = 60;

// ─────────────────────────────────────────────────────────
// POST /api/mcp/cli
// Body: { command, cwd?, interpret?: boolean, sessionId? }
// ─────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { command, cwd, interpret, sessionId } = body;

    if (!command || typeof command !== 'string') {
      return NextResponse.json({ error: 'Brak komendy' }, { status: 400 });
    }

    await ensureFamilySeeded();
    const family = await getFamily();

    // Execute
    const result = await executeCliCommand(command, {
      cwd: cwd || undefined,
      familyId: family.id,
      sessionId,
    });

    // Resolve session
    let session = sessionId;
    if (!session) {
      const s = await db.cliSession.create({
        data: {
          familyId: family.id,
          name: `CLI ${new Date().toLocaleString('pl-PL')}`,
          cwd: cwd || null,
          shell: process.platform === 'win32' ? 'cmd' : 'bash',
        },
      });
      session = s.id;
    }

    // Log command
    const cmd = await db.cliCommand.create({
      data: {
        sessionId: session,
        command,
        workingDir: cwd || null,
        exitCode: result.exitCode,
        stdout: result.stdout,
        stderr: result.stderr,
        durationMs: result.durationMs,
      },
    });

    // Optional AI interpretation
    let aiInterpretation: string | undefined;
    if (interpret) {
      try {
        aiInterpretation = await interpretCliOutput(command, result);
        await db.cliCommand.update({
          where: { id: cmd.id },
          data: { aiInterpretation },
        });
      } catch (e) {
        console.warn('[/api/mcp/cli] AI interpretation failed:', e);
      }
    }

    return NextResponse.json({
      ok: result.exitCode === 0,
      sessionId: session,
      commandId: cmd.id,
      ...result,
      aiInterpretation,
    });
  } catch (err) {
    console.error('[/api/mcp/cli]', err);
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : 'unknown' },
      { status: 500 },
    );
  }
}

// ─────────────────────────────────────────────────────────
// GET /api/mcp/cli?sessionId= — list commands in session
// ─────────────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  try {
    const sessionId = req.nextUrl.searchParams.get('sessionId');
    if (!sessionId) {
      // List all sessions
      const sessions = await db.cliSession.findMany({
        take: 50,
        orderBy: { updatedAt: 'desc' },
        include: { _count: { select: { commands: true } } },
      });
      return NextResponse.json({ sessions });
    }

    const session = await db.cliSession.findUnique({
      where: { id: sessionId },
      include: { commands: { orderBy: { createdAt: 'asc' }, take: 500 } },
    });
    if (!session) return NextResponse.json({ error: 'Sesja nie znaleziona' }, { status: 404 });
    return NextResponse.json({ session });
  } catch (err) {
    console.error('[/api/mcp/cli GET]', err);
    return NextResponse.json(
      { error: 'Błąd listowania', details: err instanceof Error ? err.message : 'unknown' },
      { status: 500 },
    );
  }
}
