import { NextRequest, NextResponse } from 'next/server';
import { callService, routeNaturalLanguageCommand } from '@/lib/homeassistant-service';

// ═══════════════════════════════════════════════════════════
// BOKA — Home Assistant Service Call API
// POST /api/homeassistant/service
// Body: { familyId, domain, service, data } OR { familyId, message: "włącz światło w salonie" }
// ═══════════════════════════════════════════════════════════

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { familyId, domain, service, data, message } = body;

    if (!familyId) {
      return NextResponse.json({ error: 'familyId required' }, { status: 400 });
    }

    // If natural language message — route it
    if (message && !domain) {
      const routed = await routeNaturalLanguageCommand(familyId, message);
      return NextResponse.json(routed);
    }

    // Otherwise direct service call
    if (!domain || !service) {
      return NextResponse.json({ error: 'domain and service required (or message for NL routing)' }, { status: 400 });
    }

    const result = await callService(domain, service, data ?? {});
    return NextResponse.json(result);
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
