import { NextRequest, NextResponse } from 'next/server';
import { getCachedEntities } from '@/lib/homeassistant-service';

// GET /api/homeassistant/entities?familyId=&domain=

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const familyId = url.searchParams.get('familyId');
    if (!familyId) {
      return NextResponse.json({ error: 'familyId required' }, { status: 400 });
    }
    const domain = url.searchParams.get('domain') ?? undefined;

    const entities = await getCachedEntities(familyId, domain);
    return NextResponse.json({ entities, count: entities.length });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
