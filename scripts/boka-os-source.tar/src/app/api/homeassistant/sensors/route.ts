import { NextRequest, NextResponse } from 'next/server';
import { getSensors } from '@/lib/homeassistant-service';

// GET /api/homeassistant/sensors?familyId=

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const familyId = url.searchParams.get('familyId');
    if (!familyId) {
      return NextResponse.json({ error: 'familyId required' }, { status: 400 });
    }

    const sensors = await getSensors(familyId);
    return NextResponse.json({ sensors, count: sensors.length });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
