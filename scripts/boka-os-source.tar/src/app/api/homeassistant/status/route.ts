import { NextRequest, NextResponse } from 'next/server';
import { getStatus, syncEntities, getCachedEntities, getSensors } from '@/lib/homeassistant-service';

// ═══════════════════════════════════════════════════════════
// BOKA — Home Assistant Status & Sync API
// GET /api/homeassistant/status?familyId= — test connection + version
// POST /api/homeassistant/status?familyId= — sync entities
// GET /api/homeassistant/entities?familyId=&domain= — cached entities
// GET /api/homeassistant/sensors?familyId= — sensors
// ═══════════════════════════════════════════════════════════

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const familyId = url.searchParams.get('familyId');

    // Just test connection
    const status = await getStatus();
    return NextResponse.json(status);
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const familyId = url.searchParams.get('familyId');
    if (!familyId) {
      return NextResponse.json({ error: 'familyId required' }, { status: 400 });
    }

    const result = await syncEntities(familyId);
    return NextResponse.json({ ok: true, ...result });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
