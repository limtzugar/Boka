'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useAppStore, type TabId, type FamilyMember, type Message, type MemoryEntry, type WellbeingEntry } from '@/lib/store';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import { useBokaTTS } from '@/hooks/use-boka-tts';
import { BokaFace, BokaFaceMini, type BokaEmotion, type FaceStyle, EMOTION_LABELS, FACE_STYLE_LABELS, type MemoryGraphNode, type MemoryGraphEdge } from '@/components/boka-face';
import { MemoryGraph } from '@/components/memory-graph';
import { PixelAvatar, getCategoryLabel } from '@/components/pixel-avatar';
import { FileExplorer } from '@/components/file-explorer';
import { FileViewer } from '@/components/file-viewer';
import { DebateTab } from '@/components/debate-tab';
import { DocumentsTab } from '@/components/documents-tab';
import { McpTab } from '@/components/mcp-tab';
import { PrivacyTab } from '@/components/privacy-tab';
import { HomeAssistantTab } from '@/components/homeassistant-tab';
import { VisionTab } from '@/components/vision-tab';
import {
  Mic, MicOff, Volume2, VolumeX, Send, Brain,
  Shield, BookOpen, Coins, Wrench, Users, Clock,
  ChevronRight, AlertTriangle, MessageSquare, Star,
  Baby, User, UserCheck, MemoryStick,
  Sparkles, Activity, Search, Globe, Settings, Server, Key, Cpu, Wifi, Eye, EyeOff, CheckCircle, XCircle, Loader2, Zap, HardDrive, FolderOpen, Play, Square, Download, Check,
  Heart, Sun, CloudRain, Cloud, Smile
} from 'lucide-react';
import { useVAD } from '@/hooks/use-vad';
import { useVision } from '@/hooks/use-vision';
import { useImageGeneration } from '@/hooks/use-image-generation';
import { useProactive } from '@/hooks/use-proactive';
import { useReminders } from '@/hooks/use-reminders';
import { useVoiceEmotion } from '@/hooks/use-voice-emotion';
import { useChatStream } from '@/hooks/use-chat-stream';
import { useSpeakerId } from '@/hooks/use-speaker-id';
import { useWeather } from '@/hooks/use-weather';
import { usePresenceDetection } from '@/hooks/use-presence-detection';
import { Image as ImageIcon, Camera, Ear, Radio, Bell, Palette, UsersRound, Trash2, Plus, Upload, X, CircleDot, Network, List, Beaker, Calendar, FolderTree, FileText, FileCode, File, PanelRight, ChevronDown, Home, Paperclip, Terminal as TerminalIcon, Home as HomeIcon } from 'lucide-react';

// ═══════════════════════════════════════════
// AGENT ICONS MAP
// ═══════════════════════════════════════════
const AGENT_ICONS: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  general: { icon: <Brain size={14} />, color: '#00f5d4', label: 'BOKA' },
  search: { icon: <Globe size={14} />, color: '#60a5fa', label: 'Wyszukiwanie' },
  child_culture: { icon: <Star size={14} />, color: '#ffd93d', label: 'Kultura Dziecięca' },
  education: { icon: <BookOpen size={14} />, color: '#a855f7', label: 'Edukacja' },
  finance: { icon: <Coins size={14} />, color: '#4ade80', label: 'Finanse' },
  legal: { icon: <Shield size={14} />, color: '#60a5fa', label: 'Prawo' },
  mathematics: { icon: <Brain size={14} />, color: '#f472b6', label: 'Matematyka' },
  safety: { icon: <AlertTriangle size={14} />, color: '#ff6b6b', label: 'Bezpieczeństwo' },
};

export default function BokaPage() {
  const {
    familyId, members, activeMemberId, childNearby,
    messages, isStreaming, currentAgentId,
    memoryEntries, activeTab, faceStyle,
    wellbeingLog, lastWellbeingCheckIn,
    setFamily, setActiveMember, toggleChildNearby,
    addMessage, setStreaming, setCurrentAgent,
    setMemoryEntries, setActiveTab, setFaceStyle,
    addWellbeingEntry, setLastWellbeingCheckIn,
    updateLastAssistantMessage,
  } = useAppStore();

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [memoryGrowth, setMemoryGrowth] = useState(0);
  const [bokaEmotion, setBokaEmotion] = useState<BokaEmotion>('neutral');
  const [showWellbeingCheckIn, setShowWellbeingCheckIn] = useState(false);
  const [sessionStart] = useState(() => Date.now());
  const [waveformSize, setWaveformSize] = useState(400);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // ── v0.3.7: File Explorer side panel + File Viewer ──
  const [showFileExplorer, setShowFileExplorer] = useState(false);
  const [openFilePath, setOpenFilePath] = useState<string | null>(null);

  // ── Obsidian Graph: real memory data for face visualization ──
  const [memoryGraphNodes, setMemoryGraphNodes] = useState<MemoryGraphNode[]>([]);
  const [memoryGraphEdges, setMemoryGraphEdges] = useState<MemoryGraphEdge[]>([]);
  const [focusNodeId, setFocusNodeId] = useState<string | undefined>();
  const [focusIntensity, setFocusIntensity] = useState(0);
  const [thinkingTopics, setThinkingTopics] = useState<string[]>([]);

  const { isListening, toggleListening, isSupported: asrSupported, nativeAsrSupported, continuousMode, toggleContinuousMode, setOnSpeechResult, micError } = useSpeechRecognition();
  const { isSpeaking, speak, stop: stopSpeaking, isSupported: ttsSupported, analyserNode, micAnalyserNode, startMic, stopMic, playBurp, playFart, playSneeze, playRandomBodySound, fallbackReason } = useBokaTTS();

  // New AI Features
  const vad = useVAD({ energyThreshold: 0.015, silenceDuration: 1500, minSpeechDuration: 300 });
  const vision = useVision();
  const imageGen = useImageGeneration();
  const proactive = useProactive(activeMemberId);
  const reminders = useReminders(activeMemberId);
  const voiceEmotion = useVoiceEmotion();
  const chatStream = useChatStream();
  const speakerId = useSpeakerId();
  const weather = useWeather(); // Rozprza weather for sneezy days

  const [vadMode, setVadMode] = useState(false); // Always-listening toggle
  const [showImageUpload, setShowImageUpload] = useState(false);

  // ── v0.3.16: drag&drop file attachments in chat ──
  interface ChatAttachment {
    id: string;
    fileName: string;
    fileType: string;
    extractionKind: string | null;
    thumbnailDataUrl: string | null;
    status: 'uploading' | 'ready' | 'error';
    error?: string;
  }
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const attachmentInputRef = useRef<HTMLInputElement>(null);
  const [showImageGen, setShowImageGen] = useState(false);
  const [imageGenPrompt, setImageGenPrompt] = useState('');
  const [proactiveDismissed, setProactiveDismissed] = useState(false);
  const [showRemindersTab, setShowRemindersTab] = useState(false);
  const [newReminderTitle, setNewReminderTitle] = useState('');
  const [newReminderDate, setNewReminderDate] = useState('');
  const [detectedEmotion, setDetectedEmotion] = useState<string | null>(null);
  const [detectedSpeaker, setDetectedSpeaker] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ═══ FEATURE #1: Streaming Mode ═══
  const [streamingMode, setStreamingMode] = useState(true);

  // ═══ FEATURE #4: Image Generation inline ═══
  const [generatedImages, setGeneratedImages] = useState<Record<string, string>>({});

  // ═══ FEATURE #7: Function Calling notifications ═══
  const [messageExpenses, setMessageExpenses] = useState<Record<string, number>>({});
  const [messageCalendarEvents, setMessageCalendarEvents] = useState<Record<string, number>>({});

  // ── Connect speech recognition to sendMessage ──
  useEffect(() => {
    setOnSpeechResult((text, isFinal) => {
      if (isFinal && text.trim()) {
        // Auto-send when speech is finalized
        sendMessage(text.trim());
      } else {
        // Show interim text in input
        setInputText(text);
      }
    });
  }, [setOnSpeechResult]);

  // ── Start/stop mic when listening changes ──
  useEffect(() => {
    if (isListening) {
      startMic();
    } else {
      stopMic();
    }
  }, [isListening, startMic, stopMic]);

  // ── v0.3.4: AHI Wellbeing popup USUNIĘTY na życzenie użytkownika ──
  // (oryginalny useEffect okresowo pokazujący "Jak się dzisiaj czujesz?" usunięty)

  // ── Compute waveform size based on viewport ──
  useEffect(() => {
    const update = () => setWaveformSize(Math.min(window.innerHeight * 0.55, 500));
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  // ── Startup: check memory integrity, then load family ──
  useEffect(() => {
    async function startup() {
      // 1. Check memory integrity
      try {
        const startupRes = await fetch('/api/startup');
        if (startupRes.ok) {
          const startupData = await startupRes.json();
          if (startupData.errors?.length > 0) {
            console.warn('⚠️ BOKA Memory issues:', startupData.errors);
          }
          if (startupData.warnings?.length > 0) {
            console.info('ℹ️ BOKA Memory warnings:', startupData.warnings);
          }
          console.log('🏠 BOKA Memory paths:', startupData.paths);
        }
      } catch (e) {
        console.warn('Startup check failed (non-critical):', e);
      }

      // 2. Load family data
      try {
        const res = await fetch('/api/family');
        if (!res.ok) return;
        const data = await res.json();
        if (data.family && data.members) {
          setFamily(data.family.id, data.members);
          const parent = data.members.find((m: FamilyMember) => m.role === 'parent');
          if (parent) setActiveMember(parent.id);
        }
      } catch (e) {
        console.error('Failed to load family:', e);
      }
    }
    startup();
  }, [setFamily, setActiveMember]);

  // ── Load memory on mount ──
  useEffect(() => {
    loadMemoryEntries();
  }, [setMemoryEntries]);

  async function loadMemoryEntries() {
    try {
      const res = await fetch('/api/memory');
      if (!res.ok) return;
      const data = await res.json();
      if (data.entries) {
        setMemoryEntries(data.entries.map((e: { id: string; memberId?: string; entryType: string; domain?: string; title?: string; content: string; importance: number; tags: string; createdAt: string }) => ({
          ...e,
          tags: JSON.parse(typeof e.tags === 'string' ? e.tags : '[]'),
        })));
      }
    } catch (e) {
      console.error('Failed to load memory:', e);
    }
  }

  // ── Load memory graph data for Obsidian face ──
  async function loadMemoryGraph() {
    try {
      const res = await fetch('/api/memory/graph');
      if (!res.ok) return;
      const data = await res.json();
      if (data.nodes && data.edges) {
        setMemoryGraphNodes(data.nodes);
        setMemoryGraphEdges(data.edges);
      }
    } catch (e) {
      console.error('Failed to load memory graph:', e);
    }
  }

  useEffect(() => {
    loadMemoryGraph();
    // Refresh graph every 30 seconds
    const interval = setInterval(loadMemoryGraph, 30000);
    return () => clearInterval(interval);
  }, []);

  // ── Focus logic: when BOKA talks/thinks about someone, focus on their cluster ──
  useEffect(() => {
    if (activeMemberId && (isLoading || isSpeaking || bokaEmotion === 'thinking' || bokaEmotion === 'talking')) {
      setFocusNodeId(`member:${activeMemberId}`);
      setFocusIntensity(isLoading ? 0.8 : isSpeaking ? 0.5 : 0.3);
      // Extract thinking topics from active member name
      const member = members.find(m => m.id === activeMemberId);
      if (member) {
        setThinkingTopics([member.name]);
      }
    } else {
      // Gradually reduce focus
      const fadeTimer = setTimeout(() => {
        setFocusIntensity(prev => Math.max(0, prev - 0.2));
        if (focusIntensity <= 0.2) {
          setFocusNodeId(undefined);
          setThinkingTopics([]);
        }
      }, 2000);
      return () => clearTimeout(fadeTimer);
    }
  }, [activeMemberId, isLoading, isSpeaking, bokaEmotion, members]);

  // ── Extract thinking topics from last messages ──
  useEffect(() => {
    if (messages.length === 0) return;
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role !== 'user') return;

    // Extract topic hints from user message
    const memberNames = members.map(m => m.name);
    const mentionedMembers = memberNames.filter(name =>
      lastMsg.content.toLowerCase().includes(name.toLowerCase())
    );
    if (mentionedMembers.length > 0) {
      setThinkingTopics(prev => [...new Set([...prev, ...mentionedMembers])]);
    }
  }, [messages, members]);

  // ── Auto-scroll chat ──
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Update BOKA emotion based on state ──
  useEffect(() => {
    if (isSpeaking) {
      setBokaEmotion('talking');
    } else if (isListening) {
      setBokaEmotion('listening');
    } else if (isLoading) {
      setBokaEmotion('thinking');
    } else if (bokaEmotion === 'talking' || bokaEmotion === 'listening' || bokaEmotion === 'greeting') {
      setBokaEmotion('neutral');
    }
  }, [isSpeaking, isListening, isLoading]);

  // ── AHI: Greeting on first visit ──
  useEffect(() => {
    const hasGreeted = sessionStorage.getItem('boka-greeted');
    if (!hasGreeted && messages.length === 0) {
      setBokaEmotion('greeting');
      sessionStorage.setItem('boka-greeted', '1');
      // Reset to neutral after greeting animation
      setTimeout(() => setBokaEmotion('neutral'), 3000);
    }
  }, []);

  // ── Wellbeing check-in handler ──
  const handleWellbeingResponse = useCallback((mood: number) => {
    const entry: WellbeingEntry = {
      id: `wb-${Date.now()}`,
      date: new Date().toISOString(),
      mood,
      note: ['', 'Trudno mi', 'Jest ok', 'Nieźle', 'Dobrze', 'Świetnie!'][mood],
      timestamp: Date.now(),
    };
    addWellbeingEntry(entry);
    setLastWellbeingCheckIn(Date.now());
    setShowWellbeingCheckIn(false);

    // Boka reacts to the mood
    if (mood >= 4) {
      setBokaEmotion('happy');
      sendMessage(mood === 5 ? 'Czuję się świetnie!' : 'Jest mi dobrze.');
    } else if (mood <= 2) {
      setBokaEmotion('neutral');
      sendMessage('Nie mam dzisiaj najlepszego dnia...');
    } else {
      sendMessage('Jest tak średnio...');
    }
    setTimeout(() => setBokaEmotion('neutral'), 2000);
  }, [addWellbeingEntry, setLastWellbeingCheckIn]);

  // ═══ FEATURE #2: VAD Wake Word ═══
  useEffect(() => {
    if (vadMode && vad.isListening) {
      vad.setOnSpeechEnd(async (audioBlob) => {
        // Guard: validate audioBlob before using FileReader
        if (!audioBlob || !(audioBlob instanceof Blob) || audioBlob.size === 0) {
          console.warn('[BOKA VAD] Received invalid/empty audio blob, skipping ASR');
          return;
        }
        try {
          const base64Audio = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = reader.result;
              if (typeof result === 'string' && result.length > 0) {
                resolve(result);
              } else {
                reject(new Error('FileReader returned empty result'));
              }
            };
            reader.onerror = () => reject(new Error('FileReader error'));
            reader.readAsDataURL(audioBlob);
          });

          try {
            const res = await fetch('/api/asr', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audio: base64Audio, format: 'audio/webm' }),
            });
            const data = await res.json();
            if (data.text && data.text.trim()) {
              const lowerText = data.text.toLowerCase().trim();
              const wakeWords = ['hej boka', 'hey boka', 'ej boka'];
              const hasWakeWord = wakeWords.some(w => lowerText.includes(w));
              if (hasWakeWord) {
                // Strip wake word and send the remaining text
                let cleanedText = data.text.trim();
                for (const w of wakeWords) {
                  const regex = new RegExp(`^${w}[\\s,!.?]*`, 'i');
                  cleanedText = cleanedText.replace(regex, '');
                }
                sendMessage(cleanedText.trim() || 'Cześć!');
              }
              // No wake word → ignore in VAD mode (only respond to wake word)
            }
          } catch (e) {
            console.error('VAD ASR error:', e);
          }
          // ═══ FEATURE #6: Voice Emotion ═══
          try {
            const emotionResult = await voiceEmotion.analyzeEmotion(base64Audio);
            if (emotionResult) {
              setDetectedEmotion(emotionResult.emotion);
            }
          } catch (e) {
            console.warn('Voice emotion analysis error:', e);
          }
        } catch (e) {
          console.error('[BOKA VAD] FileReader error:', e);
        }
      });
      vad.setOnSpeechStart(() => {
        setBokaEmotion('listening');
      });
    }
  }, [vadMode, vad.isListening]);

  // Toggle VAD mode
  useEffect(() => {
    if (vadMode) {
      vad.startVAD();
    } else {
      vad.stopVAD();
      if (bokaEmotion === 'listening') setBokaEmotion('neutral');
    }
  }, [vadMode]);

  // ═══ SNEEZE ON RAINY DAYS IN ROZPRZA ═══
  // When it's raining, Boka occasionally sneezes — she's alive!
  useEffect(() => {
    if (!weather.isRaining) return;

    // Schedule random sneezes every 3-8 minutes while it's raining
    const scheduleSneeze = () => {
      const delay = (3 + Math.random() * 5) * 60 * 1000; // 3-8 min
      return setTimeout(() => {
        playSneeze();
        // Briefly change emotion to show Boka sneezed
        setBokaEmotion('surprised');
        setTimeout(() => setBokaEmotion('neutral'), 1500);
      }, delay);
    };

    const timer = scheduleSneeze();

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [weather.isRaining, playSneeze]);

  // ═══ FEATURE #8: Multi-party ═══
  // Auto-switch active member when speaker is identified
  useEffect(() => {
    if (speakerId.currentSpeaker && speakerId.currentSpeaker.memberId && speakerId.currentSpeaker.memberId !== activeMemberId) {
      setActiveMember(speakerId.currentSpeaker.memberId);
    }
  }, [speakerId.currentSpeaker, activeMemberId, setActiveMember]);

  // Start/stop speaker identification with VAD analyser node
  useEffect(() => {
    if (vadMode && vad.analyserNode && speakerId.profileCount > 0) {
      speakerId.startIdentifying(vad.analyserNode);
    } else {
      speakerId.stopIdentifying();
    }
  }, [vadMode, vad.analyserNode, speakerId.profileCount]);

  // ── Proactive: Show Boka's proactive messages ──
  useEffect(() => {
    if (proactive.proactiveMessage && !proactiveDismissed) {
      const msg = proactive.proactiveMessage;
      if (msg.shouldSend && msg.message) {
        // Add as a system-like message from Boka
        addMessage({
          id: `proactive-${Date.now()}`,
          role: 'agent',
          content: `💭 ${msg.message}`,
          agentId: 'general',
          timestamp: new Date(),
        });
        speak(msg.message);
        setProactiveDismissed(true);
        setTimeout(() => setProactiveDismissed(false), 300000); // 5 min cooldown
      }
    }
  }, [proactive.proactiveMessage]);

  // ═══ v0.3.16: Drag & drop file attachments ═══
  const uploadAttachment = async (file: File): Promise<void> => {
    const tempId = `temp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    setPendingAttachments((prev) => [
      ...prev,
      { id: tempId, fileName: file.name, fileType: file.type, extractionKind: null, thumbnailDataUrl: null, status: 'uploading' },
    ]);

    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await fetch('/api/chat/attachments', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);

      setPendingAttachments((prev) =>
        prev.map((a) =>
          a.id === tempId
            ? {
                id: data.id,
                fileName: data.fileName,
                fileType: data.fileType,
                extractionKind: data.extractionKind,
                thumbnailDataUrl: data.thumbnailDataUrl,
                status: 'ready',
              }
            : a,
        ),
      );
    } catch (err) {
      setPendingAttachments((prev) =>
        prev.map((a) =>
          a.id === tempId
            ? { ...a, status: 'error', error: err instanceof Error ? err.message : String(err) }
            : a,
        ),
      );
    }
  };

  const handleFiles = useCallback((files: FileList | File[]) => {
    const arr = Array.from(files);
    arr.forEach(uploadAttachment);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Only set false if leaving the container (not entering a child)
    if (e.currentTarget === e.target) setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  }, [handleFiles]);

  const removeAttachment = (id: string) => {
    setPendingAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  // ── Send message to BOKA ──
  const sendMessage = async (text: string) => {
    // Allow send if there's text OR pending ready attachments
    const readyAttachments = pendingAttachments.filter((a) => a.status === 'ready');
    if ((!text.trim() && readyAttachments.length === 0) || isLoading) return;
    const attachmentIds = readyAttachments.map((a) => a.id);

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text.trim() || (attachmentIds.length > 0 ? `[${attachmentIds.length} plików]` : ''),
      inputMode: isListening ? 'voice' : 'text',
      timestamp: new Date(),
    };
    addMessage(userMsg);
    setInputText('');
    // Clear attachments after send
    if (attachmentIds.length > 0) setPendingAttachments([]);
    setIsLoading(true);
    setStreaming(true);
    setBokaEmotion('thinking');

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          memberId: activeMemberId,
          inputMode: userMsg.inputMode,
          // ═══ FEATURE #6: Voice Emotion context ═══
          voiceEmotion: detectedEmotion || undefined,
          // ═══ v0.3.7: childNearby flag → emoji mode (child) vs no-emoji (adult) ═══
          childNearby,
          // ═══ v0.3.16: attachment IDs from drag&drop ═══
          attachmentIds: attachmentIds.length > 0 ? attachmentIds : undefined,
        }),
      });

      if (!res.ok) {
        const textBody = await res.text().catch(() => '');
        throw new Error(`API error ${res.status}: ${textBody.substring(0, 100)}`);
      }
      const data = await res.json();

      if (data.response) {
        const agentMsg: Message = {
          id: `msg-${Date.now()}-agent`,
          role: 'agent',
          content: data.response,
          agentId: data.agentId || 'general',
          confidence: 0.85,
          timestamp: new Date(),
        };
        addMessage(agentMsg);
        setCurrentAgent(data.agentId || 'general');

        // ═══ FEATURE #4: Image Generation inline ═══
        if (data.generatedImageUrl) {
          setGeneratedImages(prev => ({ ...prev, [agentMsg.id]: data.generatedImageUrl }));
        }
        // ═══ FEATURE #7: Function Calling ═══
        if (data.remindersCreated > 0) {
          setMessageCalendarEvents(prev => ({ ...prev, [agentMsg.id]: data.remindersCreated }));
        }
        if (data.expensesCreated > 0) {
          setMessageExpenses(prev => ({ ...prev, [agentMsg.id]: data.expensesCreated }));
        }
        if (data.calendarEventsCreated > 0) {
          setMessageCalendarEvents(prev => ({ ...prev, [agentMsg.id]: data.calendarEventsCreated }));
        }

        // Set BOKA emotion from response
        if (data.emotion) {
          setBokaEmotion(data.emotion as BokaEmotion);
        }

        // Auto-speak the response
        try {
          speak(data.response);
        } catch (ttsErr) {
          console.warn('TTS failed, trying browser fallback:', ttsErr);
          // Fallback: try browser speech synthesis
          if (typeof window !== 'undefined' && window.speechSynthesis) {
            const utterance = new SpeechSynthesisUtterance(data.response.substring(0, 500));
            utterance.lang = 'pl-PL';
            const voices = window.speechSynthesis.getVoices();
            const plVoice = voices.find(v => v.lang.startsWith('pl'));
            if (plVoice) utterance.voice = plVoice;
            window.speechSynthesis.speak(utterance);
          }
        }

        // ── BĄKI & BEKNIĘCIA: Play sound effects when Boka talks about them ──
        const lowerResp = data.response.toLowerCase();
        if (lowerResp.includes('bąk') || lowerResp.includes('bąki') || lowerResp.includes('pierd') || lowerResp.includes('gaz') || lowerResp.includes('pup')) {
          // Fart sound after a short delay (so it plays after TTS starts)
          setTimeout(() => playFart(), 800);
        } else if (lowerResp.includes('bekn') || lowerResp.includes('błęk') || lowerResp.includes('odbij') || lowerResp.includes('eruct')) {
          // Burp sound
          setTimeout(() => playBurp(), 800);
        } else if (lowerResp.includes('kich') || lowerResp.includes('apsik') || lowerResp.includes('atchoo') || lowerResp.includes('sneeze')) {
          // Sneeze sound — Boka kicha!
          setTimeout(() => playSneeze(), 600);
        } else if (Math.random() < 0.08) {
          // 8% chance of a random body sound after any response — Boka is alive!
          const delay = 1500 + Math.random() * 3000;
          setTimeout(() => playRandomBodySound(), delay);
        }

        // Memory growth indicator
        if (data.memoryUpdates > 0) {
          setMemoryGrowth(data.memoryUpdates);
          setTimeout(() => setMemoryGrowth(0), 3000);
        }

        // Reload memory
        loadMemoryEntries();
      }
    } catch (error) {
      console.error('Chat error:', error);
      addMessage({
        id: `msg-${Date.now()}-error`,
        role: 'system',
        content: 'Błąd połączenia z BOKĄ. Spróbuj ponownie.',
        timestamp: new Date(),
      });
      setBokaEmotion('angry');
      setTimeout(() => setBokaEmotion('neutral'), 3000);
    } finally {
      setIsLoading(false);
      setStreaming(false);
    }
  };

  // ═══ FEATURE #3: Vision ═══
  const handleImageUpload = async (file: File) => {
    // Show immediate feedback that image is being analyzed
    const uploadMsgId = `msg-${Date.now()}`;
    addMessage({
      id: uploadMsgId,
      role: 'user',
      content: `📷 Analizuję zdjęcie: ${file.name}...`,
      inputMode: 'text',
      timestamp: new Date(),
    });
    setBokaEmotion('thinking');

    const result = await vision.analyzeImage(file);
    if (result) {
      // Update the user message with the final description
      addMessage({
        id: `msg-${Date.now()}-vision`,
        role: 'user',
        content: `📷 Zdjęcie: ${file.name}`,
        inputMode: 'text',
        timestamp: new Date(),
      });
      // Send the description to chat with vision context + emotion
      const emotionContext = result.emotion !== 'neutral' ? ` (nastrój: ${result.emotion})` : '';
      sendMessage(`Opisz to zdjęcie: ${result.description}${emotionContext}`);
      setShowImageUpload(false);
    } else {
      // Show error message
      const errorMsg = vision.error || 'Nie udało się przeanalizować zdjęcia';
      addMessage({
        id: `msg-${Date.now()}-error`,
        role: 'system',
        content: `❌ ${errorMsg}`,
        inputMode: 'text',
        timestamp: new Date(),
      });
      setBokaEmotion('neutral');
    }
  };

  // ═══ FEATURE #4: Image Generation panel ═══
  const handleGenerateImage = async () => {
    if (!imageGenPrompt.trim()) return;

    // Show immediate feedback
    const pendingMsgId = `msg-${Date.now()}`;
    addMessage({
      id: pendingMsgId,
      role: 'user',
      content: `🎨 Narysuj: "${imageGenPrompt}"`,
      inputMode: 'text',
      timestamp: new Date(),
    });
    setBokaEmotion('thinking');

    const result = await imageGen.generateImage(imageGenPrompt);
    if (result) {
      const imgMsgId = `msg-${Date.now()}-gen`;
      addMessage({
        id: imgMsgId,
        role: 'agent',
        content: `🎨 Oto mój rysunek: "${imageGenPrompt}"`,
        agentId: 'general',
        timestamp: new Date(),
      });
      // Store image URL for inline rendering
      setGeneratedImages(prev => ({ ...prev, [imgMsgId]: result.imageUrl }));
      setImageGenPrompt('');
      setShowImageGen(false);
      setBokaEmotion('happy');
    } else {
      const errorMsg = imageGen.error || 'Nie udało się narysować obrazka';
      addMessage({
        id: `msg-${Date.now()}-error`,
        role: 'system',
        content: `❌ ${errorMsg}`,
        inputMode: 'text',
        timestamp: new Date(),
      });
      setBokaEmotion('neutral');
    }
  };

  const sendMessageStream = async (text: string) => {
    const readyAttachments = pendingAttachments.filter((a) => a.status === 'ready');
    if ((!text.trim() && readyAttachments.length === 0) || chatStream.isStreaming) return;
    const attachmentIds = readyAttachments.map((a) => a.id);

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text.trim() || (attachmentIds.length > 0 ? `[${attachmentIds.length} plików]` : ''),
      inputMode: isListening ? 'voice' : 'text',
      timestamp: new Date(),
    };
    addMessage(userMsg);
    setInputText('');
    if (attachmentIds.length > 0) setPendingAttachments([]);
    setIsLoading(true);
    setStreaming(true);
    setBokaEmotion('thinking');
    
    // Add placeholder agent message
    const agentMsgId = `msg-${Date.now()}-agent`;
    addMessage({
      id: agentMsgId,
      role: 'agent',
      content: '',
      agentId: 'general',
      timestamp: new Date(),
    });

    let fullText = '';
    
    // ═══ FEATURE #6: Voice Emotion context (streaming) ═══
    // Voice emotion is passed via the inputMode field for now since streamChat doesn't accept extra params
    await chatStream.streamChat(text.trim(), activeMemberId, userMsg.inputMode || 'text', {
      onSentence: (sentence) => {
        fullText += sentence;
        updateLastAssistantMessage(fullText);
        // ═══ FEATURE #1: Streaming TTS ═══
        speak(sentence);
      },
      onEmotion: (emotion) => {
        if (emotion) setBokaEmotion(emotion as BokaEmotion);
      },
      onDone: (finalText, metadata) => {
        updateLastAssistantMessage(finalText);
        if (metadata?.agentId) setCurrentAgent(metadata.agentId);
        if (metadata?.emotion) setBokaEmotion(metadata.emotion as BokaEmotion);
        // ═══ FEATURE #4: Image Generation inline ═══
        if (metadata?.generatedImageUrl) {
          setGeneratedImages(prev => ({ ...prev, [agentMsgId]: metadata.generatedImageUrl! }));
        }
        // ═══ FEATURE #7: Function Calling ═══
        if (metadata?.expensesCreated && metadata.expensesCreated > 0) {
          setMessageExpenses(prev => ({ ...prev, [agentMsgId]: metadata.expensesCreated! }));
        }
        if (metadata?.calendarEventsCreated && metadata.calendarEventsCreated > 0) {
          setMessageCalendarEvents(prev => ({ ...prev, [agentMsgId]: metadata.calendarEventsCreated! }));
        }
        // Reload memory after stream completes
        loadMemoryEntries();
        loadMemoryGraph(); // Refresh graph view
      },
      onError: (error) => {
        updateLastAssistantMessage(`Błąd: ${error}`);
        setBokaEmotion('angry');
      },
    }, { childNearby, attachmentIds: attachmentIds.length > 0 ? attachmentIds : undefined });
    // Reset loading state after stream completes
    setIsLoading(false);
    setStreaming(false);
  };

  const handleCreateReminder = async () => {
    if (!newReminderTitle.trim() || !newReminderDate) return;
    await reminders.createReminder({
      title: newReminderTitle,
      dueDate: newReminderDate,
      category: 'general',
      priority: 'normal',
      memberId: activeMemberId || '',
      familyId: familyId || '',
    });
    setNewReminderTitle('');
    setNewReminderDate('');
  };

  // ═══ FEATURE #1: Streaming Mode toggle ═══
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (streamingMode) {
      sendMessageStream(inputText);
    } else {
      sendMessage(inputText);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (streamingMode) {
        sendMessageStream(inputText);
      } else {
        sendMessage(inputText);
      }
    }
  };

  const activeMember = members.find(m => m.id === activeMemberId);
  const currentAgentInfo = currentAgentId ? AGENT_ICONS[currentAgentId] : AGENT_ICONS.general;

  // ═══════════════════════════════════════════
  // RENDER — Waveform center, Chat right
  // ═══════════════════════════════════════════
  return (
    <div className={`h-screen flex flex-col bg-[#0a0a0f] text-[#e0e0f0] overflow-hidden ${childNearby ? 'child-nearby-mode' : ''}`}>
      {/* ══ HEADER ══ */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-[#2a2a3a] bg-[#0f0f1a] shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 flex items-center justify-center overflow-hidden">
            <BokaFaceMini emotion={bokaEmotion} size={6} faceStyle={faceStyle} />
          </div>
          <h1 className="font-pixel text-xs tracking-wider" style={{ color: '#6ec6e7' }}>BOKA</h1>
          <span className="text-[10px] text-[#6b6b8d] font-mono">{EMOTION_LABELS[bokaEmotion]}</span>
          {memoryGrowth > 0 && (
            <div className="flex items-center gap-1 text-[10px] text-[#ffd93d] font-mono">
              <Sparkles size={10} />
              <span>+{memoryGrowth}</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          {childNearby && (
            <span className="flex items-center gap-1 px-2 py-1 rounded text-[10px] bg-[#4ade80]/20 text-[#4ade80] border border-[#4ade80]/50 font-mono">
              <Baby size={12} /> Dziecko obok
            </span>
          )}
          {ttsSupported && (
            <button
              onClick={isSpeaking ? stopSpeaking : () => {}}
              className={`p-1.5 rounded transition-colors ${isSpeaking ? 'bg-[#00f5d4]/20 text-[#00f5d4]' : 'text-[#6b6b8d]'}`}
              title={isSpeaking ? 'Zatrzymaj mowę' : 'Mowa aktywna'}
            >
              {isSpeaking ? <Volume2 size={14} /> : <VolumeX size={14} />}
            </button>
          )}
          {/* Bell — przypomnienia (przeniesione z sidebara) */}
          <button
            onClick={() => setShowRemindersTab(!showRemindersTab)}
            className={`p-1.5 rounded transition-colors relative ${showRemindersTab ? 'bg-[#ffd93d]/20 text-[#ffd93d]' : 'text-[#6b6b8d] hover:text-[#ffd93d]'}`}
            title="Przypomnienia"
          >
            <Bell size={14} />
            {reminders.reminders.filter(r => !r.isCompleted).length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[14px] h-[14px] px-1 flex items-center justify-center rounded-full bg-[#ffd93d] text-[#0a0a0f] text-[8px] font-bold leading-none">
                {reminders.reminders.filter(r => !r.isCompleted).length}
              </span>
            )}
          </button>
          {activeMember && (
            <span className="text-[10px] text-[#6b6b8d] font-mono flex items-center gap-1">
              <PixelAvatar name={activeMember.name} category={(activeMember.category || 'family') as any} color={activeMember.color || undefined} role={activeMember.role} size={16} showRing={false} />
              {activeMember.name}
            </span>
          )}
        </div>
      </header>

      {/* ══ MAIN LAYOUT: Left nav | Left chat | Center waveform ══ */}
      <div className="flex flex-1 overflow-hidden">

        {/* ── LEFT: Slim nav sidebar ── */}
        <aside className="w-14 border-r border-[#2a2a3a] bg-[#0f0f1a] flex flex-col items-center py-3 gap-1 shrink-0">
          <button
            onClick={() => setActiveTab('chat')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'chat' ? 'bg-[#00f5d4]/15 text-[#00f5d4] border border-[#00f5d4]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Czat"
          >
            <MessageSquare size={16} />
          </button>
          <button
            onClick={() => setActiveTab('memory')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'memory' ? 'bg-[#00f5d4]/15 text-[#00f5d4] border border-[#00f5d4]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Pamięć"
          >
            <MemoryStick size={16} />
          </button>
          <button
            onClick={() => setActiveTab('profiles')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'profiles' ? 'bg-[#00f5d4]/15 text-[#00f5d4] border border-[#00f5d4]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Rodzina"
          >
            <Users size={16} />
          </button>
          <button
            onClick={() => setActiveTab('apps')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'apps' ? 'bg-[#00f5d4]/15 text-[#00f5d4] border border-[#00f5d4]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Moje Apki"
          >
            <Wrench size={16} />
          </button>

          <button
            onClick={() => setActiveTab('insights')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'insights' ? 'bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Umysł BOKA — Rytuały, Podsumowania, Dusza, Sugestie, Wyszukiwanie w pamięci"
          >
            <Sparkles size={16} />
          </button>

          {/* v0.3.8.1 — Tryb Debaty Boki */}
          <button
            onClick={() => setActiveTab('debate')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'debate' ? 'bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Debata BOKI — Boka dzieli się na kilku agentów-personowości i debatuje ze sobą. Ty moderujesz."
          >
            <Users size={16} />
          </button>

          {/* v0.3.15 — Document AI: umowy + dokumenty księgowe/administracyjne */}
          <button
            onClick={() => setActiveTab('documents')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'documents' ? 'bg-[#e7d76e]/15 text-[#e7d76e] border border-[#e7d76e]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Dokumenty — analizuj umowy i generuj dokumenty prawne (rodzinne, budowlane, prawa autorskie)"
          >
            <FileText size={16} />
          </button>

          {/* v0.3.16 — MCP & CLI — serwery MCP + terminal + Higgsfield */}
          <button
            onClick={() => setActiveTab('mcp')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'mcp' ? 'bg-[#6ee7b2]/15 text-[#6ee7b2] border border-[#6ee7b2]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="MCP & CLI — podłącz serwery MCP (Higgsfield, filesystem, BOKA tools) i używaj terminala"
          >
            <TerminalIcon size={16} />
          </button>

          {/* v0.3.17 — Privacy Layer: Audit Log + Forget API + Consent */}
          <button
            onClick={() => setActiveTab('privacy')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'privacy' ? 'bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Prywatność — Dziennik decyzji BOKI ('Dlaczego to zrobiłam?'), Forget API, Zgody domowników"
          >
            <Shield size={16} />
          </button>

          {/* v0.3.17 — Home Assistant: sterowanie domem */}
          <button
            onClick={() => setActiveTab('homeassistant')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'homeassistant' ? 'bg-[#6ee7b2]/15 text-[#6ee7b2] border border-[#6ee7b2]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Home Assistant — steruj światłami, czujnikami, urządzeniami w domu"
          >
            <HomeIcon size={16} />
          </button>

          {/* v0.3.17 — Vision (Moondream): lokalna kamera */}
          <button
            onClick={() => setActiveTab('vision')}
            className={`w-10 h-10 rounded flex items-center justify-center transition-all ${activeTab === 'vision' ? 'bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
            title="Wizja — lokalna kamera + Moondream (opis sceny, proactive triggers)"
          >
            <Eye size={16} />
          </button>

          {/* v0.3.4 — USTAWIENIA BOKI przeniesione do menu bocznego Umysł BOKA (zakładka insights) */}

          <div className="w-8 h-px bg-[#2a2a3a] my-2" />

          {/* Mini agent icons */}
          {Object.entries(AGENT_ICONS).map(([key, agent]) => (
            <button
              key={key}
              className={`w-8 h-8 rounded flex items-center justify-center transition-all ${
                currentAgentId === key
                  ? 'bg-[#1e1e2e] border border-[#00f5d4]/40'
                  : 'hover:bg-[#14141f]'
              }`}
              style={{ color: agent.color }}
              title={agent.label}
            >
              {agent.icon}
            </button>
          ))}

          <div className="flex-1" />

          {/* Memory counter */}
          <div className="text-center">
            <Activity size={12} className="text-[#00f5d4] mx-auto" />
            <div className="text-[8px] text-[#00f5d4] font-mono">{memoryEntries.length}</div>
          </div>

          {/* Child toggle */}
          <button
            onClick={toggleChildNearby}
            className={`w-8 h-8 rounded flex items-center justify-center transition-all ${childNearby ? 'bg-[#4ade80]/10 text-[#4ade80]' : 'text-[#6b6b8d]'}`}
            title={childNearby ? 'Tryb dziecko (emotki włączone)' : 'Tryb dorosły (bez emotików)'}
          >
            <Baby size={14} />
          </button>

          {/* v0.3.7 — File Explorer toggle (Show side bar) */}
          <button
            onClick={() => setShowFileExplorer(v => !v)}
            className={`w-8 h-8 rounded flex items-center justify-center transition-all ${showFileExplorer ? 'bg-[#6ec6e7]/10 text-[#6ec6e7]' : 'text-[#6b6b8d] hover:text-[#6ec6e7]'}`}
            title={showFileExplorer ? 'Ukryj explorator plików' : 'Pokaż explorator plików (drzewko PC)'}
          >
            <PanelRight size={14} />
          </button>
        </aside>

        {/* ── LEFT-CENTER: Chat panel (v0.3.4 — pół okna z lewej) ── */}
        {activeTab === 'chat' && !showRemindersTab && (
          <aside
            className="flex-1 border-r border-[#2a2a3a] bg-[#0f0f1a] flex flex-col min-w-0 relative"
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {/* v0.3.16: Drag & drop overlay */}
            {isDragOver && (
              <div className="absolute inset-0 z-50 bg-[#6ec6e7]/10 border-2 border-dashed border-[#6ec6e7]/60 rounded flex items-center justify-center pointer-events-none">
                <div className="text-center">
                  <Paperclip size={48} className="text-[#6ec6e7] mx-auto mb-2 animate-pulse" />
                  <div className="text-sm font-mono text-[#6ec6e7]">Upuść pliki tutaj</div>
                  <div className="text-[10px] text-[#6b6b8d] font-mono mt-1">obraz · audio · txt · pdf</div>
                </div>
              </div>
            )}
            {/* Chat header */}
            <div className="px-4 py-2 border-b border-[#2a2a3a] flex items-center justify-between">
              <span className="text-xs font-mono text-[#6b6b8d]">Rozmowa</span>
              <div className="flex items-center gap-2">
                {vadMode && speakerId.currentSpeaker && (
                  <span className="text-[10px] text-[#4ade80] font-mono flex items-center gap-1">
                    <UsersRound size={10} />
                    {speakerId.currentSpeaker.memberName} ({Math.round(speakerId.currentSpeaker.confidence * 100)}%)
                  </span>
                )}
                {currentAgentId && AGENT_ICONS[currentAgentId] && (
                  <span className="text-[10px] font-mono flex items-center gap-1" style={{ color: AGENT_ICONS[currentAgentId].color }}>
                    {AGENT_ICONS[currentAgentId].icon}
                    {AGENT_ICONS[currentAgentId].label}
                  </span>
                )}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {/* v0.3.6 — empty-chat welcome + 4 default buttons usunięte na życzenie użytkownika */}
              {messages.length === 0 && (
                <div className="text-center py-16 text-[#3a3a4a]">
                  <div className="text-[10px] font-mono">·</div>
                </div>
              )}

              {messages.map(msg => (
                <div key={msg.id} className={`msg-appear flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[90%] rounded-lg p-2.5 ${
                    msg.role === 'user'
                      ? 'bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#e0e0f0]'
                      : msg.role === 'system'
                      ? 'bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 text-[#ff6b6b]'
                      : 'bg-[#1e1e2e] border border-[#2a2a3a] text-[#e0e0f0]'
                  }`}>
                    {msg.role === 'agent' && msg.agentId && AGENT_ICONS[msg.agentId] && (
                      <div className="flex items-center gap-1 mb-1 text-[9px]" style={{ color: AGENT_ICONS[msg.agentId].color }}>
                        {AGENT_ICONS[msg.agentId].icon}
                        <span>{AGENT_ICONS[msg.agentId].label}</span>
                      </div>
                    )}
                    <div className="text-xs font-mono whitespace-pre-wrap leading-relaxed">
                      {msg.content}
                    </div>
                    {generatedImages[msg.id] && (
                      <div className="mt-2">
                        <img
                          src={generatedImages[msg.id]}
                          alt="Wygenerowany obrazek"
                          className="rounded-lg max-w-full border border-[#2a2a3a]"
                          style={{ maxHeight: '200px' }}
                        />
                      </div>
                    )}
                    {(messageExpenses[msg.id] || messageCalendarEvents[msg.id]) && (
                      <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                        {messageExpenses[msg.id] && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[8px] font-mono bg-[#4ade80]/10 text-[#4ade80] border border-[#4ade80]/20">
                            <Coins size={8} /> {messageExpenses[msg.id]} wydatek
                          </span>
                        )}
                        {messageCalendarEvents[msg.id] && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[8px] font-mono bg-[#ffd93d]/10 text-[#ffd93d] border border-[#ffd93d]/20">
                            <Clock size={8} /> {messageCalendarEvents[msg.id]} wydarzenie
                          </span>
                        )}
                      </div>
                    )}
                    {msg.id.startsWith('proactive-') && (
                      <button
                        onClick={() => setProactiveDismissed(true)}
                        className="mt-1 text-[9px] text-[#6b6b8d] hover:text-[#e0e0f0] font-mono underline"
                      >
                        Zamknij
                      </button>
                    )}
                    <div className="mt-1 text-[9px] text-[#6b6b8d]">
                      {msg.timestamp instanceof Date
                        ? msg.timestamp.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })
                        : new Date(msg.timestamp).toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })
                      }
                    </div>
                  </div>
                </div>
              ))}

              {isStreaming && (
                <div className="flex justify-start">
                  <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-2.5 flex items-center gap-2">
                    <BokaFace emotion="thinking" size={6} analyserNode={analyserNode} isSpeaking={isSpeaking} isListening={isListening} faceStyle={faceStyle} />
                    <span className="text-[10px] text-[#6b6b8d] font-mono">{currentAgentInfo.label} myśli...</span>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Input */}
            <div className="border-t border-[#2a2a3a] p-3">
              {micError && (
                <div className="mb-2 px-3 py-1.5 bg-[#ff6b6b]/10 border border-[#ff6b6b]/20 rounded-lg flex items-center gap-2">
                  <span className="text-[10px] text-[#ff6b6b] font-mono">{micError}</span>
                </div>
              )}
              {showImageGen && (
                <div className="mb-2 p-2 bg-[#a855f7]/5 border border-[#a855f7]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Palette size={12} className="text-[#a855f7]" />
                    <span className="text-[10px] text-[#a855f7] font-mono">Boka narysuje...</span>
                    <button type="button" onClick={() => setShowImageGen(false)} className="ml-auto text-[#6b6b8d] hover:text-[#e0e0f0]"><X size={12} /></button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={imageGenPrompt}
                      onChange={e => setImageGenPrompt(e.target.value)}
                      placeholder="Kot w kosmosie..."
                      className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#a855f7]/50 font-mono"
                      onKeyDown={e => { if (e.key === 'Enter') handleGenerateImage(); }}
                    />
                    <button
                      type="button"
                      onClick={handleGenerateImage}
                      disabled={imageGen.isGenerating || !imageGenPrompt.trim()}
                      className="px-2 py-1 rounded bg-[#a855f7] text-white text-[10px] font-mono disabled:opacity-30"
                    >
                      {imageGen.isGenerating ? '...' : 'Rysuj'}
                    </button>
                  </div>
                </div>
              )}
              {/* v0.3.16: pending attachments preview (drag&drop) */}
              {pendingAttachments.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {pendingAttachments.map((att) => (
                    <div
                      key={att.id}
                      className={`flex items-center gap-2 px-2 py-1 rounded border text-[10px] font-mono ${
                        att.status === 'ready'
                          ? 'bg-[#6ec6e7]/10 border-[#6ec6e7]/30 text-[#6ec6e7]'
                          : att.status === 'error'
                          ? 'bg-[#ff6b6b]/10 border-[#ff6b6b]/30 text-[#ff6b6b]'
                          : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d]'
                      }`}
                    >
                      {att.thumbnailDataUrl ? (
                        <img src={att.thumbnailDataUrl} alt={att.fileName} className="w-6 h-6 rounded object-cover" />
                      ) : att.status === 'uploading' ? (
                        <Loader2 size={12} className="animate-spin" />
                      ) : att.status === 'error' ? (
                        <X size={12} />
                      ) : (
                        <Paperclip size={12} />
                      )}
                      <span className="max-w-[120px] truncate" title={att.fileName}>{att.fileName}</span>
                      {att.extractionKind && att.status === 'ready' && (
                        <span className="text-[8px] opacity-60">[{att.extractionKind}]</span>
                      )}
                      {att.status === 'error' && (
                        <span className="text-[8px]" title={att.error}>błąd</span>
                      )}
                      <button
                        type="button"
                        onClick={() => removeAttachment(att.id)}
                        className="hover:text-[#ff6b6b] ml-1"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <form onSubmit={handleSubmit} className="flex items-center gap-2">
                <div className="relative shrink-0">
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`p-2 rounded-lg transition-all ${
                      isListening
                        ? 'voice-recording bg-[#ff6b6b]/20 text-[#ff6b6b] border border-[#ff6b6b]/50'
                        : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#00f5d4]/30'
                    }`}
                    title={isListening ? 'Zatrzymaj nasłuchiwanie' : 'Kliknij aby mówić'}
                  >
                    {isListening ? <MicOff size={16} /> : <Mic size={16} />}
                  </button>
                  {detectedEmotion && (
                    <span className="absolute -top-1 -right-1 px-1 py-0.5 rounded text-[7px] font-mono font-bold leading-none" style={{
                      backgroundColor: detectedEmotion === 'happy' ? '#4ade80' : detectedEmotion === 'sad' ? '#60a5fa' : detectedEmotion === 'angry' ? '#ff6b6b' : detectedEmotion === 'excited' ? '#ffd93d' : '#6b6b8d',
                      color: '#0a0a0f',
                    }}>
                      {detectedEmotion === 'happy' ? '😊' : detectedEmotion === 'sad' ? '😢' : detectedEmotion === 'angry' ? '😠' : detectedEmotion === 'excited' ? '🤩' : detectedEmotion === 'calm' ? '😌' : '😐'}
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setVadMode(!vadMode)}
                  className={`p-2 rounded-lg transition-all shrink-0 ${
                    vadMode
                      ? 'bg-[#4ade80]/20 text-[#4ade80] border border-[#4ade80]/50'
                      : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#4ade80]/30'
                  }`}
                  title={vadMode ? 'Zawsze nasłuchuję — wyłącz' : 'Włącz nasłuchiwanie (hands-free)'}
                >
                  <Ear size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => setStreamingMode(!streamingMode)}
                  className={`p-2 rounded-lg transition-all shrink-0 ${
                    streamingMode
                      ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50'
                      : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#00f5d4]/30'
                  }`}
                  title={streamingMode ? 'Tryb streaming: WŁĄCZONY' : 'Włącz tryb streaming'}
                >
                  <Radio size={16} />
                </button>
                {nativeAsrSupported && (
                  <button
                    type="button"
                    onClick={toggleContinuousMode}
                    className={`p-2 rounded-lg transition-all shrink-0 ${
                      continuousMode
                        ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50'
                        : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#00f5d4]/30'
                    }`}
                    title={continuousMode ? 'Tryb ciągły: WŁĄCZONY (Boka cały czas słucha)' : 'Włącz tryb ciągłego nasłuchiwania'}
                  >
                    <Activity size={16} />
                  </button>
                )}
                <input
                  type="text"
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={isListening ? (continuousMode ? '🔊 Ciągłe nasłuchiwanie...' : 'Mów...') : 'Napisz do Boki...'}
                  className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-xs text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 rounded-lg bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#a855f7]/30 transition-all shrink-0"
                  title="Prześlij zdjęcie — Boka zobaczy"
                >
                  <Camera size={16} />
                </button>
                {/* v0.3.16: Paperclip — attach any file (image/audio/txt/pdf) */}
                <button
                  type="button"
                  onClick={() => attachmentInputRef.current?.click()}
                  className={`p-2 rounded-lg transition-all shrink-0 ${
                    pendingAttachments.length > 0
                      ? 'bg-[#6ec6e7]/20 text-[#6ec6e7] border border-[#6ec6e7]/50'
                      : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#6ec6e7]/30'
                  }`}
                  title="Załącz plik (obraz, audio, txt, pdf) — lub przeciągnij i upuść"
                >
                  <Paperclip size={16} />
                </button>
                <input
                  ref={attachmentInputRef}
                  type="file"
                  multiple
                  accept="image/*,audio/*,text/*,.txt,.md,.json,.csv,.pdf"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFiles(e.target.files);
                    }
                    e.target.value = '';
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowImageGen(!showImageGen)}
                  className={`p-2 rounded-lg transition-all shrink-0 ${
                    showImageGen
                      ? 'bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50'
                      : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:border-[#a855f7]/30'
                  }`}
                  title="Boka narysuje obrazek"
                >
                  <Palette size={16} />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageUpload(file);
                    e.target.value = '';
                  }}
                />
                <button
                  type="submit"
                  disabled={(!inputText.trim() && pendingAttachments.filter(a => a.status === 'ready').length === 0) || isLoading}
                  className="p-2 rounded-lg bg-[#00f5d4] text-[#0a0a0f] disabled:opacity-30 disabled:cursor-not-allowed hover:bg-[#00dbc4] transition-all shrink-0"
                >
                  <Send size={16} />
                </button>
              </form>
            </div>
          </aside>
        )}

        {/* ── CENTER: Reminders panel ── */}
        {showRemindersTab && (
          <main className="flex-1 overflow-y-auto p-4">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-pixel text-sm" style={{ color: '#6ee7b2' }}>PRZYPOMNIENIA</h2>
                <button onClick={() => setShowRemindersTab(false)} className="text-[#6b6b8d] hover:text-[#e0e0f0]"><X size={16} /></button>
              </div>
              
              {/* New reminder form */}
              <div className="mb-4 p-3 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Plus size={14} className="text-[#00f5d4]" />
                  <span className="text-xs font-mono text-[#e0e0f0]">Nowe przypomnienie</span>
                </div>
                <div className="flex items-center gap-2">
                  <input type="text" value={newReminderTitle} onChange={e => setNewReminderTitle(e.target.value)} placeholder="Co przypomnieć?" className="flex-1 bg-[#14141f] border border-[#2a2a3a] rounded px-2 py-1.5 text-xs text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
                  <input type="datetime-local" value={newReminderDate} onChange={e => setNewReminderDate(e.target.value)} className="bg-[#14141f] border border-[#2a2a3a] rounded px-2 py-1.5 text-xs text-[#e0e0f0] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
                  <button onClick={handleCreateReminder} className="px-3 py-1.5 rounded bg-[#00f5d4] text-[#0a0a0f] text-xs font-mono">Dodaj</button>
                </div>
              </div>
              
              {/* Reminders list */}
              <div className="space-y-2">
                {reminders.isLoading ? (
                  <div className="text-center py-8 text-[#6b6b8d] text-sm font-mono">Ładowanie...</div>
                ) : reminders.reminders.length === 0 ? (
                  <div className="text-center py-8 text-[#6b6b8d] text-sm font-mono">Brak przypomnień</div>
                ) : (
                  reminders.reminders.map(r => (
                    <div key={r.id} className={`p-3 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg flex items-center gap-3 ${r.isCompleted ? 'opacity-50' : ''}`}>
                      <Clock size={14} className="text-[#ffd93d] shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-[#e0e0f0] font-mono">{r.title}</div>
                        <div className="text-[10px] text-[#6b6b8d] font-mono">{new Date(r.dueDate).toLocaleString('pl-PL')}</div>
                      </div>
                      <button onClick={() => reminders.deleteReminder(r.id)} className="text-[#6b6b8d] hover:text-[#ff6b6b] shrink-0"><Trash2 size={14} /></button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </main>
        )}

        {/* ── CENTER: BIG WAVEFORM (the star of the show) ── */}
        {activeTab === 'chat' && !showRemindersTab && (
          <main className="flex-1 flex items-center justify-center relative overflow-hidden">
            {/* Glow background effect */}
            <div className="absolute inset-0 pointer-events-none"
              style={{
                background: `radial-gradient(ellipse 80% 70% at 50% 50%, ${
                  bokaEmotion === 'talking' ? 'rgba(0,245,212,0.10)' :
                  bokaEmotion === 'listening' ? 'rgba(0,245,212,0.06)' :
                  bokaEmotion === 'thinking' ? 'rgba(255,217,61,0.06)' :
                  bokaEmotion === 'happy' || bokaEmotion === 'greeting' ? 'rgba(74,222,128,0.06)' :
                  bokaEmotion === 'angry' ? 'rgba(255,68,68,0.06)' :
                  'rgba(0,245,212,0.03)'
                } 0%, transparent 70%)`
              }}
            />

            <div className="flex flex-col items-center gap-4 relative z-10">
              {/* THE BIG WAVEFORM — dominant central element */}
              <BokaFace
                emotion={bokaEmotion}
                size={waveformSize}
                analyserNode={analyserNode}
                micAnalyserNode={vadMode ? vad.analyserNode : micAnalyserNode}
                isSpeaking={isSpeaking}
                isListening={isListening || vad.isSpeechDetected}
                onClick={() => playRandomBodySound()}
                faceStyle={faceStyle}
                graphNodes={memoryGraphNodes}
                graphEdges={memoryGraphEdges}
                focusNodeId={focusNodeId}
                focusIntensity={focusIntensity}
                thinkingTopics={thinkingTopics}
              />

              {/* Emotion label */}
              <div className="text-center">
                <div
                  className="text-lg font-mono font-bold tracking-widest transition-colors uppercase"
                  style={{
                    color:
                      bokaEmotion === 'talking' ? '#00f5d4' :
                      bokaEmotion === 'listening' ? '#00f5d4' :
                      bokaEmotion === 'greeting' ? '#4ade80' :
                      bokaEmotion === 'thinking' ? '#ffd93d' :
                      bokaEmotion === 'happy' ? '#4ade80' :
                      bokaEmotion === 'angry' ? '#ff4444' :
                      '#6b6b8d'
                  }}
                >
                  {EMOTION_LABELS[bokaEmotion]}
                </div>

                {/* Quick status line */}
                {isSpeaking && (
                  <div className="text-xs text-[#00f5d4]/60 font-mono mt-1 animate-pulse">
                    Boka mówi...
                  </div>
                )}
                {isListening && (
                  <div className="text-xs text-[#ff6b6b]/80 font-mono mt-1 animate-pulse">
                    ● Słucham...
                  </div>
                )}
                {isLoading && !isSpeaking && (
                  <div className="text-xs text-[#ffd93d]/60 font-mono mt-1">
                    Myśli...
                  </div>
                )}
                {/* ═══ FEATURE #2: VAD "Nasłuchuję..." indicator ═══ */}
                {vadMode && vad.isSpeechDetected && (
                  <div className="text-xs text-[#4ade80] font-mono mt-1 animate-pulse">
                    ● Nasłuchuję...
                  </div>
                )}
                {/* ═══ FEATURE #8: Multi-party "Mówi:" indicator ═══ */}
                {vadMode && speakerId.currentSpeaker && (
                  <div className="text-[10px] text-[#4ade80]/80 font-mono mt-1 flex items-center gap-1">
                    <UsersRound size={10} />
                    Mówi: {speakerId.currentSpeaker.memberName}
                  </div>
                )}

                {/* Voice Emotion indicator */}
                {detectedEmotion && (
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="text-[10px] font-mono" style={{ color: detectedEmotion === 'happy' ? '#4ade80' : detectedEmotion === 'sad' ? '#60a5fa' : detectedEmotion === 'angry' ? '#ff6b6b' : detectedEmotion === 'excited' ? '#ffd93d' : '#6b6b8d' }}>
                      Emocja z głosu: {detectedEmotion}
                    </span>
                  </div>
                )}
              </div>

              {/* ══ AHI WELLBEING CHECK-IN — v0.3.4 USUNIĘTY na życzenie użytkownika ══ */}

              {/* ══ PROACTIVE MESSAGE BANNER ══ */}
              {proactive.proactiveMessage?.shouldSend && !proactiveDismissed && (
                <div className="mt-2 p-3 rounded-xl bg-[#1e1e2e]/90 border border-[#ffd93d]/30 backdrop-blur-sm max-w-xs animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-start gap-2">
                    <Sparkles size={14} className="text-[#ffd93d] shrink-0 mt-0.5" />
                    <div>
                      <div className="text-[10px] text-[#ffd93d] font-mono mb-1">Boka pisze:</div>
                      <div className="text-xs text-[#e0e0f0] font-mono">{proactive.proactiveMessage.message}</div>
                    </div>
                    <button onClick={() => setProactiveDismissed(true)} className="text-[#6b6b8d] hover:text-[#e0e0f0] shrink-0"><X size={12} /></button>
                  </div>
                </div>
              )}
            </div>
          </main>
        )}

        {/* ══ v0.3.7: FILE VIEWER (okno z tekstem pliku .txt/.html/.md) ══ */}
        {showFileExplorer && openFilePath && (
          <aside className="w-[28rem] border-l border-[#2a2a3a] bg-[#0f0f1a] flex flex-col shrink-0 min-w-0">
            <FileViewer
              path={openFilePath}
              onClose={() => setOpenFilePath(null)}
            />
          </aside>
        )}

        {/* ══ v0.3.7: FILE EXPLORER (drzewko plików PC, wysuwane z prawej) ══ */}
        {showFileExplorer && (
          <aside className="w-64 border-l border-[#2a2a3a] bg-[#0f0f1a] flex flex-col shrink-0">
            <FileExplorer
              onOpenFile={(p) => setOpenFilePath(p)}
              currentFilePath={openFilePath}
            />
          </aside>
        )}

        {/* v0.3.8.1 — Tryb Debaty Boki (full-screen, own flex layout) */}
        {activeTab === 'debate' && (
          <main className="flex-1 flex overflow-hidden">
            <DebateTab />
          </main>
        )}

        {/* v0.3.15 — Document AI: umowy + dokumenty księgowe/administracyjne */}
        {activeTab === 'documents' && (
          <main className="flex-1 flex overflow-hidden">
            <DocumentsTab />
          </main>
        )}

        {/* v0.3.16 — MCP & CLI — serwery MCP + terminal */}
        {activeTab === 'mcp' && (
          <main className="flex-1 flex overflow-hidden">
            <McpTab />
          </main>
        )}

        {/* v0.3.17 — Privacy Layer: Audit Log + Forget API + Consent */}
        {activeTab === 'privacy' && (
          <main className="flex-1 flex overflow-hidden">
            <PrivacyTab />
          </main>
        )}

        {/* v0.3.17 — Home Assistant: most do fizycznego domu */}
        {activeTab === 'homeassistant' && (
          <main className="flex-1 flex overflow-hidden">
            <HomeAssistantTab />
          </main>
        )}

        {/* v0.3.17 — Vision (Moondream): lokalna kamera + opis sceny */}
        {activeTab === 'vision' && (
          <main className="flex-1 flex overflow-hidden">
            <VisionTab />
          </main>
        )}

        {/* Non-chat tabs in center */}
        {activeTab !== 'chat' && activeTab !== 'debate' && activeTab !== 'documents' && activeTab !== 'mcp' && activeTab !== 'privacy' && activeTab !== 'homeassistant' && activeTab !== 'vision' && (
          <main className="flex-1 overflow-y-auto">
            {activeTab === 'memory' && <MemoryTab entries={memoryEntries} members={members} activeMemberId={activeMemberId} />}
            {activeTab === 'vault' && <VaultTab />}
            {activeTab === 'profiles' && <ProfilesTab members={members} activeMemberId={activeMemberId} setActiveMember={setActiveMember} childNearby={childNearby} toggleChildNearby={toggleChildNearby} />}
            {activeTab === 'apps' && <AppsTab />}
            {activeTab === 'insights' && <InsightsTab />}
            {activeTab === 'settings' && <SettingsTab />}
          </main>
        )}

      </div>

      {/* ══ STATUS BAR ══ */}
      <footer className="flex items-center justify-between px-4 py-1 border-t border-[#2a2a3a] bg-[#0a0a0f] text-[8px] font-pixel text-[#6b6b8d] shrink-0">
        <div className="flex items-center gap-3">
          <span className="text-[#00f5d4]">BOKA</span>
          <span>PAMIĘĆ: {memoryEntries.length}</span>
          {wellbeingLog.length > 0 && (
            <span className="text-[#4ade80]">
              <Heart size={8} className="inline" /> {wellbeingLog.length > 0 ? ['','😢','😐','🙂','😊','🌟'][wellbeingLog[0]?.mood || 0] : ''}
            </span>
          )}
          <span className={childNearby ? 'text-[#4ade80]' : ''}>
            {childNearby ? 'DZIECKO: OBOK' : ''}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span>ASR: {nativeAsrSupported ? 'NATIVE' : asrSupported ? 'BACKEND' : 'BRAK'}</span>
          <span>TTS: {ttsSupported ? 'OK' : 'BRAK'}</span>
          {vadMode && <span className="text-[#4ade80]">VAD</span>}
          {streamingMode && <span className="text-[#00f5d4]">STREAM</span>}
          {fallbackReason && (
            <span className="text-[#ff6b6b] animate-pulse">
              ⚠ Głos przeglądarki ({fallbackReason})
            </span>
          )}
          <span>AHI</span>
        </div>
      </footer>
    </div>
  );
}

// ═══════════════════════════════════════════
// MEMORY TAB
// ═══════════════════════════════════════════
// ═══════════════════════════════════════════
// BOKA INSIGHTS — martwe funkcje wskrzeszone: Rituals / Daily Summary / Soul / Improvements
// ═══════════════════════════════════════════

function BokaInsights() {
  const [section, setSection] = useState<'rituals' | 'summary' | 'soul' | 'improvements'>('rituals');
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-2 flex-wrap">
        <button onClick={() => setSection('rituals')} className={`px-2 py-1 rounded text-xs font-mono ${section === 'rituals' ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
          <Clock size={10} className="inline mr-1" />Rytuały
        </button>
        <button onClick={() => setSection('summary')} className={`px-2 py-1 rounded text-xs font-mono ${section === 'summary' ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
          <BookOpen size={10} className="inline mr-1" />Podsumowanie dnia
        </button>
        <button onClick={() => setSection('soul')} className={`px-2 py-1 rounded text-xs font-mono ${section === 'soul' ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
          <Brain size={10} className="inline mr-1" />Dusza BOKA
        </button>
        <button onClick={() => setSection('improvements')} className={`px-2 py-1 rounded text-xs font-mono ${section === 'improvements' ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
          <Sparkles size={10} className="inline mr-1" />Propozycje BOKA
        </button>
      </div>
      {section === 'rituals' && <RitualsPanel />}
      {section === 'summary' && <DailySummaryPanel />}
      {section === 'soul' && <SoulPanel />}
      {section === 'improvements' && <ImprovementsPanel />}
    </div>
  );
}

function RitualsPanel() {
  const [rituals, setRituals] = useState<any[]>([]);
  const [triggers, setTriggers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState(''); const [type, setType] = useState('daily');
  const [time, setTime] = useState('08:00'); const [prompt, setPrompt] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r1, r2] = await Promise.all([
        fetch('/api/rituals').then(r => r.json()),
        fetch('/api/rituals?check=true').then(r => r.json()),
      ]);
      setRituals(r1.rituals || []);
      setTriggers(r2.triggers || []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    if (!name || !prompt) return;
    await fetch('/api/rituals', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, type, time, prompt, isActive: true }),
    });
    setName(''); setPrompt(''); setShowForm(false); load();
  };

  if (loading) return <div className="text-xs text-[#6b6b8d] p-2">Ładowanie rytuałów...</div>;

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-3">
      {triggers.length > 0 && (
        <div className="mb-3 p-2 bg-[#4ade80]/10 border border-[#4ade80]/30 rounded text-xs">
          <div className="text-[#4ade80] font-bold mb-1">⏰ Rytuały do odpalenia teraz ({triggers.length})</div>
          {triggers.map((t, i) => (
            <div key={i} className="text-[#a0a0c0]">• <b>{t.ritual?.name || t.name}</b>: {t.reason}</div>
          ))}
        </div>
      )}
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-mono text-[#e0e0f0]">Aktywne rytuały ({rituals.length})</h4>
        <button onClick={() => setShowForm(!showForm)} className="text-[10px] px-2 py-0.5 bg-[#00f5d4]/10 text-[#00f5d4] border border-[#00f5d4]/30 rounded">+ Nowy</button>
      </div>
      {showForm && (
        <div className="mb-3 p-2 bg-[#0f0f1a] rounded space-y-1">
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Nazwa" className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0]" />
          <div className="flex gap-1">
            <select value={type} onChange={e => setType(e.target.value)} className="bg-[#1e1e2e] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0]">
              <option value="daily">Codziennie</option><option value="weekly">Tygodniowo</option><option value="monthly">Miesięcznie</option>
            </select>
            <input type="time" value={time} onChange={e => setTime(e.target.value)} className="bg-[#1e1e2e] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0]" />
          </div>
          <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Prompt rytuału" rows={2} className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0]" />
          <button onClick={create} className="w-full py-1 bg-[#4ade80]/15 text-[#4ade80] border border-[#4ade80]/30 rounded text-xs">Utwórz</button>
        </div>
      )}
      <div className="space-y-1">
        {rituals.length === 0 ? (
          <div className="text-[10px] text-[#6b6b8d]">Brak rytuałów. Utwórz pierwszy powyżej.</div>
        ) : rituals.map(r => (
          <div key={r.id} className="p-2 bg-[#0f0f1a] rounded text-xs">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[#e0e0f0]">{r.name}</span>
              <span className="text-[#6b6b8d] text-[10px]">{r.type} · {r.time || '-'}</span>
            </div>
            <div className="text-[10px] text-[#6b6b8d] mt-1 line-clamp-2">{r.prompt}</div>
            {r.lastTriggeredAt && <div className="text-[9px] text-[#4ade80] mt-0.5">Ostatnio: {new Date(r.lastTriggeredAt).toLocaleString()}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

function DailySummaryPanel() {
  const [summaries, setSummaries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetch('/api/daily-summary?recent=7').then(r => r.json());
      setSummaries(data.summaries || []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const generate = async () => {
    setGenerating(true);
    try {
      await fetch('/api/daily-summary', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
      load();
    } finally { setGenerating(false); }
  };

  if (loading) return <div className="text-xs text-[#6b6b8d] p-2">Ładowanie podsumowań...</div>;

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-3">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-mono text-[#e0e0f0]">Ostatnie 7 dni</h4>
        <button onClick={generate} disabled={generating}
          className="text-[10px] px-2 py-0.5 bg-[#fbbf24]/10 text-[#fbbf24] border border-[#fbbf24]/30 rounded disabled:opacity-50">
          {generating ? <Loader2 size={10} className="animate-spin inline" /> : null} Generuj dla dziś
        </button>
      </div>
      <div className="space-y-2">
        {summaries.length === 0 ? (
          <div className="text-[10px] text-[#6b6b8d]">Brak podsumowań. Kliknij „Generuj" aby AI streściło dzisiejszy dzień.</div>
        ) : summaries.map(s => (
          <div key={s.id} className="p-2 bg-[#0f0f1a] rounded">
            <div className="text-[10px] text-[#6b6b8d] font-mono">{new Date(s.date).toLocaleDateString()}</div>
            <div className="text-xs text-[#a0a0c0] mt-1 whitespace-pre-wrap">{s.summary?.slice(0, 400) || '(puste)'}{s.summary?.length > 400 ? '...' : ''}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SoulPanel() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [mood, setMood] = useState('');

  const MOODS = ['happy', 'calm', 'curious', 'playful', 'focused', 'tired', 'concerned', 'excited', 'reflective', 'neutral'];

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetch('/api/soul').then(r => r.json());
      setProfile(data.profile);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const setMoodNow = async () => {
    if (!mood) return;
    await fetch('/api/soul', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mood, reason: 'Ręcznie ustawione przez usera' }),
    });
    setMood('');
    load();
  };

  if (loading) return <div className="text-xs text-[#6b6b8d] p-2">Ładowanie profilu duszy...</div>;
  if (!profile) return <div className="text-xs text-[#6b6b8d] p-2">Brak profilu</div>;

  const traits = profile.traits ? (typeof profile.traits === 'string' ? JSON.parse(profile.traits) : profile.traits) : {};
  const traitEntries = Object.entries(traits);

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-3 space-y-3">
      <div>
        <h4 className="text-xs font-mono text-[#e0e0f0] mb-2">Cechy osobowości ({traitEntries.length})</h4>
        <div className="grid grid-cols-2 gap-2">
          {traitEntries.length === 0 ? (
            <div className="text-[10px] text-[#6b6b8d] col-span-2">Brak cech — profil domyślny</div>
          ) : traitEntries.map(([k, v]: any) => (
            <div key={k} className="bg-[#0f0f1a] p-2 rounded">
              <div className="text-[10px] text-[#6b6b8d] font-mono">{k}</div>
              <div className="flex items-center gap-1">
                <div className="flex-1 h-1 bg-[#2a2a3a] rounded overflow-hidden">
                  <div className="h-full bg-[#00f5d4]" style={{ width: `${(v || 0) * 10}%` }} />
                </div>
                <span className="text-[#00f5d4] text-[10px] font-mono">{(v || 0).toFixed(1)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {profile.catchphrases && (
        <div>
          <h4 className="text-xs font-mono text-[#e0e0f0] mb-1">Catchphrases</h4>
          <div className="text-[10px] text-[#a0a0c0] font-mono bg-[#0f0f1a] p-2 rounded">
            {Array.isArray(profile.catchphrases) ? profile.catchphrases.join(' · ') : String(profile.catchphrases)}
          </div>
        </div>
      )}

      {profile.coreValues && (
        <div>
          <h4 className="text-xs font-mono text-[#e0e0f0] mb-1">Wartości</h4>
          <div className="text-[10px] text-[#a0a0c0] font-mono bg-[#0f0f1a] p-2 rounded">
            {Array.isArray(profile.coreValues) ? profile.coreValues.join(', ') : String(profile.coreValues)}
          </div>
        </div>
      )}

      <div>
        <h4 className="text-xs font-mono text-[#e0e0f0] mb-1">Nastrój (mood)</h4>
        <div className="flex gap-1">
          <select value={mood} onChange={e => setMood(e.target.value)}
            className="bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0]">
            <option value="">Wybierz...</option>
            {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
          <button onClick={setMoodNow} disabled={!mood}
            className="px-3 py-1 bg-[#a855f7]/10 text-[#a855f7] border border-[#a855f7]/30 rounded text-xs disabled:opacity-50">
            Ustaw
          </button>
        </div>
        {profile.currentMood && (
          <div className="text-[10px] text-[#6b6b8d] mt-1">Aktualny: <b className="text-[#a855f7]">{profile.currentMood}</b></div>
        )}
      </div>
    </div>
  );
}

function ImprovementsPanel() {
  const [proposals, setProposals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actioned, setActioned] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetch('/api/improvements?status=pending').then(r => r.json());
      setProposals(data.proposals || []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const act = async (id: string, action: 'approve' | 'reject') => {
    setActioned(id);
    try {
      await fetch(`/api/improvements?id=${id}&action=${action}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      load();
    } finally { setActioned(null); }
  };

  if (loading) return <div className="text-xs text-[#6b6b8d] p-2">Ładowanie propozycji...</div>;

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-3">
      <h4 className="text-xs font-mono text-[#e0e0f0] mb-2">Propozycje oczekujące ({proposals.length})</h4>
      {proposals.length === 0 ? (
        <div className="text-[10px] text-[#6b6b8d]">Brak oczekujących propozycji. BOKA będzie tu sugerować nowe umiejętności i zmiany osobowości gdy wykryje wzorce w rozmowach.</div>
      ) : (
        <div className="space-y-2">
          {proposals.map(p => (
            <div key={p.id} className="p-2 bg-[#0f0f1a] rounded">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono text-[#fbbf24] uppercase">{p.type || p.proposalType}</span>
                <span className="text-[9px] text-[#6b6b8d]">{new Date(p.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="text-xs text-[#a0a0c0]">{p.proposal || p.description || p.title}</div>
              {p.reasoning && <div className="text-[10px] text-[#6b6b8d] mt-1">Powód: {p.reasoning}</div>}
              <div className="flex gap-1 mt-2">
                <button onClick={() => act(p.id, 'approve')} disabled={actioned === p.id}
                  className="px-2 py-0.5 bg-[#4ade80]/15 text-[#4ade80] border border-[#4ade80]/30 rounded text-[10px] disabled:opacity-50">
                  ✓ Akceptuj
                </button>
                <button onClick={() => act(p.id, 'reject')} disabled={actioned === p.id}
                  className="px-2 py-0.5 bg-[#ff6b6b]/15 text-[#ff6b6b] border border-[#ff6b6b]/30 rounded text-[10px] disabled:opacity-50">
                  ✗ Odrzuć
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// INSIGHTS TAB — pełny „Umysł BOKA": rytuały + podsumowania
// dnia + dusza + sugestie self-improvement + zaawansowane
// wyszukiwanie w pamięci. Wszystkie 5 endpointów podpięte.
// ═══════════════════════════════════════════════════════════
function InsightsTab() {
  const [section, setSection] = useState<'rituals' | 'summary' | 'soul' | 'improvements' | 'search' | 'vector' | 'mem0' | 'ingestion' | 'graphrag' | 'deepagents' | 'autogen' | 'guardrails' | 'crew' | 'sandbox' | 'presence' | 'reflection' | 'settings'>('rituals');

  const TABS: { key: typeof section; label: string; icon: React.ReactNode; color: string }[] = [
    { key: 'rituals', label: 'Rytuały', icon: <Clock size={14} />, color: '#00f5d4' },
    { key: 'summary', label: 'Podsumowanie', icon: <BookOpen size={14} />, color: '#00f5d4' },
    { key: 'soul', label: 'Dusza BOKA', icon: <Brain size={14} />, color: '#00f5d4' },
    { key: 'improvements', label: 'Propozycje', icon: <Sparkles size={14} />, color: '#00f5d4' },
    { key: 'search', label: 'Memory Search', icon: <Search size={14} />, color: '#a855f7' },
    // BOKA OS v0.3 — new modules inspired by 12 OSS frameworks (emojis removed — icons only)
    { key: 'vector', label: 'Wektory (Qdrant)', icon: <Network size={14} />, color: '#fbbf24' },
    { key: 'mem0', label: 'Mem0 (ADD/UPD/DEL)', icon: <Brain size={14} />, color: '#fbbf24' },
    { key: 'ingestion', label: 'Ingestion (LlamaIndex)', icon: <Upload size={14} />, color: '#fbbf24' },
    { key: 'graphrag', label: 'GraphRAG', icon: <Network size={14} />, color: '#fbbf24' },
    { key: 'deepagents', label: 'Plany (DeepAgents)', icon: <List size={14} />, color: '#4ade80' },
    { key: 'autogen', label: 'Multi-Agent (AutoGen)', icon: <MessageSquare size={14} />, color: '#4ade80' },
    { key: 'guardrails', label: 'Guardrails', icon: <Shield size={14} />, color: '#4ade80' },
    { key: 'crew', label: 'Crew (CrewAI)', icon: <Users size={14} />, color: '#60a5fa' },
    { key: 'sandbox', label: 'Sandbox (OpenHands)', icon: <Wrench size={14} />, color: '#60a5fa' },
    { key: 'presence', label: 'Presence (Isaac)', icon: <Eye size={14} />, color: '#60a5fa' },
    { key: 'reflection', label: 'Refleksja (Cron)', icon: <Calendar size={14} />, color: '#f472b6' },
    // v0.3.4 — USTAWIENIA BOKI przeniesione do menu bocznego Umysł BOKA
    { key: 'settings', label: 'Ustawienia Boki', icon: <Settings size={14} />, color: '#00f5d4' },
  ];

  // Grupowanie modułów w sekcje dla lepszej nawigacji w menu bocznym
  const GROUPS: { title: string; color: string; keys: typeof section[] }[] = [
    { title: 'BOKA CORE', color: '#00f5d4', keys: ['rituals', 'summary', 'soul', 'improvements', 'search'] },
    { title: 'PAMIĘĆ (Vector + Graph)', color: '#fbbf24', keys: ['vector', 'mem0', 'ingestion', 'graphrag'] },
    { title: 'AGENCI (Multi-Agent)', color: '#4ade80', keys: ['deepagents', 'autogen', 'guardrails'] },
    { title: 'ZESPÓŁ + SANDBOX', color: '#60a5fa', keys: ['crew', 'sandbox', 'presence'] },
    { title: 'AUTOMATYZACJA', color: '#f472b6', keys: ['reflection'] },
    { title: 'USTAWIENIA BOKI', color: '#00f5d4', keys: ['settings'] },
  ];

  const tabMap = new Map(TABS.map(t => [t.key, t]));

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* ─────────── SIDE MENU ─────────── */}
      <aside className="w-56 shrink-0 border-r border-[#2a2a3a] bg-[#0f0f1a] flex flex-col">
        <div className="p-3 border-b border-[#2a2a3a]">
          <h2 className="font-pixel text-xs" style={{ color: '#6ec6e7' }}>UMYSŁ BOKA</h2>
          <div className="text-[9px] text-[#6b6b8d] font-mono mt-1">v0.3.17 · 21 modułów</div>
        </div>

        <nav className="flex-1 overflow-y-auto py-2">
          {GROUPS.map(group => (
            <div key={group.title} className="mb-2">
              <div
                className="px-3 py-1 text-[9px] font-mono uppercase tracking-wider"
                style={{ color: group.color }}
              >
                {group.title}
              </div>
              {group.keys.map(key => {
                const t = tabMap.get(key);
                if (!t) return null;
                const active = section === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSection(key)}
                    className={`w-full text-left px-3 py-1.5 text-[11px] font-mono transition-all border-l-2 flex items-center gap-2 ${
                      active
                        ? 'bg-[#a855f7]/15 text-[#e0e0f0] border-[#a855f7]'
                        : 'text-[#6b6b8d] border-transparent hover:bg-[#1e1e2e] hover:text-[#e0e0f0]'
                    }`}
                    style={active ? { color: t.color, borderColor: t.color, backgroundColor: `${t.color}1a` } : undefined}
                  >
                    <span className="w-4 flex justify-center shrink-0" style={{ color: active ? t.color : undefined }}>{t.icon}</span>
                    <span className="truncate">{t.label}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="p-2 border-t border-[#2a2a3a] text-[9px] text-[#6b6b8d] font-mono leading-relaxed">
          Qdrant · Mem0 · LlamaIndex<br />
          PocketFlow · GraphRAG<br />
          Supermemory · DeepAgents<br />
          AutoGen · Agents SDK<br />
          CrewAI · OpenHands · Isaac ROS
        </div>
      </aside>

      {/* ─────────── CONTENT ─────────── */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto">
          {/* Treść */}
          {section === 'rituals' && <RitualsPanel />}
          {section === 'summary' && <DailySummaryPanel />}
          {section === 'soul' && <SoulPanel />}
          {section === 'improvements' && <ImprovementsPanel />}
          {section === 'search' && <MemorySearchPanel />}
          {/* v0.3 new modules */}
          {section === 'vector' && <VectorMemoryPanel />}
          {section === 'mem0' && <Mem0Panel />}
          {section === 'ingestion' && <IngestionPanel />}
          {section === 'graphrag' && <GraphRAGPanel />}
          {section === 'deepagents' && <DeepAgentsPanel />}
          {section === 'autogen' && <AutoGenPanel />}
          {section === 'guardrails' && <GuardrailsPanel />}
          {section === 'crew' && <CrewPanel />}
          {section === 'sandbox' && <SandboxPanel />}
          {section === 'presence' && <PresencePanel />}
          {section === 'reflection' && <WeeklyReflectionPanel />}
          {/* v0.3.4 — USTAWIENIA BOKI przeniesione do menu bocznego */}
          {section === 'settings' && <SettingsTab />}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// V0.3 — 10 new panels (one per framework)
// ═══════════════════════════════════════════════════════════

function VectorMemoryPanel() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (!query.trim()) return;
    setLoading(true); setError(null); setResults(null);
    try {
      const r = await fetch(`/api/vector-memory?q=${encodeURIComponent(query)}`).then(r => r.json());
      if (r.error) throw new Error(r.error);
      setResults(r.results || []);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  };

  const reindex = async () => {
    setLoading(true); setError(null);
    try {
      const r = await fetch('/api/vector-memory?action=reindex', { method: 'POST' }).then(r => r.json());
      alert(`Zindeksowano: ${r.indexed || 0}, pominięto: ${r.skipped || 0}`);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-mono text-[#fbbf24]">⚡ Qdrant-style Vector Search</h3>
        <button onClick={reindex} disabled={loading}
          className="text-[10px] px-2 py-1 bg-[#fbbf24]/10 text-[#fbbf24] border border-[#fbbf24]/30 rounded">
          Reindex missing
        </button>
      </div>
      <p className="text-[10px] text-[#6b6b8d]">Wektorowe wyszukiwanie z filtrami (memberId/domain/emotion). Cosine similarity na embeddings.</p>
      <input
        type="text" value={query} onChange={e => setQuery(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && run()}
        placeholder="Wyszukaj wspomnienia po znaczeniu..."
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] font-mono"
      />
      <button onClick={run} disabled={loading || !query.trim()}
        className="px-4 py-2 bg-[#fbbf24]/15 text-[#fbbf24] border border-[#fbbf24]/30 rounded text-xs font-mono disabled:opacity-50">
        {loading ? <Loader2 size={12} className="animate-spin inline" /> : null} Szukaj wektorowo
      </button>
      {error && <div className="text-xs text-[#ff6b6b] bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 rounded p-2 font-mono">{error}</div>}
      {results !== null && (
        <div className="space-y-2">
          <div className="text-[10px] text-[#6b6b8d] font-mono">{results.length} wyników</div>
          {results.map((r, i) => (
            <div key={i} className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-[#fbbf24] font-mono uppercase">{r.memory?.entryType}</span>
                <span className="text-[10px] text-[#4ade80] font-mono">score: {(r.score || 0).toFixed(3)}</span>
              </div>
              <div className="text-xs text-[#a0a0c0]">{r.memory?.content?.slice(0, 300)}{r.memory?.content?.length > 300 ? '...' : ''}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Mem0Panel() {
  const [content, setContent] = useState('');
  const [memberId, setMemberId] = useState('');
  const [lastResult, setLastResult] = useState<any>(null);
  const [revisions, setRevisions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const ingest = async () => {
    if (!content.trim()) return;
    setLoading(true);
    try {
      const r = await fetch('/api/mem0', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, memberId: memberId || undefined, source: 'manual' }),
      }).then(r => r.json());
      setLastResult(r);
      setContent('');
      loadRevisions();
    } finally { setLoading(false); }
  };

  const loadRevisions = async () => {
    try {
      const r = await fetch('/api/mem0').then(r => r.json());
      setRevisions(r.revisions || []);
    } catch {}
  };

  useEffect(() => { loadRevisions(); }, []);

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#fbbf24]">🧠 Mem0 — ADD/UPDATE/DELETE/NOOP</h3>
      <p className="text-[10px] text-[#6b6b8d]">Algorytm LLM-judge decyduje czy dodać nową pamięć, zaktualizować istniejącą, czy zignorować jako duplikat.</p>
      <textarea value={content} onChange={e => setContent(e.target.value)}
        placeholder="Wpisz nowe wspomnienie do zainwestowania..."
        rows={3}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] font-mono"
      />
      <input type="text" value={memberId} onChange={e => setMemberId(e.target.value)}
        placeholder="memberId (opcjonalne)"
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <button onClick={ingest} disabled={loading || !content.trim()}
        className="px-4 py-2 bg-[#fbbf24]/15 text-[#fbbf24] border border-[#fbbf24]/30 rounded text-xs font-mono disabled:opacity-50">
        {loading ? <Loader2 size={12} className="animate-spin inline" /> : null} Ingest (Mem0)
      </button>
      {lastResult && (
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2 text-xs">
          <div className="font-mono text-[#fbbf24] mb-1">ACTION: {lastResult.action}</div>
          <div className="text-[#a0a0c0]">{lastResult.reason}</div>
          {lastResult.matchedMemoryId && <div className="text-[10px] text-[#6b6b8d] mt-1">matched: {lastResult.matchedMemoryId}</div>}
          {lastResult.similarity !== undefined && <div className="text-[10px] text-[#4ade80] mt-1">similarity: {lastResult.similarity.toFixed(3)}</div>}
        </div>
      )}
      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Ostatnie rewizje ({revisions.length})</div>
        <div className="space-y-1 max-h-60 overflow-y-auto">
          {revisions.slice(0, 10).map((r, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1.5 border border-[#2a2a3a]">
              <span className={`font-mono ${r.action === 'ADD' ? 'text-[#4ade80]' : r.action === 'UPDATE' ? 'text-[#fbbf24]' : r.action === 'DELETE' ? 'text-[#ff6b6b]' : 'text-[#6b6b8d]'}`}>
                {r.action}
              </span>
              <span className="text-[#6b6b8d] ml-2">{new Date(r.createdAt).toLocaleString()}</span>
              <div className="text-[#a0a0c0] mt-0.5">{r.reason}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function IngestionPanel() {
  const [sourceType, setSourceType] = useState<'text' | 'url'>('text');
  const [content, setContent] = useState('');
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const ingest = async () => {
    if (!content.trim()) return;
    setLoading(true);
    try {
      const r = await fetch('/api/ingestion', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceType, sourceUri: content }),
      }).then(r => r.json());
      alert(`Status: ${r.status}\nMemories: ${r.memoriesCreated}\nEntities: ${r.entitiesCreated}`);
      loadJobs();
    } finally { setLoading(false); }
  };

  const loadJobs = async () => {
    try { setJobs((await fetch('/api/ingestion?list=true').then(r => r.json())).jobs || []); } catch {}
  };

  useEffect(() => { loadJobs(); }, []);

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#fbbf24]">📥 LlamaIndex Ingestion Pipeline</h3>
      <p className="text-[10px] text-[#6b6b8d]">Pipeline: LOAD → PARSE → CHUNK → EXTRACT → EMBED → STORE. Auto-entity extraction + Mem0 ingest.</p>
      <select value={sourceType} onChange={e => setSourceType(e.target.value as any)}
        className="bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono">
        <option value="text">Text (raw)</option>
        <option value="url">URL (fetch + parse HTML)</option>
      </select>
      <textarea value={content} onChange={e => setContent(e.target.value)}
        placeholder={sourceType === 'text' ? 'Wklej tekst do ingestji...' : 'https://example.com/article'}
        rows={4}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] font-mono"
      />
      <button onClick={ingest} disabled={loading || !content.trim()}
        className="px-4 py-2 bg-[#fbbf24]/15 text-[#fbbf24] border border-[#fbbf24]/30 rounded text-xs font-mono disabled:opacity-50">
        {loading ? <Loader2 size={12} className="animate-spin inline" /> : null} Run pipeline
      </button>
      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Ostatnie joby ({jobs.length})</div>
        <div className="space-y-1 max-h-60 overflow-y-auto">
          {jobs.slice(0, 10).map((j, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1.5 border border-[#2a2a3a]">
              <span className={`font-mono ${j.status === 'done' ? 'text-[#4ade80]' : j.status === 'error' ? 'text-[#ff6b6b]' : 'text-[#fbbf24]'}`}>
                {j.status}
              </span>
              <span className="text-[#6b6b8d] ml-2">{j.sourceType}</span>
              <span className="text-[#6b6b8d] ml-2">{new Date(j.createdAt).toLocaleString()}</span>
              {j.memoriesCreated > 0 && <span className="text-[#a855f7] ml-2">{j.memoriesCreated} mem</span>}
              {j.entitiesCreated > 0 && <span className="text-[#4ade80] ml-2">{j.entitiesCreated} ent</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GraphRAGPanel() {
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [entities, setEntities] = useState<any[]>([]);
  const [communities, setCommunities] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const rebuild = async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/graphrag?action=rebuild', { method: 'POST' }).then(r => r.json());
      alert(`Entities: ${r.entitiesProcessed}\nCommunities: ${r.communitiesCreated}\nSummarized: ${r.communitiesSummarized}`);
      loadData();
    } finally { setLoading(false); }
  };

  const globalSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/graphrag?action=global&q=${encodeURIComponent(query)}`).then(r => r.json());
      setAnswer(r.answer);
    } finally { setLoading(false); }
  };

  const loadData = async () => {
    try {
      const [e, c] = await Promise.all([
        fetch('/api/graphrag?action=entities').then(r => r.json()),
        fetch('/api/graphrag?action=communities').then(r => r.json()),
      ]);
      setEntities(e.entities || []);
      setCommunities(c.communities || []);
    } catch {}
  };

  useEffect(() => { loadData(); }, []);

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-mono text-[#fbbf24]">🕸️ GraphRAG — Entities, Relations, Communities</h3>
        <button onClick={rebuild} disabled={loading}
          className="text-[10px] px-2 py-1 bg-[#fbbf24]/10 text-[#fbbf24] border border-[#fbbf24]/30 rounded">
          Rebuild graph
        </button>
      </div>
      <p className="text-[10px] text-[#6b6b8d]">Cron nocny ekstrahuje encje (Person/Place/Activity) + relacje + wykrywa społeczności (clustering) + generuje podsumowania LLM.</p>
      <input type="text" value={query} onChange={e => setQuery(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && globalSearch()}
        placeholder="Global search: 'Co było ważne w tym tygodniu?'"
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] font-mono"
      />
      <button onClick={globalSearch} disabled={loading || !query.trim()}
        className="px-4 py-2 bg-[#fbbf24]/15 text-[#fbbf24] border border-[#fbbf24]/30 rounded text-xs font-mono disabled:opacity-50">
        Global search
      </button>
      {answer && (
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2 text-xs text-[#a0a0c0] whitespace-pre-wrap">
          {answer}
        </div>
      )}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Encje ({entities.length})</div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {entities.slice(0, 20).map((e, i) => (
              <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1 border border-[#2a2a3a]">
                <span className="text-[#fbbf24] font-mono">{e.name}</span>
                <span className="text-[#6b6b8d] ml-1">({e.type})</span>
                <span className="text-[#4ade80] ml-1">×{e.mentionCount}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Społeczności ({communities.length})</div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {communities.slice(0, 20).map((c, i) => (
              <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1 border border-[#2a2a3a]">
                <span className="text-[#a855f7] font-mono">L{c.level}</span>
                {c.label && <span className="text-[#e0e0f0] ml-1">{c.label}</span>}
                <div className="text-[#6b6b8d]">{c.summary?.slice(0, 80) || '(brak podsumowania)'}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function DeepAgentsPanel() {
  const [plans, setPlans] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [stepsText, setStepsText] = useState('');
  const [blobs, setBlobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    try {
      const [p, b] = await Promise.all([
        fetch('/api/deepagents?action=plans').then(r => r.json()),
        fetch('/api/deepagents?action=blobs').then(r => r.json()),
      ]);
      setPlans(p.plans || []);
      setBlobs(b.blobs || []);
    } catch {}
  };

  useEffect(() => { load(); }, []);

  const createPlan = async () => {
    if (!title || !stepsText) return;
    setLoading(true);
    try {
      const steps = stepsText.split('\n').filter(s => s.trim());
      await fetch('/api/deepagents?action=create_plan', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, steps, scope: 'daily' }),
      });
      setTitle(''); setStepsText('');
      load();
    } finally { setLoading(false); }
  };

  const toggleStep = async (planId: string, stepId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'done' ? 'pending' : 'done';
    await fetch(`/api/deepagents?action=update_step&planId=${planId}&stepId=${stepId}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    });
    load();
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#4ade80]">📋 DeepAgents — Todo-plans + Vestibule</h3>
      <p className="text-[10px] text-[#6b6b8d]">Widoczny plan dnia + vestibule filesystem (zrzucanie długich kontekstów). ReflectionSubagent czyta wykonane plany.</p>
      <input type="text" value={title} onChange={e => setTitle(e.target.value)}
        placeholder="Tytuł planu (np. 'Plan dnia 2026-06-17')"
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <textarea value={stepsText} onChange={e => setStepsText(e.target.value)}
        placeholder={"Jeden krok na linię:\nPrzypomnieć Tacie o zakupach\nPrzygotować quiz dla Zuzy\nPodsumować dzień o 20:00"}
        rows={4}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <button onClick={createPlan} disabled={loading || !title || !stepsText}
        className="px-4 py-2 bg-[#4ade80]/15 text-[#4ade80] border border-[#4ade80]/30 rounded text-xs font-mono disabled:opacity-50">
        Utwórz plan
      </button>

      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Plany ({plans.length})</div>
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {plans.map(p => {
            const steps = typeof p.steps === 'string' ? JSON.parse(p.steps) : p.steps;
            return (
              <div key={p.id} className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-[#e0e0f0]">{p.title}</span>
                  <span className={`text-[9px] ${p.status === 'completed' ? 'text-[#4ade80]' : 'text-[#fbbf24]'}`}>{p.status}</span>
                </div>
                <div className="mt-1 space-y-0.5">
                  {steps.map((s: any, i: number) => (
                    <button key={i} onClick={() => toggleStep(p.id, s.id, s.status)}
                      className="flex items-center gap-1 text-[10px] w-full text-left hover:bg-[#1e1e2e] px-1 py-0.5 rounded">
                      <span className={s.status === 'done' ? 'text-[#4ade80]' : 'text-[#6b6b8d]'}>
                        {s.status === 'done' ? '✓' : '○'}
                      </span>
                      <span className={s.status === 'done' ? 'text-[#6b6b8d] line-through' : 'text-[#a0a0c0]'}>{s.text}</span>
                    </button>
                  ))}
                </div>
                {p.reflectionNotes && (
                  <div className="mt-1 text-[10px] text-[#a855f7] italic">{p.reflectionNotes}</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Vestibule blobs ({blobs.length})</div>
        <div className="space-y-1 max-h-40 overflow-y-auto">
          {blobs.slice(0, 10).map((b, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1 border border-[#2a2a3a]">
              <span className="text-[#4ade80] font-mono">{b.kind}</span>
              <span className="text-[#6b6b8d] ml-2">{b.tokenCount} tok</span>
              <span className="text-[#6b6b8d] ml-2">×{b.accessCount}</span>
              {b.title && <div className="text-[#a0a0c0]">{b.title}</div>}
              {b.summary && <div className="text-[#6b6b8d]">{b.summary.slice(0, 100)}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AutoGenPanel() {
  const [topic, setTopic] = useState('discussion');
  const [trigger, setTrigger] = useState('');
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const loadHistory = async () => {
    try { setHistory((await fetch(`/api/autogen?action=history&topic=${topic}`).then(r => r.json())).history || []); } catch {}
  };

  useEffect(() => { loadHistory(); }, [topic]);

  const runGroupChat = async () => {
    if (!trigger) return;
    setLoading(true); setResult(null);
    try {
      const r = await fetch('/api/autogen?action=group_chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic, trigger,
          availableAgents: ['orchestrator', 'child_agent', 'finance_agent', 'health_agent', 'education_agent'],
          maxRounds: 3,
        }),
      }).then(r => r.json());
      setResult(r);
      loadHistory();
    } finally { setLoading(false); }
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#4ade80]">💬 AutoGen — SelectorGroupChat</h3>
      <p className="text-[10px] text-[#6b6b8d]">Multi-agent messaging: LLM wybiera kto z 6 agentów (orchestrator/child/finance/health/education/reflection) ma odpowiedzieć w każdej rundzie.</p>
      <select value={topic} onChange={e => setTopic(e.target.value)}
        className="bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono">
        <option value="discussion">discussion</option>
        <option value="reflection">reflection</option>
        <option value="research">research</option>
        <option value="ritual">ritual</option>
        <option value="alert">alert</option>
      </select>
      <textarea value={trigger} onChange={e => setTrigger(e.target.value)}
        placeholder="Wpisz trigger dla group chatu..."
        rows={2}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <button onClick={runGroupChat} disabled={loading || !trigger}
        className="px-4 py-2 bg-[#4ade80]/15 text-[#4ade80] border border-[#4ade80]/30 rounded text-xs font-mono disabled:opacity-50">
        {loading ? <Loader2 size={12} className="animate-spin inline" /> : null} Run SelectorGroupChat
      </button>
      {result && (
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
          <div className="text-[10px] text-[#4ade80] font-mono mb-1">Final agent: {result.selectedAgent}</div>
          <div className="text-xs text-[#a0a0c0]">{result.reply?.slice(0, 500)}</div>
          <div className="text-[10px] text-[#6b6b8d] mt-1">{result.messages?.length} wiadomości w wątku</div>
        </div>
      )}
      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Historia tematu '{topic}' ({history.length})</div>
        <div className="space-y-1 max-h-60 overflow-y-auto">
          {history.slice(-15).map((m, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1.5 border border-[#2a2a3a]">
              <span className="text-[#4ade80] font-mono">{m.fromAgent}</span>
              <span className="text-[#6b6b8d]"> → {m.toAgent || '(broadcast)'}</span>
              <div className="text-[#a0a0c0] mt-0.5">{m.payload?.content?.slice(0, 200)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GuardrailsPanel() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [childNearby, setChildNearby] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const check = async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/guardrails?action=check', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, output, childNearby, memberAge: 18 }),
      }).then(r => r.json());
      setResult(r);
    } finally { setLoading(false); }
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#4ade80]">🛡️ OpenAI Agents SDK — Guardrails</h3>
      <p className="text-[10px] text-[#6b6b8d]">Input guardrails: child_safe, financial_risk, intent_classify. Output guardrails: personality_consistency, length_check.</p>
      <label className="flex items-center gap-2 text-xs text-[#a0a0c0]">
        <input type="checkbox" checked={childNearby} onChange={e => setChildNearby(e.target.checked)}
          className="accent-[#4ade80]" />
        Dziecko w pobliżu (włącza child_safe filter)
      </label>
      <textarea value={input} onChange={e => setInput(e.target.value)}
        placeholder="Input użytkownika..."
        rows={2}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <textarea value={output} onChange={e => setOutput(e.target.value)}
        placeholder="Output BOKA do sprawdzenia..."
        rows={2}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <button onClick={check} disabled={loading}
        className="px-4 py-2 bg-[#4ade80]/15 text-[#4ade80] border border-[#4ade80]/30 rounded text-xs font-mono disabled:opacity-50">
        Run all guardrails
      </button>
      {result && (
        <div className="space-y-2">
          {result.blocked && (
            <div className="bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 rounded p-2 text-xs text-[#ff6b6b] font-mono">
              🚫 ZABLOKOWANE: {result.blockReason}
            </div>
          )}
          {result.warnings.length > 0 && (
            <div className="bg-[#fbbf24]/10 border border-[#fbbf24]/30 rounded p-2 text-xs text-[#fbbf24] font-mono">
              ⚠️ Ostrzeżenia: {result.warnings.join('; ')}
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Input guardrails</div>
              {result.input.map((r: any, i: number) => (
                <div key={i} className={`text-[10px] p-1 rounded mb-1 ${r.passed ? 'text-[#4ade80]' : 'text-[#ff6b6b]'}`}>
                  {r.passed ? '✓' : '✗'} {r.reason}
                </div>
              ))}
            </div>
            <div>
              <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Output guardrails</div>
              {result.output.map((r: any, i: number) => (
                <div key={i} className={`text-[10px] p-1 rounded mb-1 ${r.passed ? 'text-[#4ade80]' : 'text-[#ff6b6b]'}`}>
                  {r.passed ? '✓' : '✗'} {r.reason}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CrewPanel() {
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    try { setMembers((await fetch('/api/crew').then(r => r.json())).members || []); } catch {}
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <h3 className="text-xs font-mono text-[#60a5fa]">👥 CrewAI — Role + Backstory per Member</h3>
      <p className="text-[10px] text-[#6b6b8d]">Każdy domownik ma crew profile (role, goal, backstory) generowane z MemberProfile. Manager Agent ewaluuje cotygodniowo.</p>
      <div className="space-y-2">
        {members.length === 0 ? (
          <div className="text-[10px] text-[#6b6b8d]">Brak crew profili. Generuj przez API: POST /api/crew?action=generate&memberId=...</div>
        ) : members.map(m => (
          <div key={m.memberId} className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-[#60a5fa]">{m.role}</span>
              {m.evaluationScore !== undefined && (
                <span className="text-[10px] text-[#4ade80] font-mono">score: {m.evaluationScore.toFixed(2)}</span>
              )}
            </div>
            <div className="text-[10px] text-[#a0a0c0] mt-1">Cel: {m.goal}</div>
            <div className="text-[10px] text-[#6b6b8d] mt-1 italic">{m.backstory}</div>
            {m.lastEvaluatedAt && (
              <div className="text-[9px] text-[#6b6b8d] mt-1">Ewaluacja: {new Date(m.lastEvaluatedAt).toLocaleDateString()}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function SandboxPanel() {
  const [code, setCode] = useState(`// result = ... przypisz wynik\nconst result = input.a + input.b;\n`);
  const [inputPayload, setInputPayload] = useState('{"a": 5, "b": 7}');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const execute = async () => {
    setLoading(true); setResult(null);
    try {
      const r = await fetch('/api/openhands?action=execute', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          inputPayload: JSON.parse(inputPayload),
          inputType: 'function_call',
          sandboxKind: 'vm',
          timeoutMs: 5000,
        }),
      }).then(r => r.json());
      setResult(r);
    } catch (e: any) {
      setResult({ status: 'error', errorMessage: e.message });
    } finally { setLoading(false); }
  };

  const analyze = async () => {
    const r = await fetch('/api/openhands?action=analyze', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    }).then(r => r.json());
    alert(`Security flags: ${r.securityFlags.join(', ') || 'none'}\nBlocked: ${r.blocked}`);
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-mono text-[#60a5fa]">🔒 OpenHands Sandbox</h3>
        <button onClick={analyze} className="text-[10px] px-2 py-1 bg-[#60a5fa]/10 text-[#60a5fa] border border-[#60a5fa]/30 rounded">
          Security analyze
        </button>
      </div>
      <p className="text-[10px] text-[#6b6b8d]">Izolowany runtime (vm / worker_threads) z timeout + security scanning (fs_access, child_process, eval = block).</p>
      <textarea value={code} onChange={e => setCode(e.target.value)}
        rows={6}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <input type="text" value={inputPayload} onChange={e => setInputPayload(e.target.value)}
        className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
      />
      <button onClick={execute} disabled={loading}
        className="px-4 py-2 bg-[#60a5fa]/15 text-[#60a5fa] border border-[#60a5fa]/30 rounded text-xs font-mono disabled:opacity-50">
        {loading ? <Loader2 size={12} className="animate-spin inline" /> : null} Execute in sandbox
      </button>
      {result && (
        <div className={`bg-[#0f0f1a] border rounded p-2 text-xs ${result.status === 'success' ? 'border-[#4ade80]/30' : 'border-[#ff6b6b]/30'}`}>
          <div className="font-mono text-[#60a5fa] mb-1">Status: {result.status} ({result.durationMs}ms)</div>
          {result.errorMessage && <div className="text-[#ff6b6b]">{result.errorMessage}</div>}
          {result.output !== null && <pre className="text-[#a0a0c0] whitespace-pre-wrap">{JSON.stringify(result.output, null, 2)}</pre>}
          {result.securityFlags?.length > 0 && <div className="text-[#fbbf24] text-[10px] mt-1">Flags: {result.securityFlags.join(', ')}</div>}
        </div>
      )}
    </div>
  );
}

function PresencePanel() {
  const [history, setHistory] = useState<any[]>([]);
  const [present, setPresent] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState('salon');
  const [memberId, setMemberId] = useState<string | null>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);

  // Load members for memberId dropdown
  useEffect(() => {
    fetch('/api/family').then(r => r.json()).then(d => {
      setMembers(d.members || []);
    }).catch(() => {});
  }, []);

  const detection = usePresenceDetection(
    { mode: 'motion', location, memberId, fps: 5, cooldownMs: 60_000, absenceTimeoutMs: 30_000 },
    (e) => {
      // Refresh list when an event fires
      setTimeout(() => load(), 500);
    }
  );

  const load = async () => {
    setLoading(true);
    try {
      const [h, p] = await Promise.all([
        fetch('/api/presence?action=history').then(r => r.json()),
        fetch('/api/presence?action=present').then(r => r.json()),
      ]);
      setHistory(h.history || []);
      setPresent(p.present || []);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const simulateArrival = async () => {
    await fetch('/api/presence?action=event', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ eventKind: 'arrived', location, confidence: 0.85, captureMethod: 'metadata_only' }),
    });
    load();
  };

  const stateColor = detection.currentState === 'arrived' || detection.currentState === 'present'
    ? '#4ade80'
    : detection.currentState === 'left' ? '#ff6b6b' : '#6b6b8d';

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-mono text-[#60a5fa]">👁️ Isaac ROS — Presence Detection</h3>
        <button onClick={simulateArrival}
          className="text-[10px] px-2 py-1 bg-[#60a5fa]/10 text-[#60a5fa] border border-[#60a5fa]/30 rounded">
          Symuluj arrival
        </button>
      </div>
      <p className="text-[10px] text-[#6b6b8d]">
        Lokalna kamera + people detection (front-end, motion-based, zero deps). Tylko metadane (confidence, location, memberId)
        trafiają do API. Auto-triggery: <span className="text-[#a855f7]">after_school</span>, <span className="text-[#fbbf24]">morning_greeting</span>, <span className="text-[#4ade80]">evening_greeting</span>.
      </p>

      {/* ── Camera + Detection Controls ── */}
      <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-3 space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-[#6b6b8d] font-mono">Lokalizacja:</span>
          <select
            value={location}
            onChange={e => setLocation(e.target.value)}
            className="bg-[#1e1e2e] text-[#e0e0f0] text-[10px] font-mono px-2 py-1 rounded border border-[#2a2a3a]"
          >
            <option value="salon">salon</option>
            <option value="kuchnia">kuchnia</option>
            <option value="biuro">biuro</option>
            <option value="pokoj_dziecko">pokój dziecka</option>
            <option value="sypialnia">sypialnia</option>
            <option value="przedpokoj">przedpokój</option>
          </select>

          <span className="text-[10px] text-[#6b6b8d] font-mono ml-2">ReID:</span>
          <select
            value={memberId || ''}
            onChange={e => setMemberId(e.target.value || null)}
            className="bg-[#1e1e2e] text-[#e0e0f0] text-[10px] font-mono px-2 py-1 rounded border border-[#2a2a3a]"
          >
            <option value="">(osoba nieznana)</option>
            {members.map(m => (
              <option key={m.id} value={m.id}>{m.name} ({m.role})</option>
            ))}
          </select>

          {!detection.active ? (
            <button
              onClick={detection.start}
              disabled={detection.starting}
              className="text-[10px] px-3 py-1 bg-[#4ade80]/10 text-[#4ade80] border border-[#4ade80]/30 rounded ml-auto disabled:opacity-50"
            >
              {detection.starting ? 'Uruchamianie...' : '▶ Start kamery'}
            </button>
          ) : (
            <button
              onClick={detection.stop}
              className="text-[10px] px-3 py-1 bg-[#ff6b6b]/10 text-[#ff6b6b] border border-[#ff6b6b]/30 rounded ml-auto"
            >
              ■ Stop
            </button>
          )}
        </div>

        {detection.error && (
          <div className="text-[10px] text-[#ff6b6b] bg-[#ff6b6b]/5 p-2 rounded border border-[#ff6b6b]/30">
            ⚠ {detection.error}
          </div>
        )}

        <div className="flex items-center gap-3">
          {/* Hidden video + canvas (motion detection uses 64x48 canvas) */}
          <video
            ref={detection.videoRef}
            playsInline
            muted
            className="w-32 h-24 bg-black rounded border border-[#2a2a3a] object-cover"
            style={{ display: detection.active ? 'block' : 'none' }}
          />
          <canvas
            ref={detection.canvasRef}
            className="hidden"
          />

          {/* State indicator */}
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#6b6b8d] font-mono">Stan:</span>
              <span className="text-[10px] font-mono" style={{ color: stateColor }}>
                ● {detection.currentState.toUpperCase()}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#6b6b8d] font-mono">Motion:</span>
              <div className="flex-1 h-2 bg-[#1e1e2e] rounded overflow-hidden">
                <div
                  className="h-full transition-all"
                  style={{
                    width: `${detection.motionLevel}%`,
                    background: detection.motionLevel > 10 ? '#4ade80' : '#2a2a3a',
                  }}
                />
              </div>
              <span className="text-[10px] font-mono text-[#e0e0f0]">{detection.motionLevel}%</span>
            </div>
            <div className="flex items-center gap-4 text-[10px] text-[#6b6b8d] font-mono">
              <span>Events: {detection.eventsFired}</span>
              {detection.lastEventAt && (
                <span>Ostatni: {new Date(detection.lastEventAt).toLocaleTimeString()}</span>
              )}
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="text-[10px] text-[#4ade80] font-mono mb-1">Aktualnie obecni ({present.length})</div>
        <div className="space-y-1">
          {present.length === 0 ? (
            <div className="text-[10px] text-[#6b6b8d]">Nikogo nie wykryto</div>
          ) : present.map((p, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1.5 border border-[#2a2a3a]">
              <span className="text-[#60a5fa] font-mono">{p.member?.name || 'Nieznany'}</span>
              <span className="text-[#6b6b8d] ml-2">{p.location || '—'}</span>
              <span className="text-[#6b6b8d] ml-2">{new Date(p.lastSeen).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Historia zdarzeń ({history.length})</div>
        <div className="space-y-1 max-h-60 overflow-y-auto">
          {history.slice(0, 20).map((e, i) => (
            <div key={i} className="text-[10px] bg-[#0f0f1a] rounded p-1.5 border border-[#2a2a3a]">
              <span className={`font-mono ${e.eventKind === 'arrived' ? 'text-[#4ade80]' : e.eventKind === 'left' ? 'text-[#ff6b6b]' : 'text-[#6b6b8d]'}`}>
                {e.eventKind}
              </span>
              <span className="text-[#6b6b8d] ml-2">{new Date(e.createdAt).toLocaleString()}</span>
              {e.location && <span className="text-[#a0a0c0] ml-2">{e.location}</span>}
              {e.confidence !== null && <span className="text-[#fbbf24] ml-2">conf: {(e.confidence || 0).toFixed(2)}</span>}
              {e.triggerFired && <span className="text-[#a855f7] ml-2">→ {e.triggerFired}</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// WEEKLY REFLECTION PANEL — cron 0 4 * * 0
// GraphRAG rebuild + Supermemory refresh + CrewAI evaluation
// Manual trigger + client-side scheduler (auto-fires Sunday 04:00)
// ═══════════════════════════════════════════════════════════
function WeeklyReflectionPanel() {
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastRun, setLastRun] = useState<{ at: string; ok: boolean; durationMs: number } | null>(null);
  const [nextRun, setNextRun] = useState<string>('');
  const [autoScheduled, setAutoScheduled] = useState(true);
  const [stats, setStats] = useState<any>(null);

  // ── Load last-run info from localStorage + compute next Sunday 04:00 ──
  useEffect(() => {
    try {
      const stored = localStorage.getItem('boka.weeklyReflection.lastRun');
      if (stored) setLastRun(JSON.parse(stored));
    } catch {}

    const now = new Date();
    const next = new Date(now);
    next.setDate(now.getDate() + ((7 - now.getDay()) % 7 || 7)); // next Sunday
    next.setHours(4, 0, 0, 0);
    setNextRun(next.toLocaleString('pl-PL'));

    // Load stats
    fetch('/api/cron/weekly-reflection').then(r => r.json()).then(setStats).catch(() => {});

    // ── Auto-scheduler: check every 5 min if we're at Sunday 04:00 ±15min and not yet run this week ──
    if (!autoScheduled) return;
    const checkInterval = setInterval(() => {
      const n = new Date();
      const isSunday = n.getDay() === 0;
      const isTargetTime = n.getHours() === 4 && n.getMinutes() < 15;
      if (!isSunday || !isTargetTime) return;

      // Check if already ran this Sunday
      const stored = localStorage.getItem('boka.weeklyReflection.lastRun');
      let alreadyRan = false;
      if (stored) {
        try {
          const last = JSON.parse(stored);
          const lastDate = new Date(last.at);
          const lastSunday = new Date(n);
          lastSunday.setHours(0, 0, 0, 0);
          if (lastDate > lastSunday) alreadyRan = true;
        } catch {}
      }
      if (!alreadyRan) {
        console.log('[weekly-reflection] auto-triggering Sunday 04:00 run');
        runReflection(true);
      }
    }, 5 * 60 * 1000);

    return () => clearInterval(checkInterval);
  }, [autoScheduled]);

  const runReflection = async (auto = false) => {
    setRunning(true); setError(null); setLogs([]); setResult(null);
    const startedAt = new Date().toISOString();
    console.log(`[weekly-reflection] ${auto ? 'auto' : 'manual'} run starting at ${startedAt}`);

    try {
      const res = await fetch('/api/cron/weekly-reflection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || `HTTP ${res.status}`);
      }

      setResult(data);
      setLogs(data.log || []);
      const runInfo = { at: startedAt, ok: true, durationMs: data.durationMs };
      setLastRun(runInfo);
      try { localStorage.setItem('boka.weeklyReflection.lastRun', JSON.stringify(runInfo)); } catch {}

      // Refresh stats
      fetch('/api/cron/weekly-reflection').then(r => r.json()).then(setStats).catch(() => {});
    } catch (e: any) {
      setError(e.message);
      const runInfo = { at: startedAt, ok: false, durationMs: 0 };
      setLastRun(runInfo);
      try { localStorage.setItem('boka.weeklyReflection.lastRun', JSON.stringify(runInfo)); } catch {}
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-mono text-[#f472b6]">📅 Refleksja Cotygodniowa</h3>
          <p className="text-[10px] text-[#6b6b8d] mt-1">
            Cron <span className="font-mono text-[#fbbf24]">0 4 * * 0</span> — niedziela 04:00.
            Pipeline: GraphRAG rebuild → Supermemory (auto-profile per member) → CrewAI (Manager evaluation).
          </p>
        </div>
        <button
          onClick={() => runReflection(false)}
          disabled={running}
          className="text-[10px] px-3 py-2 bg-[#f472b6]/10 text-[#f472b6] border border-[#f472b6]/30 rounded disabled:opacity-50"
        >
          {running ? '⟳ Trwa...' : '▶ Uruchom teraz'}
        </button>
      </div>

      {/* Status grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
          <div className="text-[9px] text-[#6b6b8d] font-mono">Następny auto-run</div>
          <div className="text-[10px] text-[#f472b6] font-mono mt-0.5">{nextRun}</div>
        </div>
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
          <div className="text-[9px] text-[#6b6b8d] font-mono">Ostatni run</div>
          <div className="text-[10px] text-[#e0e0f0] font-mono mt-0.5">
            {lastRun ? `${new Date(lastRun.at).toLocaleString('pl-PL')} (${(lastRun.durationMs/1000).toFixed(0)}s)` : '—'}
          </div>
          {lastRun && (
            <div className={`text-[9px] font-mono mt-0.5 ${lastRun.ok ? 'text-[#4ade80]' : 'text-[#ff6b6b]'}`}>
              {lastRun.ok ? '✓ sukces' : '✗ błąd'}
            </div>
          )}
        </div>
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
          <div className="text-[9px] text-[#6b6b8d] font-mono">Auto-scheduler</div>
          <label className="flex items-center gap-1 mt-0.5 cursor-pointer">
            <input
              type="checkbox"
              checked={autoScheduled}
              onChange={e => setAutoScheduled(e.target.checked)}
              className="w-3 h-3"
            />
            <span className="text-[10px] text-[#e0e0f0] font-mono">
              {autoScheduled ? 'włączony' : 'wyłączony'}
            </span>
          </label>
        </div>
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
          <div className="text-[9px] text-[#6b6b8d] font-mono">Stats (24h)</div>
          <div className="text-[10px] text-[#e0e0f0] font-mono mt-0.5">
            {stats?.last24h ? (
              <>
                C:{stats.last24h.newCommunities} R:{stats.last24h.profileRevisions} E:{stats.last24h.crewEvaluations}
              </>
            ) : '—'}
          </div>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="text-[10px] text-[#ff6b6b] bg-[#ff6b6b]/5 p-2 rounded border border-[#ff6b6b]/30">
          ⚠ {error}
        </div>
      )}

      {/* Result summary */}
      {result && (
        <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-3 space-y-2">
          <div className="text-[10px] font-mono text-[#4ade80]">✓ Refleksja zakończona ({(result.durationMs/1000).toFixed(1)}s, {result.families} rodzin)</div>
          {result.results?.map((f: any, i: number) => (
            <div key={i} className="border-t border-[#2a2a3a] pt-2 mt-1 space-y-1">
              <div className="text-[10px] font-mono text-[#fbbf24]">Family {f.familyId}</div>
              <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
                <div>
                  <div className="text-[#6b6b8d]">GraphRAG</div>
                  <div className="text-[#e0e0f0]">
                    {f.stages.graphrag?.error ? '✗' : `E:${f.stages.graphrag?.entitiesProcessed || 0} C:${f.stages.graphrag?.communitiesCreated || 0}`}
                  </div>
                </div>
                <div>
                  <div className="text-[#6b6b8d]">Supermemory</div>
                  <div className="text-[#e0e0f0]">
                    {f.stages.supermemory?.error ? '✗' : `${f.stages.supermemory?.membersProcessed || 0} profili`}
                  </div>
                </div>
                <div>
                  <div className="text-[#6b6b8d]">CrewAI</div>
                  <div className="text-[#e0e0f0]">
                    {f.stages.crew?.error ? '✗' : `${f.stages.crew?.membersProcessed || 0} eval`}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Logs */}
      {logs.length > 0 && (
        <div>
          <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">Logi ({logs.length})</div>
          <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2 max-h-60 overflow-y-auto space-y-0.5">
            {logs.map((l, i) => (
              <div key={i} className="text-[10px] font-mono text-[#a0a0c0]">
                {l.includes('✓') ? <span className="text-[#4ade80]">{l}</span> :
                 l.includes('✗') ? <span className="text-[#ff6b6b]">{l}</span> :
                 l.includes('FAILED') ? <span className="text-[#ff6b6b]">{l}</span> :
                 l.includes('══') ? <span className="text-[#f472b6]">{l}</span> :
                 l}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Setup instructions */}
      <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-3">
        <div className="text-[10px] font-mono text-[#a855f7] mb-1">📋 Konfiguracja external cron (opcjonalnie)</div>
        <pre className="text-[9px] font-mono text-[#6b6b8d] whitespace-pre-wrap">
{`# Linux crontab (systemd timer / cron):
0 4 * * 0 curl -X POST http://localhost:3000/api/cron/weekly-reflection \\
  -H "X-BOKA-CRON: $BOKA_CRON_SECRET"

# Windows Task Scheduler (niedziela 04:00):
cmd /c "curl -X POST http://localhost:3000/api/cron/weekly-reflection -H \\"X-BOKA-CRON: secret\\""

# Lub zostaw auto-scheduler (powyżej) — wyzwoli się sam gdy BOKA jest włączona w niedzielę 04:00.`}
        </pre>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MEMORY SEARCH PANEL — zaawansowane wyszukiwanie z /api/memory/search
// Tryby: text search (q=) oraz smart recall (mode=recall)
// Filtry: memberId, domain, emotion
// ═══════════════════════════════════════════════════════════
function MemorySearchPanel() {
  const [query, setQuery] = useState('');
  const [mode, setMode] = useState<'search' | 'recall'>('search');
  const [memberId, setMemberId] = useState('');
  const [domain, setDomain] = useState('');
  const [emotion, setEmotion] = useState('');
  const [results, setResults] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const DOMAINS = ['general', 'child_culture', 'education', 'finance', 'legal', 'health', 'food', 'hobby', 'social', 'family', 'work'];
  const EMOTIONS = ['happy', 'calm', 'curious', 'playful', 'focused', 'tired', 'concerned', 'excited', 'reflective', 'neutral', 'sad', 'angry'];

  const run = async () => {
    setLoading(true); setError(null); setResults(null);
    try {
      const params = new URLSearchParams();
      if (mode === 'recall') {
        params.set('mode', 'recall');
        if (memberId) params.set('memberId', memberId);
        if (emotion) params.set('emotion', emotion);
      } else {
        if (!query.trim()) { setError('Podaj zapytanie (q)'); setLoading(false); return; }
        params.set('q', query.trim());
        if (memberId) params.set('memberId', memberId);
        if (domain) params.set('domain', domain);
        if (emotion) params.set('emotion', emotion);
      }
      const r = await fetch(`/api/memory/search?${params.toString()}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Błąd wyszukiwania');
      setResults(data.results || []);
    } catch (e: any) {
      setError(e.message || 'Nieznany błąd');
    } finally { setLoading(false); }
  };

  return (
    <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 space-y-3">
      {/* Mode toggle */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-mono text-[#6b6b8d]">Tryb:</span>
        <button
          onClick={() => setMode('search')}
          className={`px-3 py-1 rounded text-xs font-mono ${mode === 'search' ? 'bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50' : 'bg-[#0f0f1a] text-[#6b6b8d] border border-[#2a2a3a]'}`}
        >
          <Search size={10} className="inline mr-1" />Text search
        </button>
        <button
          onClick={() => setMode('recall')}
          className={`px-3 py-1 rounded text-xs font-mono ${mode === 'recall' ? 'bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50' : 'bg-[#0f0f1a] text-[#6b6b8d] border border-[#2a2a3a]'}`}
        >
          <Brain size={10} className="inline mr-1" />Smart recall (scoring)
        </button>
      </div>

      {/* Query row */}
      {mode === 'search' && (
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && run()}
          placeholder='Szukaj w pamięci BOKA... (np. wczorajszy obiad, projekt React)'
          className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#a855f7]/50 font-mono"
        />
      )}

      {/* Filters */}
      <div className="grid grid-cols-3 gap-2">
        <div>
          <label className="text-[10px] text-[#6b6b8d] font-mono">Member</label>
          <input
            type="text"
            value={memberId}
            onChange={e => setMemberId(e.target.value)}
            placeholder="(wszyscy)"
            className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono"
          />
        </div>
        <div>
          <label className="text-[10px] text-[#6b6b8d] font-mono">Domain</label>
          <select value={domain} onChange={e => setDomain(e.target.value)}
            className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono">
            <option value="">(wszystkie)</option>
            {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[10px] text-[#6b6b8d] font-mono">Emotion</label>
          <select value={emotion} onChange={e => setEmotion(e.target.value)}
            className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] font-mono">
            <option value="">(dowolna)</option>
            {EMOTIONS.map(em => <option key={em} value={em}>{em}</option>)}
          </select>
        </div>
      </div>

      {/* Run */}
      <button
        onClick={run}
        disabled={loading || (mode === 'search' && !query.trim())}
        className="px-4 py-2 bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30 rounded-lg text-xs font-mono disabled:opacity-50 flex items-center gap-2"
      >
        {loading ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}
        {mode === 'recall' ? 'Przywołaj wspomnienia' : 'Szukaj'}
      </button>

      {/* Error */}
      {error && (
        <div className="text-xs text-[#ff6b6b] bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 rounded p-2 font-mono">
          {error}
        </div>
      )}

      {/* Results */}
      {results !== null && (
        <div className="space-y-2">
          <div className="text-[10px] text-[#6b6b8d] font-mono">{results.length} wyników</div>
          {results.length === 0 ? (
            <div className="text-xs text-[#6b6b8d] p-4 bg-[#0f0f1a] rounded text-center">
              Brak wyników. {mode === 'recall' ? 'Pamięć BOKA jest pusta lub brak pasującego kontekstu emocjonalnego.' : 'Spróbuj innej frazy.'}
            </div>
          ) : results.map((r, i) => (
            <div key={r.id || i} className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-[#a855f7] font-mono uppercase">{r.type || r.entryType || 'memory'}</span>
                <div className="flex items-center gap-2">
                  {r.score !== undefined && (
                    <span className="text-[10px] text-[#4ade80] font-mono">score: {typeof r.score === 'number' ? r.score.toFixed(2) : r.score}</span>
                  )}
                  <span className="text-[9px] text-[#6b6b8d]">{r.createdAt ? new Date(r.createdAt).toLocaleDateString() : ''}</span>
                </div>
              </div>
              <div className="text-xs text-[#e0e0f0]">
                {r.title && <div className="font-mono mb-1">{r.title}</div>}
                <div className="text-[#a0a0c0] whitespace-pre-wrap">
                  {(r.content || r.summary || r.text || '').slice(0, expanded === (r.id || String(i)) ? undefined : 240)}
                  {(r.content || r.summary || r.text || '').length > 240 && (
                    <button
                      onClick={() => setExpanded(expanded === (r.id || String(i)) ? null : (r.id || String(i)))}
                      className="ml-1 text-[#00f5d4] underline"
                    >
                      {expanded === (r.id || String(i)) ? 'mniej' : 'więcej'}
                    </button>
                  )}
                </div>
              </div>
              {/* Tags */}
              {(r.tags || (r.domain && [r.domain])) && (
                <div className="flex gap-1 mt-2 flex-wrap">
                  {(r.tags || (r.domain ? [r.domain] : [])).map((t: string, j: number) => (
                    <span key={j} className="text-[9px] px-1.5 py-0.5 bg-[#1e1e2e] border border-[#2a2a3a] rounded text-[#6b6b8d] font-mono">#{t}</span>
                  ))}
                </div>
              )}
              {/* Emotion */}
              {r.emotion && (
                <div className="text-[9px] text-[#fbbf24] font-mono mt-1">nastrój: {r.emotion}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MemoryTab({ entries, members, activeMemberId }: {
  entries: MemoryEntry[];
  members: FamilyMember[];
  activeMemberId: string | null;
}) {
  const [filter, setFilter] = useState<string>('all');
  const [memberFilter, setMemberFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'graph' | 'list'>('graph');
  const [graphData, setGraphData] = useState<{ nodes: any[]; edges: any[]; stats: any } | null>(null);
  const [selectedNode, setSelectedNode] = useState<any>(null);
  const [graphLoading, setGraphLoading] = useState(false);
  // ═══ Smart Recall — /api/memory/search server-side search with scoring ═══
  const [smartMode, setSmartMode] = useState(false);
  const [smartResults, setSmartResults] = useState<any[] | null>(null);
  const [smartLoading, setSmartLoading] = useState(false);
  const [smartError, setSmartError] = useState<string | null>(null);

  // Debounced smart search (server-side, only when smartMode is on)
  useEffect(() => {
    if (!smartMode) { setSmartResults(null); setSmartError(null); return; }
    if (!searchQuery.trim() && memberFilter === 'all') {
      setSmartResults(null);
      return;
    }
    setSmartLoading(true);
    setSmartError(null);
    const t = setTimeout(async () => {
      try {
        const params = new URLSearchParams();
        if (searchQuery.trim()) params.set('q', searchQuery.trim());
        if (memberFilter !== 'all') params.set('memberId', memberFilter);
        if (filter !== 'all') params.set('domain', filter);
        // If no query, use recall mode (emotion-aware ranked retrieval)
        if (!searchQuery.trim()) params.set('mode', 'recall');
        const res = await fetch(`/api/memory/search?${params.toString()}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setSmartResults(data.results || []);
      } catch (e: any) {
        setSmartError(e?.message || 'Błąd wyszukiwania');
        setSmartResults([]);
      } finally {
        setSmartLoading(false);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [smartMode, searchQuery, memberFilter, filter]);

  // Fetch graph data
  useEffect(() => {
    if (viewMode !== 'graph') return;
    let cancelled = false;
    setGraphLoading(true);
    const params = memberFilter !== 'all' ? `?memberId=${memberFilter}` : '';
    fetch(`/api/memory/graph${params}`)
      .then(r => r.json())
      .then(data => { if (!cancelled) { setGraphData(data); setGraphLoading(false); } })
      .catch(() => { if (!cancelled) setGraphLoading(false); });
    return () => { cancelled = true; };
  }, [viewMode, memberFilter]);

  let filtered = filter === 'all'
    ? entries
    : entries.filter(e => e.domain === filter || e.entryType === filter);

  if (memberFilter !== 'all') {
    filtered = filtered.filter(e => e.memberId === memberFilter);
  }

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(e =>
      e.content.toLowerCase().includes(q) ||
      (e.title && e.title.toLowerCase().includes(q)) ||
      e.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  const domainColors: Record<string, string> = {
    general: '#6b6b8d', child_culture: '#ffd93d', education: '#a855f7',
    finance: '#4ade80', legal: '#60a5fa', health: '#ff6b6b',
    food: '#f472b6', hobby: '#ffd93d', social: '#00f5d4',
    family: '#4ade80', work: '#60a5fa',
  };

  const entryTypeLabels: Record<string, string> = {
    semantic: 'Wiedza', episodic: 'Wydarzenie', decision: 'Decyzja',
    event: 'Zdarzenie', preference: 'Preferencja',
  };

  // When a graph node is clicked, show its memory details below
  const handleGraphNodeClick = useCallback((node: any) => {
    setSelectedNode(node);
  }, []);

  // ── v0.3.4: Graf dopasowany do szerokości kontenera (zamiast stałego 700px) ──
  const graphContainerRef = useRef<HTMLDivElement>(null);
  const [graphWidth, setGraphWidth] = useState(860);
  useEffect(() => {
    if (typeof ResizeObserver === 'undefined') return;
    const el = graphContainerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      for (const e of entries) {
        const w = Math.floor(e.contentRect.width);
        if (w > 320) setGraphWidth(w);
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="max-w-4xl mx-auto">
        <BokaInsights />
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-pixel text-sm" style={{ color: '#6ee77c' }}>PAMIĘĆ BOKI</h2>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-[#6b6b8d] font-mono">
              <Activity size={12} className="text-[#00f5d4]" />
              <span>{entries.length} wpisów</span>
            </div>
            {/* View mode toggle */}
            <div className="flex items-center bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('graph')}
                className={`px-2 py-1 text-xs font-mono flex items-center gap-1 transition-colors ${viewMode === 'graph' ? 'bg-[#00f5d4]/15 text-[#00f5d4]' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
              >
                <Network size={12} /> Graf
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-2 py-1 text-xs font-mono flex items-center gap-1 transition-colors ${viewMode === 'list' ? 'bg-[#00f5d4]/15 text-[#00f5d4]' : 'text-[#6b6b8d] hover:text-[#e0e0f0]'}`}
              >
                <List size={12} /> Lista
              </button>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <div className="flex gap-2 items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={smartMode ? "Smart recall — server-side wyszukiwanie z scoringiem..." : "Szukaj w pamięci BOKI (lokalny filtr)..."}
              className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono"
            />
            <button
              onClick={() => setSmartMode(v => !v)}
              className={`px-3 py-2 rounded-lg text-xs font-mono border flex items-center gap-1.5 whitespace-nowrap transition-all ${
                smartMode
                  ? 'bg-[#a855f7]/15 border-[#a855f7]/50 text-[#a855f7]'
                  : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d] hover:text-[#a855f7] hover:border-[#a855f7]/30'
              }`}
              title="Smart Recall używa /api/memory/search — scoring semantyczny, ważność, świeżość, emocje"
            >
              <Sparkles size={12} />
              Smart{smartMode ? ' ✓' : ''}
            </button>
          </div>
          {smartMode && (
            <div className="text-[10px] text-[#a855f7]/80 mt-1 font-mono flex items-center gap-1">
              <Sparkles size={9} />
              Tryb Smart: server-side scoring (semantyka × ważność × świeżość × emocje).
              Puste q = recall (top wspomnienia na teraz).
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-2 mb-3">
          <button onClick={() => setMemberFilter('all')} className={`px-3 py-1 rounded text-xs font-mono transition-colors ${memberFilter === 'all' ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>Wszyscy</button>
          {members.map(m => (
            <button key={m.id} onClick={() => setMemberFilter(m.id)} className={`px-3 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1 ${memberFilter === m.id ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
              <PixelAvatar name={m.name} category={(m.category || 'family') as any} color={m.color || undefined} role={m.role} size={14} showRing={false} />
              {m.name}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {['all', 'general', 'child_culture', 'education', 'finance', 'health', 'food', 'hobby', 'semantic', 'episodic'].map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1 rounded text-xs font-mono transition-colors ${filter === f ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50' : 'bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
              {f === 'all' ? 'Wszystko' : f}
            </button>
          ))}
        </div>

        {/* ── GRAPH VIEW ── */}
        {viewMode === 'graph' && (
          <div className="mb-4" ref={graphContainerRef}>
            {graphLoading ? (
              <div className="bg-[#0a0a12] rounded-xl border border-[#2a2a3a] flex items-center justify-center" style={{ height: 380 }}>
                <div className="text-[#6b6b8d] font-mono text-sm flex items-center gap-2">
                  <Activity size={14} className="animate-spin" /> Ładowanie grafu...
                </div>
              </div>
            ) : graphData && graphData.nodes.length > 0 ? (
              <>
                <MemoryGraph
                  nodes={graphData.nodes}
                  edges={graphData.edges}
                  width={graphWidth}
                  height={380}
                  onNodeClick={handleGraphNodeClick}
                  selectedNodeId={selectedNode?.id}
                  className="mb-2"
                />
                {/* Stats bar */}
                <div className="flex items-center gap-4 text-[10px] text-[#6b6b8d] font-mono mb-3">
                  <span>{graphData.stats.members} osób</span>
                  <span>{graphData.stats.displayedMemories} wspomnień</span>
                  <span>{graphData.stats.domains} domen</span>
                  <span>{graphData.stats.tags} tagów</span>
                  <span className="text-[#8899aa] ml-auto">Scroll = zoom • Drag = przesuń • Klik = szczegóły</span>
                </div>
              </>
            ) : (
              <div className="bg-[#0a0a12] rounded-xl border border-[#2a2a3a] flex items-center justify-center" style={{ height: 380 }}>
                <div className="text-[#6b6b8d] font-mono text-sm text-center">
                  <Network size={24} className="mx-auto mb-2 opacity-30" />
                  Brak danych do wyświetlenia grafu
                </div>
              </div>
            )}

            {/* Selected node detail */}
            {selectedNode && (
              <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 mb-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedNode.color }} />
                  <span className="text-sm font-mono font-bold text-[#e0e0f0]">
                    {selectedNode.emoji && `${selectedNode.emoji} `}{selectedNode.label}
                  </span>
                  <span className="px-2 py-0.5 bg-[#2a2a3a] rounded text-[10px] text-[#6b6b8d]">{selectedNode.type}</span>
                  <button onClick={() => setSelectedNode(null)} className="ml-auto text-[#6b6b8d] hover:text-[#e0e0f0]">
                    <X size={14} />
                  </button>
                </div>
                {selectedNode.meta?.content && (
                  <div className="text-sm text-[#e0e0f0]/80 font-mono">{String(selectedNode.meta.content)}</div>
                )}
                {selectedNode.meta?.role && (
                  <div className="text-xs text-[#6b6b8d] mt-1">
                    Rola: {String(selectedNode.meta.role)}{selectedNode.meta.age ? ` • Wiek: ${String(selectedNode.meta.age)}` : ''}
                    {selectedNode.meta.isActive ? ' • Aktywny' : ''}
                  </div>
                )}
                {selectedNode.meta?.domain && (
                  <div className="text-xs text-[#6b6b8d] mt-1">
                    Domena: {String(selectedNode.meta.domain)} • Typ: {String(selectedNode.meta.entryType)} • Ważność: {String(Math.round((Number(selectedNode.meta.importance) || 0) * 100))}%
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── LIST VIEW ── */}
        {viewMode === 'list' && (
          <div className="space-y-2">
            {/* ═══ Smart Recall results (server-side, with scoring) ═══ */}
            {smartMode && smartLoading && (
              <div className="text-center py-4 text-[#a855f7] text-xs font-mono flex items-center justify-center gap-2">
                <Loader2 size={14} className="animate-spin" />
                Wyszukiwanie w pamięci z scoringiem...
              </div>
            )}
            {smartMode && smartError && (
              <div className="bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 rounded p-3 text-xs text-[#ff6b6b] font-mono">
                Błąd: {smartError}
              </div>
            )}
            {smartMode && !smartLoading && smartResults && smartResults.length === 0 && (
              <div className="text-center text-[#6b6b8d] py-8 text-sm font-mono">
                Brak wyników smart recall dla tego zapytania.
              </div>
            )}
            {smartMode && !smartLoading && smartResults && smartResults.length > 0 && (
              <>
                <div className="text-[10px] text-[#a855f7]/80 font-mono mb-2 flex items-center gap-1">
                  <Sparkles size={9} />
                  {smartResults.length} wyników z /api/memory/search — sortowane wg score
                </div>
                {smartResults.map((r: any) => (
                  <div key={r.id || r.memoryId} className="scanline-effect bg-[#1e1e2e] border border-[#a855f7]/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      {r.domain && <span className="px-2 py-0.5 rounded text-[10px] font-mono" style={{ color: domainColors[r.domain] || '#6b6b8d', backgroundColor: `${domainColors[r.domain] || '#6b6b8d'}15` }}>{r.domain}</span>}
                      <span className="text-[10px] text-[#6b6b8d]">{entryTypeLabels[r.entryType] || r.entryType}</span>
                      {r.score !== undefined && (
                        <span className="ml-auto px-2 py-0.5 rounded text-[10px] font-mono bg-[#a855f7]/15 text-[#a855f7] border border-[#a855f7]/30">
                          score: {typeof r.score === 'number' ? r.score.toFixed(2) : r.score}
                        </span>
                      )}
                    </div>
                    {r.title && <div className="text-xs font-bold text-[#e0e0f0] mb-1">{r.title}</div>}
                    <div className="text-sm text-[#e0e0f0]/80 font-mono">{r.content}</div>
                    {r.matchReason && (
                      <div className="text-[10px] text-[#a855f7]/70 mt-1 font-mono">✓ {r.matchReason}</div>
                    )}
                    {r.tags && Array.isArray(r.tags) && r.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {r.tags.map((tag: string, i: number) => (
                          <span key={i} className="px-1.5 py-0.5 bg-[#2a2a3a] rounded text-[10px] text-[#6b6b8d]">{tag}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}

            {/* ═══ Standard local-filter list (only when Smart is OFF) ═══ */}
            {!smartMode && (
              <>
                {filtered.length === 0 ? (
                  <div className="text-center text-[#6b6b8d] py-8 text-sm font-mono">Brak wpisów w pamięci</div>
                ) : (
                  filtered.map(entry => (
                    <div key={entry.id} className="scanline-effect bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        {entry.domain && <span className="px-2 py-0.5 rounded text-[10px] font-mono" style={{ color: domainColors[entry.domain] || '#6b6b8d', backgroundColor: `${domainColors[entry.domain] || '#6b6b8d'}15` }}>{entry.domain}</span>}
                        <span className="text-[10px] text-[#6b6b8d]">{entryTypeLabels[entry.entryType] || entry.entryType}</span>
                        {entry.importance >= 0.8 && <Star size={10} className="text-[#ffd93d]" />}
                        <span className="text-[10px] text-[#6b6b8d] ml-auto">{new Date(entry.createdAt).toLocaleDateString('pl-PL')}</span>
                      </div>
                      {entry.title && <div className="text-xs font-bold text-[#e0e0f0] mb-1">{entry.title}</div>}
                      <div className="text-sm text-[#e0e0f0]/80 font-mono">{entry.content}</div>
                      {entry.tags && entry.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {entry.tags.map((tag, i) => (
                            <span key={i} className="px-1.5 py-0.5 bg-[#2a2a3a] rounded text-[10px] text-[#6b6b8d]">{tag}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// PROFILES TAB
// ═══════════════════════════════════════════
function ProfilesTab({ members, activeMemberId, setActiveMember, childNearby, toggleChildNearby }: {
  members: FamilyMember[]; activeMemberId: string | null;
  setActiveMember: (id: string) => void; childNearby: boolean; toggleChildNearby: () => void;
}) {
  const [showAddPerson, setShowAddPerson] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formRole, setFormRole] = useState('other');
  const [formAge, setFormAge] = useState(0);
  const [formCategory, setFormCategory] = useState<'family' | 'friend' | 'colleague' | 'acquaintance' | 'other'>('other');
  const [formColor, setFormColor] = useState('');
  const [formEmoji, setFormEmoji] = useState('🙂');
  const [saving, setSaving] = useState(false);

  // Group members by category
  const familyMembers = members.filter(m => !m.category || m.category === 'family');
  const otherMembers = members.filter(m => m.category && m.category !== 'family');

  const resetForm = () => {
    setFormName(''); setFormRole('other'); setFormAge(0);
    setFormCategory('other'); setFormColor(''); setFormEmoji('🙂');
    setEditingMember(null);
  };

  const openAdd = (presetCategory: 'family' | 'friend' | 'colleague' | 'acquaintance' | 'other' = 'other') => {
    resetForm();
    setFormCategory(presetCategory);
    setShowAddPerson(true);
  };

  const openEdit = (m: FamilyMember) => {
    setFormName(m.name);
    setFormRole(m.role);
    setFormAge(m.age);
    setFormCategory((m.category as any) || 'family');
    setFormColor(m.color || '');
    setFormEmoji(m.avatarEmoji);
    setEditingMember(m);
    setShowAddPerson(true);
  };

  const handleSubmit = async () => {
    if (!formName.trim()) return;
    setSaving(true);
    try {
      if (editingMember) {
        const res = await fetch(`/api/family/update?id=${editingMember.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName, role: formRole, age: formAge,
            avatarEmoji: formEmoji, category: formCategory,
            color: formColor || null,
          }),
        });
        if (res.ok) { setShowAddPerson(false); resetForm(); window.location.reload(); }
      } else {
        const res = await fetch('/api/family', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName, role: formRole, age: formAge,
            avatarEmoji: formEmoji, category: formCategory,
            color: formColor || null,
          }),
        });
        if (res.ok) { setShowAddPerson(false); resetForm(); window.location.reload(); }
      }
    } finally { setSaving(false); }
  };

  const handleDelete = async (m: FamilyMember) => {
    if (!confirm(`Usunąć "${m.name}"? Tej operacji nie można cofnąć.`)) return;
    const res = await fetch(`/api/family?id=${m.id}`, { method: 'DELETE' });
    if (res.ok) window.location.reload();
    else {
      const data = await res.json();
      alert(data.error || 'Błąd usuwania');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header with add buttons */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-pixel text-sm" style={{ color: '#6ee7b2' }}>LUDZIE WOKÓŁ BOKA</h2>
          <div className="flex gap-2">
            <button onClick={() => openAdd('family')}
              className="px-2 py-1 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-xs hover:bg-[#00f5d4]/20 flex items-center gap-1">
              <Plus size={12} /> Rodzina
            </button>
            <button onClick={() => openAdd('other')}
              className="px-2 py-1 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-xs hover:bg-[#a855f7]/20 flex items-center gap-1">
              <Plus size={12} /> Inna osoba
            </button>
          </div>
        </div>

        {/* Child safety toggle */}
        <div className={`mb-6 p-4 rounded-lg border ${childNearby ? 'bg-[#4ade80]/5 border-[#4ade80]/30' : 'bg-[#1e1e2e] border-[#2a2a3a]'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Baby size={24} className={childNearby ? 'text-[#4ade80]' : 'text-[#6b6b8d]'} />
              <div>
                <div className="text-sm font-bold text-[#e0e0f0]">{childNearby ? 'Tryb: Dziecko w pobliżu' : 'Tryb: Standardowy'}</div>
                <div className="text-xs text-[#6b6b8d] font-mono">{childNearby ? 'Filtr języka AKTYWNY' : 'Filtr języka nieaktywny'}</div>
              </div>
            </div>
            <button onClick={toggleChildNearby} className={`px-4 py-2 rounded-lg text-xs font-mono transition-all ${childNearby ? 'bg-[#4ade80]/20 text-[#4ade80] border border-[#4ade80]/50' : 'bg-[#2a2a3a] text-[#6b6b8d] border border-[#2a2a3a]'}`}>
              {childNearby ? 'AKTYWNY' : 'WŁĄCZ'}
            </button>
          </div>
        </div>

        {/* FAMILY section */}
        {familyMembers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-xs font-mono text-[#00f5d4] mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00f5d4]" />
              RODZINA ({familyMembers.length})
            </h3>
            <div className="grid gap-3 md:grid-cols-3">
              {familyMembers.map(member => {
                const prefs = member.preferences as Record<string, unknown> | null;
                const zodiac = prefs?.zodiacSign as string | undefined;
                const ZODIAC_EMOJI: Record<string, string> = {
                  'Baran': '♈', 'Byk': '♉', 'Bliźnięta': '♊', 'Rak': '♋',
                  'Lew': '♌', 'Panna': '♍', 'Waga': '♎', 'Skorpion': '♏',
                  'Strzelec': '♐', 'Koziorożec': '♑', 'Wodnik': '♒', 'Ryby': '♓',
                };
                return (
                  <button key={member.id} onClick={() => setActiveMember(member.id)} className={`p-4 rounded-lg border text-left transition-all ${activeMemberId === member.id ? 'bg-[#1e1e2e] border-[#00f5d4]/50 agent-active' : 'bg-[#14141f] border-[#2a2a3a] hover:border-[#00f5d4]/30'}`}>
                    <div className="flex items-center gap-3 mb-3">
                      <PixelAvatar name={member.name} category={(member.category || 'family') as any} color={member.color || undefined} role={member.role} size={48} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-bold text-[#e0e0f0] truncate">{member.name}</div>
                        <div className="text-xs text-[#6b6b8d] font-mono">
                          {member.role === 'parent' ? 'Rodzic' : member.role === 'partner' ? 'Partnerka' : member.role === 'child' ? 'Dziecko' : member.role} - {member.age} lat
                        </div>
                      </div>
                      <button onClick={(e) => { e.stopPropagation(); openEdit(member); }}
                        className="text-[#6b6b8d] hover:text-[#00f5d4] text-[10px]" title="Edytuj">
                        <Wrench size={12} />
                      </button>
                    </div>
                    {zodiac && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="text-sm">{ZODIAC_EMOJI[zodiac] || '⭐'}</span>
                        <span className="text-[11px] text-[#ffd93d] font-mono">{zodiac}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${member.isActive ? 'bg-[#4ade80]' : 'bg-[#6b6b8d]'}`} />
                      <span className="text-[10px] text-[#6b6b8d]">{member.isActive ? 'Obecny/a' : 'Nieobecny/a'}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* OTHER PEOPLE section */}
        {otherMembers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-xs font-mono text-[#a855f7] mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#a855f7]" />
              INNE OSOBY ({otherMembers.length})
            </h3>
            <div className="grid gap-3 md:grid-cols-4">
              {otherMembers.map(member => (
                <div key={member.id} className={`p-3 rounded-lg border text-left transition-all bg-[#14141f] border-[#2a2a3a] hover:border-[#a855f7]/30 ${activeMemberId === member.id ? 'border-[#a855f7]/50 agent-active' : ''}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <PixelAvatar name={member.name} category={(member.category || 'other') as any} color={member.color || undefined} role={member.role} size={36} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-[#e0e0f0] truncate">{member.name}</div>
                      <div className="text-[10px] text-[#6b6b8d] font-mono">
                        {getCategoryLabel(member.category as any)} · {member.role}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-2">
                    <button onClick={() => setActiveMember(member.id)}
                      className="text-[10px] px-1.5 py-0.5 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded hover:bg-[#a855f7]/20">
                      Wybierz
                    </button>
                    <button onClick={() => openEdit(member)}
                      className="text-[10px] px-1.5 py-0.5 bg-[#1e1e2e] border border-[#2a2a3a] text-[#a0a0c0] rounded hover:text-[#00f5d4]">
                      Edytuj
                    </button>
                    <button onClick={() => handleDelete(member)}
                      className="text-[10px] px-1.5 py-0.5 bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] rounded hover:bg-[#ff6b6b]/10 hover:text-[#ff6b6b]">
                      <Trash2 size={10} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty state hint */}
        {otherMembers.length === 0 && (
          <div className="mb-6 p-3 bg-[#1e1e2e] border border-dashed border-[#2a2a3a] rounded-lg text-center">
            <div className="text-xs text-[#6b6b8d]">
              💡 Nie ma jeszcze „innych osób". Dodaj znajomych, kolegów, sąsiadów — tych,
              którzy pojawiają się w rozmowach ale nie są częścią rodziny. Każda kategoria ma swój kolor.
            </div>
          </div>
        )}

        {/* Add/Edit modal */}
        {showAddPerson && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setShowAddPerson(false)}>
            <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-6 max-w-md w-full" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-[#e0e0f0]">
                  {editingMember ? 'Edytuj osobę' : 'Dodaj nową osobę'}
                </h2>
                <button onClick={() => setShowAddPerson(false)} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
                  <X size={20} />
                </button>
              </div>

              {/* Live preview */}
              <div className="flex items-center gap-3 mb-4 p-3 bg-[#0f0f1a] rounded">
                <PixelAvatar
                  name={formName || '?'}
                  category={formCategory}
                  color={formColor || undefined}
                  role={formRole}
                  size={56}
                />
                <div>
                  <div className="text-sm text-[#e0e0f0] font-bold">{formName || '(imię)'}</div>
                  <div className="text-[10px] text-[#6b6b8d] font-mono">
                    {getCategoryLabel(formCategory)} · {formRole}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Imię</label>
                  <input type="text" value={formName} onChange={e => setFormName(e.target.value)}
                    placeholder="np. Kasia, Wujek Jan, Kolega Tomek"
                    className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0]" />
                </div>

                <div>
                  <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Kategoria (określa kolor)</label>
                  <div className="grid grid-cols-5 gap-1">
                    {(['family', 'friend', 'colleague', 'acquaintance', 'other'] as const).map(cat => {
                      const colors: Record<string, string> = {
                        family: '#00f5d4', friend: '#a855f7', colleague: '#60a5fa',
                        acquaintance: '#fbbf24', other: '#94a3b8',
                      };
                      return (
                        <button key={cat} onClick={() => setFormCategory(cat)}
                          className={`px-1 py-1.5 rounded text-[9px] font-mono border transition-all ${
                            formCategory === cat ? 'border-2' : 'border opacity-50 hover:opacity-100'
                          }`}
                          style={{ borderColor: colors[cat], color: colors[cat] }}>
                          {getCategoryLabel(cat)}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Rola</label>
                    <select value={formRole} onChange={e => setFormRole(e.target.value)}
                      className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-2 text-sm text-[#e0e0f0]">
                      <option value="other">Inna</option>
                      <option value="parent">Rodzic</option>
                      <option value="partner">Partnerka/Partner</option>
                      <option value="child">Dziecko</option>
                      <option value="friend">Przyjaciel/Przyjaciółka</option>
                      <option value="colleague">Kolega/Koleżanka</option>
                      <option value="relative">Krewny</option>
                      <option value="neighbour">Sąsiad</option>
                      <option value="teacher">Nauczyciel</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Wiek</label>
                    <input type="number" value={formAge} onChange={e => setFormAge(parseInt(e.target.value) || 0)}
                      min="0" max="120"
                      className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0]" />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">
                    Kolor (opcjonalny override, hex)
                  </label>
                  <div className="flex gap-2">
                    <input type="text" value={formColor} onChange={e => setFormColor(e.target.value)}
                      placeholder="np. #ff6b6b (puste = kolor kategorii)"
                      className="flex-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm font-mono text-[#e0e0f0]" />
                    {formColor && (
                      <div className="w-10 rounded border border-[#2a2a3a]" style={{ backgroundColor: formColor }} />
                    )}
                  </div>
                </div>

                <div>
                  <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">
                    Emoji (gdyby potrzebne, awatar pixelowy ma priorytet)
                  </label>
                  <input type="text" value={formEmoji} onChange={e => setFormEmoji(e.target.value)}
                    maxLength={4}
                    className="w-20 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-center text-lg text-[#e0e0f0]" />
                </div>
              </div>

              <div className="flex gap-2 mt-5">
                <button onClick={handleSubmit} disabled={saving || !formName.trim()}
                  className="flex-1 px-3 py-2 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-sm hover:bg-[#00f5d4]/20 disabled:opacity-50">
                  {saving ? 'Zapisywanie...' : (editingMember ? 'Zapisz zmiany' : 'Dodaj osobę')}
                </button>
                <button onClick={() => setShowAddPerson(false)}
                  className="px-3 py-2 bg-[#1e1e2e] border border-[#2a2a3a] text-[#a0a0c0] rounded text-sm hover:bg-[#2a2a3a]">
                  Anuluj
                </button>
              </div>

              {editingMember && editingMember.category !== 'family' && (
                <button onClick={() => handleDelete(editingMember)}
                  className="mt-3 w-full px-3 py-2 bg-[#ff6b6b]/5 border border-[#ff6b6b]/20 text-[#ff6b6b] rounded text-xs hover:bg-[#ff6b6b]/10">
                  <Trash2 size={12} className="inline mr-1" /> Usuń tę osobę
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// SETTINGS TAB — Provider, API Keys, Model
// ═══════════════════════════════════════════
type ProviderType = 'z-ai-sdk' | 'openrouter' | 'ollama' | 'gguf' | 'custom';

interface SettingsState {
  provider: ProviderType;
  openrouterKey: string;
  openrouterModel: string;
  ollamaUrl: string;
  ollamaModel: string;
  // GGUF
  ggufFilePath: string;
  ggufServerPath: string;
  ggufPort: number;
  ggufContextSize: number;
  ggufGpuLayers: number;
  customUrl: string;
  customKey: string;
  customModel: string;
  temperature: number;
  maxTokens: number;
  // Cost control
  topP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
  adaptiveMaxTokens?: boolean;
  maxTokensShort?: number;
  maxTokensLong?: number;
  shortPromptThreshold?: number;
  cacheSystemPrompt?: boolean;
  stopSequences?: string[];
  // Memory & ASR
  memoryFolder?: string;
  asrEngine: 'auto' | 'whisper' | 'z-ai-sdk';
  whisperUrl: string;
  whisperModel: string;
}

// ═══════════════════════════════════════════
// VAULT TAB — Obsidian-style notes browser
// ═══════════════════════════════════════════

interface VaultNoteData {
  id: string;
  noteType: string;
  title: string;
  frontmatter: string;
  content: string;
  tags: string;
  memberId?: string;
  emotion?: string;
  importance: number;
  isPinned: boolean;
  backlinkCount: number;
  updatedAt: string;
  createdAt: string;
}

function VaultTab() {
  const [notes, setNotes] = useState<VaultNoteData[]>([]);
  const [total, setTotal] = useState(0);
  const [selectedNote, setSelectedNote] = useState<VaultNoteData | null>(null);
  const [noteFilter, setNoteFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [backlinks, setBacklinks] = useState<VaultNoteData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingContent, setEditingContent] = useState('');
  const [showGraph, setShowGraph] = useState(false);

  const noteTypeLabels: Record<string, { label: string; color: string }> = {
    daily: { label: 'Daily Note', color: '#ffd93d' },
    note: { label: 'Notatka', color: '#00f5d4' },
    canvas: { label: 'Canvas', color: '#a855f7' },
    person: { label: 'Osoba', color: '#4ade80' },
    topic: { label: 'Temat', color: '#60a5fa' },
    dream: { label: 'Sen', color: '#c084fc' },
    story: { label: 'Historia', color: '#f472b6' },
    ritual: { label: 'Rytuał', color: '#f97316' },
  };

  useEffect(() => {
    loadNotes();
  }, [noteFilter, searchQuery]);

  async function loadNotes() {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (noteFilter !== 'all') params.set('type', noteFilter);
      if (searchQuery) params.set('search', searchQuery);
      const res = await fetch(`/api/vault?${params}`);
      if (!res.ok) { setIsLoading(false); return; }
      const data = await res.json();
      setNotes(data.notes || []);
      setTotal(data.total || 0);
    } catch (e) {
      console.error('Failed to load vault:', e);
    }
    setIsLoading(false);
  }

  async function selectNote(note: VaultNoteData) {
    setSelectedNote(note);
    setEditingContent(note.content);
    try {
      const res = await fetch(`/api/vault?id=${note.id}`);
      if (res.ok) {
        const data = await res.json();
        setBacklinks(data.backlinks || []);
      }
    } catch { /* skip */ }
  }

  async function saveNote() {
    if (!selectedNote) return;
    try {
      await fetch('/api/vault', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: selectedNote.id, content: editingContent }),
      });
      loadNotes();
    } catch (e) {
      console.error('Failed to save note:', e);
    }
  }

  async function createDailyNote() {
    try {
      const res = await fetch('/api/vault?action=daily', { method: 'GET' });
      if (res.ok) {
        const data = await res.json();
        if (data.note) selectNote(data.note);
        loadNotes();
      }
    } catch (e) {
      console.error('Failed to create daily note:', e);
    }
  }

  async function createNote() {
    const title = prompt('Tytuł notatki:');
    if (!title) return;
    try {
      const res = await fetch('/api/vault', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content: `# ${title}\n\n`, noteType: 'note' }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.note) selectNote(data.note);
        loadNotes();
      }
    } catch (e) {
      console.error('Failed to create note:', e);
    }
  }

  async function deleteNote(id: string) {
    if (!confirm('Usunąć notatkę?')) return;
    try {
      await fetch(`/api/vault?id=${id}`, { method: 'DELETE' });
      if (selectedNote?.id === id) setSelectedNote(null);
      loadNotes();
    } catch (e) {
      console.error('Failed to delete note:', e);
    }
  }

  // Render wikilinks in content as clickable spans
  function renderContent(text: string) {
    const parts = text.split(/(\[\[[^\]]+\]\])/g);
    return parts.map((part, i) => {
      const wikilinkMatch = part.match(/^\[\[([^\]]+)\]\]$/);
      if (wikilinkMatch) {
        return <span key={i} className="text-[#60a5fa] underline cursor-pointer hover:text-[#93c5fd]">{wikilinkMatch[1]}</span>;
      }
      return <span key={i}>{part}</span>;
    });
  }

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-pixel text-sm" style={{ color: '#e7d76e' }}>VAULT — NOTATKI BOKI</h2>
          <div className="flex items-center gap-2">
            <button onClick={createDailyNote} className="px-3 py-1.5 rounded bg-[#ffd93d]/10 border border-[#ffd93d]/30 text-[#ffd93d] text-xs font-mono hover:bg-[#ffd93d]/20 transition-all">
              + Daily Note
            </button>
            <button onClick={createNote} className="px-3 py-1.5 rounded bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] text-xs font-mono hover:bg-[#00f5d4]/20 transition-all">
              + Nowa
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 mb-4">
          <div className="flex-1 relative">
            <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b6b8d]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Szukaj w notatkach..."
              className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#ffd93d]/50 font-mono"
            />
          </div>
          <select
            value={noteFilter}
            onChange={e => setNoteFilter(e.target.value)}
            className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-2 py-1.5 text-xs text-[#e0e0f0] focus:outline-none focus:border-[#ffd93d]/50 font-mono"
          >
            <option value="all">Wszystkie</option>
            <option value="daily">Daily Notes</option>
            <option value="person">Osoby</option>
            <option value="note">Notatki</option>
            <option value="topic">Tematy</option>
            <option value="dream">Sny</option>
            <option value="story">Historie</option>
            <option value="ritual">Rytuały</option>
          </select>
        </div>

        {/* Two-column layout: list | editor */}
        <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-4">
          {/* Notes list */}
          <div className="space-y-1 max-h-[calc(100vh-220px)] overflow-y-auto">
            {isLoading ? (
              <div className="text-center py-8 text-[#6b6b8d] text-xs font-mono">Ładowanie...</div>
            ) : notes.length === 0 ? (
              <div className="text-center py-8 text-[#6b6b8d] text-xs font-mono">Brak notatek. Stwórz Daily Note!</div>
            ) : (
              notes.map(note => {
                const typeInfo = noteTypeLabels[note.noteType] || { label: note.noteType, color: '#6b6b8d' };
                const isSelected = selectedNote?.id === note.id;
                return (
                  <button
                    key={note.id}
                    onClick={() => selectNote(note)}
                    className={`w-full text-left p-2.5 rounded-lg border transition-all ${
                      isSelected
                        ? 'bg-[#ffd93d]/10 border-[#ffd93d]/30'
                        : 'bg-[#1e1e2e] border-[#2a2a3a] hover:border-[#ffd93d]/20'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded" style={{ backgroundColor: typeInfo.color + '20', color: typeInfo.color }}>
                        {typeInfo.label}
                      </span>
                      {note.isPinned && <span className="text-[9px] text-[#ffd93d]">📌</span>}
                      <span className="text-[8px] text-[#6b6b8d] font-mono ml-auto">{new Date(note.updatedAt).toLocaleDateString('pl-PL')}</span>
                    </div>
                    <div className="text-xs text-[#e0e0f0] font-mono truncate">{note.title}</div>
                    {note.emotion && (
                      <div className="text-[9px] text-[#6b6b8d] font-mono mt-0.5">emocja: {note.emotion}</div>
                    )}
                  </button>
                );
              })
            )}
            <div className="text-[9px] text-[#6b6b8d] font-mono text-center mt-2">{total} notatek</div>
          </div>

          {/* Note editor / viewer */}
          <div className="min-h-[400px]">
            {selectedNote ? (
              <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg overflow-hidden">
                {/* Note header */}
                <div className="px-4 py-2 border-b border-[#2a2a3a] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-[#e0e0f0] font-mono">{selectedNote.title}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded" style={{
                      backgroundColor: (noteTypeLabels[selectedNote.noteType]?.color || '#6b6b8d') + '20',
                      color: noteTypeLabels[selectedNote.noteType]?.color || '#6b6b8d'
                    }}>
                      {noteTypeLabels[selectedNote.noteType]?.label || selectedNote.noteType}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={saveNote} className="px-2 py-1 rounded bg-[#00f5d4]/10 text-[#00f5d4] text-[10px] font-mono hover:bg-[#00f5d4]/20">Zapisz</button>
                    <button onClick={() => deleteNote(selectedNote.id)} className="px-2 py-1 rounded bg-[#ff6b6b]/10 text-[#ff6b6b] text-[10px] font-mono hover:bg-[#ff6b6b]/20">Usuń</button>
                  </div>
                </div>

                {/* Frontmatter preview */}
                {selectedNote.frontmatter && selectedNote.frontmatter !== '{}' && (
                  <div className="px-4 py-2 bg-[#14141f] border-b border-[#2a2a3a]">
                    <div className="text-[9px] text-[#6b6b8d] font-mono mb-1">YAML Frontmatter:</div>
                    <pre className="text-[10px] text-[#ffd93d] font-mono whitespace-pre-wrap">
                      {(() => { try { const fm = JSON.parse(selectedNote.frontmatter); return Object.entries(fm).map(([k,v]) => `${k}: ${JSON.stringify(v)}`).join('\n'); } catch { return selectedNote.frontmatter; } })()}
                    </pre>
                  </div>
                )}

                {/* Content editor */}
                <div className="p-4">
                  <textarea
                    value={editingContent}
                    onChange={e => setEditingContent(e.target.value)}
                    className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded-lg p-3 text-xs text-[#e0e0f0] font-mono min-h-[300px] resize-y focus:outline-none focus:border-[#ffd93d]/50"
                    placeholder="Markdown z [[wikilinks]]..."
                  />
                </div>

                {/* Backlinks */}
                {backlinks.length > 0 && (
                  <div className="px-4 py-2 border-t border-[#2a2a3a]">
                    <div className="text-[9px] text-[#6b6b8d] font-mono mb-1">Backlinks ({backlinks.length}):</div>
                    <div className="flex flex-wrap gap-1">
                      {backlinks.map(bl => (
                        <button
                          key={bl.id}
                          onClick={() => selectNote(bl as VaultNoteData)}
                          className="text-[9px] px-2 py-0.5 rounded bg-[#4a90d9]/10 text-[#4a90d9] font-mono hover:bg-[#4a90d9]/20"
                        >
                          {bl.title}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tags */}
                {selectedNote.tags && (() => { try { const t = JSON.parse(selectedNote.tags); return t.length > 0; } catch { return false; } })() && (
                  <div className="px-4 py-2 border-t border-[#2a2a3a]">
                    <div className="flex flex-wrap gap-1">
                      {JSON.parse(selectedNote.tags).map((tag: string) => (
                        <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-[#8899aa]/10 text-[#8899aa] font-mono">#{tag}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-[#6b6b8d] text-xs font-mono">
                Wybierz notatkę z listy lub stwórz nową
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// VAULT SECTION — embeddable version of VaultTab, shown inside SettingsTab
// ═══════════════════════════════════════════
function VaultSection() {
  const [expanded, setExpanded] = useState(false);
  const [notes, setNotes] = useState<VaultNoteData[]>([]);
  const [total, setTotal] = useState(0);
  const [selectedNote, setSelectedNote] = useState<VaultNoteData | null>(null);
  const [noteFilter, setNoteFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [backlinks, setBacklinks] = useState<VaultNoteData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [editingContent, setEditingContent] = useState('');

  const noteTypeLabels: Record<string, { label: string; color: string }> = {
    daily: { label: 'Daily Note', color: '#ffd93d' },
    note: { label: 'Notatka', color: '#00f5d4' },
    canvas: { label: 'Canvas', color: '#a855f7' },
    person: { label: 'Osoba', color: '#4ade80' },
    topic: { label: 'Temat', color: '#60a5fa' },
    dream: { label: 'Sen', color: '#c084fc' },
    story: { label: 'Historia', color: '#f472b6' },
    ritual: { label: 'Rytuał', color: '#f97316' },
  };

  useEffect(() => {
    if (expanded) loadNotes();
  }, [expanded, noteFilter, searchQuery]);

  async function loadNotes() {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (noteFilter !== 'all') params.set('type', noteFilter);
      if (searchQuery) params.set('search', searchQuery);
      const res = await fetch(`/api/vault?${params}`);
      if (!res.ok) { setIsLoading(false); return; }
      const data = await res.json();
      setNotes(data.notes || []);
      setTotal(data.total || 0);
    } catch (e) {
      console.error('Failed to load vault:', e);
    }
    setIsLoading(false);
  }

  async function selectNote(note: VaultNoteData) {
    setSelectedNote(note);
    setEditingContent(note.content);
    try {
      const res = await fetch(`/api/vault?id=${note.id}`);
      if (res.ok) {
        const data = await res.json();
        setBacklinks(data.backlinks || []);
      }
    } catch { /* skip */ }
  }

  async function saveNote() {
    if (!selectedNote) return;
    try {
      await fetch('/api/vault', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: selectedNote.id, content: editingContent }),
      });
      loadNotes();
    } catch (e) {
      console.error('Failed to save note:', e);
    }
  }

  async function createDailyNote() {
    try {
      const res = await fetch('/api/vault?action=daily', { method: 'GET' });
      if (res.ok) {
        const data = await res.json();
        if (data.note) selectNote(data.note);
        loadNotes();
      }
    } catch (e) {
      console.error('Failed to create daily note:', e);
    }
  }

  async function createNote() {
    const title = prompt('Tytuł notatki:');
    if (!title) return;
    try {
      const res = await fetch('/api/vault', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content: `# ${title}\n\n`, noteType: 'note' }),
      });
      if (res.ok) {
        loadNotes();
      }
    } catch (e) {
      console.error('Failed to create note:', e);
    }
  }

  async function deleteNote(id: string) {
    if (!confirm('Usunąć notatkę?')) return;
    try {
      await fetch(`/api/vault?id=${id}`, { method: 'DELETE' });
      if (selectedNote?.id === id) setSelectedNote(null);
      loadNotes();
    } catch (e) {
      console.error('Failed to delete note:', e);
    }
  }

  return (
    <div className="mb-6 border border-[#ffd93d]/30 rounded-lg overflow-hidden">
      {/* Header — click to expand/collapse */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-4 py-3 bg-[#1e1e2e] hover:bg-[#252535] transition-colors"
      >
        <div className="flex items-center gap-2">
          <BookOpen size={16} className="text-[#ffd93d]" />
          <span className="font-pixel text-xs" style={{ color: '#e7d76e' }}>VAULT — NOTATKI BOKI</span>
          <span className="text-[9px] text-[#6b6b8d] font-mono">{total} notatek</span>
        </div>
        <span className="text-[#6b6b8d] text-xs">{expanded ? '▼' : '▶'}</span>
      </button>

      {expanded && (
        <div className="p-3 bg-[#0f0f1a]">
          {/* Action buttons */}
          <div className="flex items-center gap-2 mb-3">
            <button onClick={createDailyNote} className="px-3 py-1.5 rounded bg-[#ffd93d]/10 border border-[#ffd93d]/30 text-[#ffd93d] text-xs font-mono hover:bg-[#ffd93d]/20 transition-all">
              + Daily Note
            </button>
            <button onClick={createNote} className="px-3 py-1.5 rounded bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] text-xs font-mono hover:bg-[#00f5d4]/20 transition-all">
              + Nowa
            </button>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex-1 relative">
              <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#6b6b8d]" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Szukaj w notatkach..."
                className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#ffd93d]/50 font-mono"
              />
            </div>
            <select
              value={noteFilter}
              onChange={e => setNoteFilter(e.target.value)}
              className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-2 py-1.5 text-xs text-[#e0e0f0] focus:outline-none focus:border-[#ffd93d]/50 font-mono"
            >
              <option value="all">Wszystkie</option>
              <option value="daily">Daily Notes</option>
              <option value="person">Osoby</option>
              <option value="note">Notatki</option>
              <option value="topic">Tematy</option>
              <option value="dream">Sny</option>
              <option value="story">Historie</option>
              <option value="ritual">Rytuały</option>
            </select>
          </div>

          {/* Two-column: list | editor */}
          <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
            {/* Notes list */}
            <div className="space-y-1 max-h-[400px] overflow-y-auto pr-1">
              {isLoading ? (
                <div className="text-center py-6 text-[#6b6b8d] text-xs font-mono">Ładowanie...</div>
              ) : notes.length === 0 ? (
                <div className="text-center py-6 text-[#6b6b8d] text-xs font-mono">Brak notatek. Stwórz Daily Note!</div>
              ) : (
                notes.map(note => {
                  const typeInfo = noteTypeLabels[note.noteType] || { label: note.noteType, color: '#6b6b8d' };
                  const isSelected = selectedNote?.id === note.id;
                  return (
                    <button
                      key={note.id}
                      onClick={() => selectNote(note)}
                      className={`w-full text-left p-2 rounded-lg border transition-all ${
                        isSelected
                          ? 'bg-[#ffd93d]/10 border-[#ffd93d]/30'
                          : 'bg-[#1e1e2e] border-[#2a2a3a] hover:border-[#ffd93d]/20'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="text-[8px] font-mono px-1 py-0.5 rounded" style={{ backgroundColor: typeInfo.color + '20', color: typeInfo.color }}>
                          {typeInfo.label}
                        </span>
                        {note.isPinned && <span className="text-[9px] text-[#ffd93d]">📌</span>}
                        <span className="text-[8px] text-[#6b6b8d] font-mono ml-auto">{new Date(note.updatedAt).toLocaleDateString('pl-PL')}</span>
                      </div>
                      <div className="text-[11px] text-[#e0e0f0] font-mono truncate">{note.title}</div>
                    </button>
                  );
                })
              )}
            </div>

            {/* Editor / viewer */}
            <div className="min-h-[300px]">
              {selectedNote ? (
                <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg overflow-hidden">
                  <div className="px-3 py-2 border-b border-[#2a2a3a] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-[#e0e0f0] font-mono">{selectedNote.title}</span>
                      <span className="text-[8px] font-mono px-1.5 py-0.5 rounded" style={{
                        backgroundColor: (noteTypeLabels[selectedNote.noteType]?.color || '#6b6b8d') + '20',
                        color: noteTypeLabels[selectedNote.noteType]?.color || '#6b6b8d'
                      }}>
                        {noteTypeLabels[selectedNote.noteType]?.label || selectedNote.noteType}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button onClick={saveNote} className="px-2 py-1 rounded bg-[#00f5d4]/10 text-[#00f5d4] text-[10px] font-mono hover:bg-[#00f5d4]/20">Zapisz</button>
                      <button onClick={() => deleteNote(selectedNote.id)} className="px-2 py-1 rounded bg-[#ff6b6b]/10 text-[#ff6b6b] text-[10px] font-mono hover:bg-[#ff6b6b]/20">Usuń</button>
                    </div>
                  </div>

                  <div className="p-3">
                    <textarea
                      value={editingContent}
                      onChange={e => setEditingContent(e.target.value)}
                      className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded-lg p-2 text-xs text-[#e0e0f0] font-mono min-h-[220px] resize-y focus:outline-none focus:border-[#ffd93d]/50"
                      placeholder="Markdown z [[wikilinks]]..."
                    />
                  </div>

                  {backlinks.length > 0 && (
                    <div className="px-3 py-2 border-t border-[#2a2a3a]">
                      <div className="text-[9px] text-[#6b6b8d] font-mono mb-1">Backlinks ({backlinks.length}):</div>
                      <div className="flex flex-wrap gap-1">
                        {backlinks.map(bl => (
                          <button
                            key={bl.id}
                            onClick={() => selectNote(bl as VaultNoteData)}
                            className="text-[9px] px-2 py-0.5 rounded bg-[#4a90d9]/10 text-[#4a90d9] font-mono hover:bg-[#4a90d9]/20"
                          >
                            {bl.title}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-[#6b6b8d] text-xs font-mono py-8">
                  Wybierz notatkę z listy lub stwórz nową
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SettingsTab() {
  const { faceStyle, setFaceStyle } = useAppStore();
  const [settings, setSettings] = useState<SettingsState>({
    provider: 'openrouter',
    openrouterKey: '',
    openrouterModel: 'openai/gpt-oss-120b',
    ollamaUrl: 'http://localhost:11434',
    ollamaModel: 'llama3',
    ggufFilePath: '',
    ggufServerPath: '',
    ggufPort: 8080,
    ggufContextSize: 4096,
    ggufGpuLayers: -1,
    customUrl: '',
    customKey: '',
    customModel: '',
    temperature: 0.7,
    maxTokens: 1500,
    topP: 0.95,
    frequencyPenalty: 0,
    presencePenalty: 0,
    adaptiveMaxTokens: true,
    maxTokensShort: 256,
    maxTokensLong: 1500,
    shortPromptThreshold: 80,
    cacheSystemPrompt: true,
    stopSequences: [],
    asrEngine: 'auto',
    whisperUrl: 'http://127.0.0.1:5100',
    whisperModel: 'medium',
  });
  const [showKeys, setShowKeys] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [ollamaModels, setOllamaModels] = useState<Array<{
    name: string;
    size: number;
    family?: string;
    parameterSize?: string;
    quantization?: string;
    modifiedAt?: string;
  }>>([]);
  const [ollamaRunning, setOllamaRunning] = useState<Array<{ name: string; sizeVRam: number }>>([]);
  const [ollamaStatus, setOllamaStatus] = useState<{ reachable: boolean; serverVersion?: string; error?: string } | null>(null);
  const [ollamaLoading, setOllamaLoading] = useState(false);
  const [ollamaPullName, setOllamaPullName] = useState('');
  const [ollamaPulling, setOllamaPulling] = useState(false);
  const [ollamaPullResult, setOllamaPullResult] = useState<{ ok: boolean; message: string } | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/settings');
        if (!res.ok) return;
        const data = await res.json();
        if (data.settings) {
          setSettings(prev => ({
            ...prev,
            ...data.settings,
            provider: data.settings.provider || 'openrouter',
            openrouterKey: data.settings.openrouterKey || '',
            openrouterModel: data.settings.openrouterModel || 'openai/gpt-oss-120b',
            ollamaUrl: data.settings.ollamaUrl || 'http://localhost:11434',
            ollamaModel: data.settings.ollamaModel || 'llama3',
            ggufFilePath: data.settings.ggufFilePath || '',
            ggufServerPath: data.settings.ggufServerPath || '',
            ggufPort: data.settings.ggufPort || 8080,
            ggufContextSize: data.settings.ggufContextSize || 4096,
            ggufGpuLayers: data.settings.ggufGpuLayers ?? -1,
            customUrl: data.settings.customUrl || '',
            customKey: data.settings.customKey || '',
            customModel: data.settings.customModel || '',
          }));
        }
      } catch (e) {
        console.error('Failed to load settings:', e);
      }
      setLoaded(true);
    }
    load();
  }, []);

  // Fetch Ollama models with full details + running + status
  const fetchOllamaModels = async (url?: string) => {
    setOllamaLoading(true);
    try {
      const targetUrl = url || settings.ollamaUrl;
      const res = await fetch(`/api/ollama-models?url=${encodeURIComponent(targetUrl)}&detail=1`);
      if (!res.ok) {
        setOllamaModels([]);
        setOllamaRunning([]);
        setOllamaStatus({ reachable: false, error: `HTTP ${res.status}` });
        return;
      }
      const data = await res.json();
      setOllamaModels(data.models || []);
      setOllamaRunning(data.running || []);
      setOllamaStatus(data.status || null);
    } catch (e) {
      setOllamaModels([]);
      setOllamaRunning([]);
      setOllamaStatus({ reachable: false, error: e instanceof Error ? e.message : 'Błąd połączenia' });
    }
    setOllamaLoading(false);
  };

  const pullOllamaModel = async () => {
    if (!ollamaPullName.trim()) return;
    setOllamaPulling(true);
    setOllamaPullResult(null);
    try {
      const res = await fetch('/api/ollama-models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: settings.ollamaUrl, model: ollamaPullName.trim() }),
      });
      const data = await res.json();
      setOllamaPullResult(data);
      if (data.ok) {
        setOllamaPullName('');
        fetchOllamaModels();
      }
    } catch (e) {
      setOllamaPullResult({ ok: false, message: e instanceof Error ? e.message : 'Błąd pobierania' });
    }
    setOllamaPulling(false);
    setTimeout(() => setOllamaPullResult(null), 6000);
  };

  // Format bytes to human-readable size
  const formatBytes = (bytes: number): string => {
    if (!bytes || bytes === 0) return '?';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let n = bytes;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  };

  useEffect(() => {
    if (settings.provider === 'ollama') {
      fetchOllamaModels();
    }
  }, [settings.provider, settings.ollamaUrl]);

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      if (!res.ok) {
        setTestResult({ ok: false, message: 'Błąd zapisu' });
        setSaving(false);
        return;
      }
      const data = await res.json();
      if (data.ok) {
        setTestResult({ ok: true, message: 'Ustawienia zapisane!' });
      } else {
        setTestResult({ ok: false, message: data.error || 'Błąd zapisu' });
      }
    } catch {
      setTestResult({ ok: false, message: 'Błąd połączenia' });
    }
    setSaving(false);
    setTimeout(() => setTestResult(null), 3000);
  };

  const test = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      const res = await fetch('/api/settings', { method: 'PUT' });
      if (!res.ok) {
        setTestResult({ ok: false, message: 'Błąd testu połączenia' });
        setTesting(false);
        return;
      }
      const data = await res.json();
      setTestResult({ ok: data.ok, message: data.message });
    } catch {
      setTestResult({ ok: false, message: 'Błąd testu połączenia' });
    }
    setTesting(false);
    setTimeout(() => setTestResult(null), 5000);
  };

  const update = (key: keyof SettingsState, value: string | number | boolean | string[]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const providers: { id: ProviderType; label: string; icon: React.ReactNode; desc: string }[] = [
    { id: 'openrouter', label: 'OpenRouter', icon: <Globe size={16} />, desc: 'Dostęp do setek modeli: GPT, Claude, Llama, Mistral' },
    { id: 'ollama', label: 'Ollama (lokalny)', icon: <Cpu size={16} />, desc: 'Lokalne modele na Twoim komputerze. Darmowe, prywatne.' },
    { id: 'gguf', label: 'Plik GGUF (z dysku)', icon: <HardDrive size={16} />, desc: 'Wskaż dowolny plik .gguf — BOKA uruchomi go przez llama.cpp' },
    { id: 'z-ai-sdk', label: 'Z-AI SDK', icon: <Zap size={16} />, desc: 'Domyślny silnik AI' },
    { id: 'custom', label: 'Własny API', icon: <Server size={16} />, desc: 'LM Studio, vLLM — dowolny serwer OpenAI-compat' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="font-pixel text-sm mb-4" style={{ color: '#e7d76e' }}>USTAWIENIA BOKI</h2>

        {/* ── VAULT — NOTATKI BOKI (przeniesione z osobnej zakładki) ── */}
        <VaultSection />

        {/* ── VISUAL STYLE SELECTOR ── */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={16} className="text-[#a855f7]" />
            <span className="text-sm font-mono text-[#e0e0f0]">Wygląd Boki</span>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            {([
              { id: 'plasma' as FaceStyle, label: 'Plazma', desc: 'Luminacyjna kula, kolory rozmywają się na czarnym', icon: <Sparkles size={16} /> },
              { id: 'water' as FaceStyle, label: 'Tafla wody', desc: 'Kółka fal na wodzie, neonowe okręgi', icon: <Activity size={16} /> },
              { id: 'obsidian' as FaceStyle, label: 'Obsidian', desc: 'Kropki i połączenia jak w grafie wiedzy', icon: <CircleDot size={16} /> },
            ]).map(s => (
              <button
                key={s.id}
                onClick={() => setFaceStyle(s.id)}
                className={`p-3 rounded-lg border text-left transition-all ${
                  faceStyle === s.id
                    ? 'bg-[#a855f7]/10 border-[#a855f7]/50 text-[#a855f7]'
                    : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d] hover:border-[#a855f7]/30'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {s.icon}
                  <span className="text-sm font-mono">{s.label}</span>
                </div>
                <div className="text-[10px] font-mono opacity-70">{s.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Server size={16} className="text-[#00f5d4]" />
            <span className="text-sm font-mono text-[#e0e0f0]">Dostawca AI</span>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {providers.map(p => (
              <button
                key={p.id}
                onClick={() => update('provider', p.id)}
                className={`p-3 rounded-lg border text-left transition-all ${
                  settings.provider === p.id
                    ? 'bg-[#00f5d4]/10 border-[#00f5d4]/50 text-[#00f5d4]'
                    : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d] hover:border-[#00f5d4]/30'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {p.icon}
                  <span className="text-sm font-mono">{p.label}</span>
                </div>
                <div className="text-[10px] font-mono opacity-70">{p.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {settings.provider === 'openrouter' && (
          <div className="mb-6 space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <Key size={16} className="text-[#60a5fa]" />
              <span className="text-sm font-mono text-[#e0e0f0]">Konfiguracja OpenRouter</span>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Klucz API</label>
              <div className="relative">
                <input
                  type={showKeys ? 'text' : 'password'}
                  value={settings.openrouterKey}
                  onChange={e => update('openrouterKey', e.target.value)}
                  placeholder="sk-or-v1-..."
                  className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 pr-10 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono"
                />
                <button type="button" onClick={() => setShowKeys(!showKeys)} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#6b6b8d] hover:text-[#e0e0f0]">
                  {showKeys ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Model</label>
              <input
                type="text"
                value={settings.openrouterModel}
                onChange={e => update('openrouterModel', e.target.value)}
                placeholder="openai/gpt-oss-120b"
                className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono"
              />
            </div>
          </div>
        )}

        {settings.provider === 'ollama' && (
          <div className="mb-6 space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <Cpu size={16} className="text-[#4ade80]" />
              <span className="text-sm font-mono text-[#e0e0f0]">Konfiguracja Ollama</span>
            </div>

            {/* Server URL + status */}
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">URL serwera Ollama</label>
              <div className="flex gap-2">
                <input type="text" value={settings.ollamaUrl} onChange={e => update('ollamaUrl', e.target.value)} placeholder="http://localhost:11434" className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
                <button onClick={() => fetchOllamaModels()} disabled={ollamaLoading} className="px-3 py-2 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] hover:border-[#00f5d4]/30 text-xs font-mono disabled:opacity-50">
                  {ollamaLoading ? '...' : 'Odśwież'}
                </button>
              </div>
            </div>

            {/* Server status badge */}
            {ollamaStatus && (
              <div className={`text-[11px] font-mono px-3 py-2 rounded-lg border ${
                ollamaStatus.reachable
                  ? 'bg-[#4ade80]/10 border-[#4ade80]/30 text-[#4ade80]'
                  : 'bg-[#ef4444]/10 border-[#ef4444]/30 text-[#ef4444]'
              }`}>
                {ollamaStatus.reachable ? (
                  <span>
                    ✓ Serwer Ollama działa
                    {ollamaStatus.serverVersion && <span className="opacity-60"> · {ollamaStatus.serverVersion}</span>}
                    {' · '}{ollamaModels.length} modeli
                    {ollamaRunning.length > 0 && <span className="text-[#fbbf24]"> · {ollamaRunning.length} załadowanych w RAM</span>}
                  </span>
                ) : (
                  <span>✗ Serwer nieosiągalny: {ollamaStatus.error || 'sprawdź czy Ollama działa'}</span>
                )}
              </div>
            )}

            {/* Running models (loaded in RAM) */}
            {ollamaRunning.length > 0 && (
              <div className="bg-[#fbbf24]/5 border border-[#fbbf24]/20 rounded-lg p-3">
                <div className="text-[10px] font-mono text-[#fbbf24] mb-2 uppercase tracking-wider">⚡ Załadowane w pamięci (gotowe do rozmowy)</div>
                <div className="flex flex-wrap gap-1.5">
                  {ollamaRunning.map(m => (
                    <span key={m.name} className="text-[11px] font-mono px-2 py-1 rounded bg-[#fbbf24]/10 border border-[#fbbf24]/30 text-[#fbbf24]">
                      {m.name} {m.sizeVRam > 0 && <span className="opacity-60">· {formatBytes(m.sizeVRam)} VRAM</span>}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Model picker — rich cards instead of dropdown */}
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-2 block">
                Wybierz model {ollamaModels.length > 0 && <span className="opacity-60">({ollamaModels.length} dostępnych)</span>}
              </label>

              {ollamaLoading ? (
                <div className="text-[11px] font-mono text-[#6b6b8d] py-4 text-center">Szukam modeli...</div>
              ) : ollamaModels.length > 0 ? (
                <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                  {ollamaModels.map(m => {
                    const selected = settings.ollamaModel === m.name;
                    const isRunning = ollamaRunning.some(r => r.name === m.name);
                    return (
                      <button
                        key={m.name}
                        onClick={() => update('ollamaModel', m.name)}
                        className={`w-full text-left p-2.5 rounded-lg border transition-all ${
                          selected
                            ? 'bg-[#4ade80]/10 border-[#4ade80]/50'
                            : 'bg-[#1e1e2e] border-[#2a2a3a] hover:border-[#4ade80]/30'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className={`text-sm font-mono truncate ${selected ? 'text-[#4ade80]' : 'text-[#e0e0f0]'}`}>{m.name}</span>
                            {isRunning && (
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#fbbf24]/20 text-[#fbbf24] shrink-0">W RAM</span>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-[#6b6b8d] shrink-0">{formatBytes(m.size)}</span>
                        </div>
                        {(m.family || m.parameterSize || m.quantization) && (
                          <div className="flex items-center gap-2 mt-1 text-[10px] font-mono text-[#6b6b8d]">
                            {m.family && <span>🧬 {m.family}</span>}
                            {m.parameterSize && <span>📐 {m.parameterSize}</span>}
                            {m.quantization && <span>🗜️ {m.quantization}</span>}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3">
                  <input type="text" value={settings.ollamaModel} onChange={e => update('ollamaModel', e.target.value)} placeholder="llama3" className="w-full bg-[#0f0f17] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono mb-2" />
                  <div className="text-[10px] text-[#6b6b8d] font-mono">
                    Nie wykryto modeli. Uruchom Ollamę i pobierz model poniżej, albo w terminalu: <code className="text-[#4ade80]">ollama pull llama3</code>
                  </div>
                </div>
              )}
            </div>

            {/* Pull new model helper */}
            <div className="bg-[#0f0f17] border border-[#2a2a3a] rounded-lg p-3">
              <div className="text-[10px] font-mono text-[#6b6b8d] mb-2 uppercase tracking-wider">⬇️ Pobierz nowy model z rejestru Ollama</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={ollamaPullName}
                  onChange={e => setOllamaPullName(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !ollamaPulling) pullOllamaModel(); }}
                  placeholder="np. llama3, mistral, gemma3, qwen2.5, phi4..."
                  disabled={ollamaPulling}
                  className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#4ade80]/50 font-mono disabled:opacity-50"
                />
                <button
                  onClick={pullOllamaModel}
                  disabled={ollamaPulling || !ollamaPullName.trim()}
                  className="px-4 py-2 rounded bg-[#4ade80]/10 border border-[#4ade80]/40 text-[#4ade80] hover:bg-[#4ade80]/20 text-xs font-mono disabled:opacity-40"
                >
                  {ollamaPulling ? 'Pobieranie...' : 'Pobierz'}
                </button>
              </div>
              <div className="text-[10px] text-[#6b6b8d] font-mono mt-2">
                Popularne modele: <button onClick={() => setOllamaPullName('llama3.1')} className="text-[#4ade80] hover:underline">llama3.1</button>
                {' · '}<button onClick={() => setOllamaPullName('mistral')} className="text-[#4ade80] hover:underline">mistral</button>
                {' · '}<button onClick={() => setOllamaPullName('gemma3')} className="text-[#4ade80] hover:underline">gemma3</button>
                {' · '}<button onClick={() => setOllamaPullName('qwen2.5')} className="text-[#4ade80] hover:underline">qwen2.5</button>
                {' · '}<button onClick={() => setOllamaPullName('phi4')} className="text-[#4ade80] hover:underline">phi4</button>
                {' · '}<button onClick={() => setOllamaPullName('deepseek-r1')} className="text-[#4ade80] hover:underline">deepseek-r1</button>
              </div>
              {ollamaPullResult && (
                <div className={`text-[11px] font-mono mt-2 px-2 py-1 rounded ${
                  ollamaPullResult.ok ? 'text-[#4ade80] bg-[#4ade80]/10' : 'text-[#ef4444] bg-[#ef4444]/10'
                }`}>
                  {ollamaPullResult.ok ? '✓ ' : '✗ '}{ollamaPullResult.message}
                </div>
              )}
              <div className="text-[9px] text-[#6b6b8d]/70 font-mono mt-2">
                ⚠️ Pobieranie dużych modeli (np. 70B) może trwać wiele minut i wymaga kilkudziesięciu GB RAM/VRAM. Polecam modele 7B-13B na start.
              </div>
            </div>

            {/* Hint how to install Ollama if not running */}
            {ollamaStatus && !ollamaStatus.reachable && (
              <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 text-[11px] font-mono text-[#6b6b8d] space-y-1">
                <div className="text-[#e0e0f0]">Jak uruchomić Ollamę:</div>
                <div>1. Pobierz z <span className="text-[#00f5d4]">https://ollama.com/download</span></div>
                <div>2. Zainstaluj i uruchom aplikację Ollama</div>
                <div>3. W terminalu: <code className="text-[#4ade80]">ollama pull llama3</code></div>
                <div>4. Wróć tutaj i kliknij „Odśwież”</div>
              </div>
            )}
          </div>
        )}

        {settings.provider === 'gguf' && (
          <GgufSettings settings={settings} update={update} />
        )}

        {settings.provider === 'custom' && (
          <div className="mb-6 space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <Server size={16} className="text-[#a855f7]" />
              <span className="text-sm font-mono text-[#e0e0f0]">Własny serwer API</span>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">URL endpoint</label>
              <input type="text" value={settings.customUrl} onChange={e => update('customUrl', e.target.value)} placeholder="http://192.168.1.100:8080/v1" className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Klucz API (opcjonalny)</label>
              <input type={showKeys ? 'text' : 'password'} value={settings.customKey} onChange={e => update('customKey', e.target.value)} placeholder="opcjonalny" className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Model</label>
              <input type="text" value={settings.customModel} onChange={e => update('customModel', e.target.value)} placeholder="my-model" className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#00f5d4]/50 font-mono" />
            </div>
          </div>
        )}

        <div className="mb-6 space-y-3">
          <div className="flex items-center gap-2 mb-2">
            <Settings size={16} className="text-[#ffd93d]" />
            <span className="text-sm font-mono text-[#e0e0f0]">Parametry modelu</span>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Temperatura: {settings.temperature.toFixed(1)}</label>
              <input type="range" min="0" max="1.5" step="0.1" value={settings.temperature} onChange={e => update('temperature', parseFloat(e.target.value))} className="w-full accent-[#00f5d4]" />
              <div className="flex justify-between text-[10px] text-[#6b6b8d] font-mono"><span>Precyzyjny</span><span>Kreatywny</span></div>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Max tokenów: {settings.maxTokens}</label>
              <input type="range" min="256" max="4096" step="256" value={settings.maxTokens} onChange={e => update('maxTokens', parseInt(e.target.value))} className="w-full accent-[#00f5d4]" />
              <div className="flex justify-between text-[10px] text-[#6b6b8d] font-mono"><span>Krótkie</span><span>Długie</span></div>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Top-p: {(settings.topP ?? 0.95).toFixed(2)}</label>
              <input type="range" min="0.1" max="1" step="0.05" value={settings.topP ?? 0.95} onChange={e => update('topP', parseFloat(e.target.value))} className="w-full accent-[#00f5d4]" />
              <div className="flex justify-between text-[10px] text-[#6b6b8d] font-mono"><span>Fokus</span><span>Losowo</span></div>
            </div>
            <div>
              <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Frequency penalty: {(settings.frequencyPenalty ?? 0).toFixed(1)}</label>
              <input type="range" min="0" max="2" step="0.1" value={settings.frequencyPenalty ?? 0} onChange={e => update('frequencyPenalty', parseFloat(e.target.value))} className="w-full accent-[#fbbf24]" />
              <div className="flex justify-between text-[10px] text-[#6b6b8d] font-mono"><span>Brak</span><span>Unikaj powtórzeń</span></div>
            </div>
          </div>
        </div>

        {/* ── KONTROLA KOSZTÓW ── */}
        <div className="mb-6 space-y-3">
          <div className="flex items-center gap-2 mb-2">
            <Coins size={16} className="text-[#4ade80]" />
            <span className="text-sm font-mono text-[#e0e0f0]">Kontrola kosztów</span>
            <span className="text-[10px] text-[#6b6b8d]">— oszczędza kredyty / tokeny</span>
          </div>

          {/* Adaptive max_tokens */}
          <label className="flex items-start gap-2 cursor-pointer bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2.5">
            <input
              type="checkbox"
              checked={settings.adaptiveMaxTokens ?? true}
              onChange={e => update('adaptiveMaxTokens', e.target.checked)}
              className="mt-0.5 accent-[#4ade80]"
            />
            <div className="flex-1">
              <div className="text-sm text-[#e0e0f0] flex items-center gap-1">
                <Zap size={12} className="text-[#4ade80]" />
                Adaptacyjny max_tokens
              </div>
              <div className="text-[10px] text-[#6b6b8d] mt-0.5">
                Krótkie pytania (&lt; {settings.shortPromptThreshold ?? 80} znaków) używają {settings.maxTokensShort ?? 256} tokenów zamiast {settings.maxTokens}. Zapobiega błędom 402 na darmowych kontach.
              </div>
            </div>
          </label>

          {settings.adaptiveMaxTokens && (
            <div className="grid gap-3 md:grid-cols-3 pl-2">
              <div>
                <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Krótkie: {settings.maxTokensShort ?? 256}</label>
                <input type="range" min="64" max="1024" step="64" value={settings.maxTokensShort ?? 256} onChange={e => update('maxTokensShort', parseInt(e.target.value))} className="w-full accent-[#4ade80]" />
              </div>
              <div>
                <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Długie: {settings.maxTokensLong ?? 1500}</label>
                <input type="range" min="512" max="4096" step="256" value={settings.maxTokensLong ?? 1500} onChange={e => update('maxTokensLong', parseInt(e.target.value))} className="w-full accent-[#4ade80]" />
              </div>
              <div>
                <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Próg (znaki): {settings.shortPromptThreshold ?? 80}</label>
                <input type="range" min="20" max="300" step="10" value={settings.shortPromptThreshold ?? 80} onChange={e => update('shortPromptThreshold', parseInt(e.target.value))} className="w-full accent-[#4ade80]" />
              </div>
            </div>
          )}

          {/* Prompt cache */}
          <label className="flex items-start gap-2 cursor-pointer bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2.5">
            <input
              type="checkbox"
              checked={settings.cacheSystemPrompt ?? true}
              onChange={e => update('cacheSystemPrompt', e.target.checked)}
              className="mt-0.5 accent-[#4ade80]"
            />
            <div className="flex-1">
              <div className="text-sm text-[#e0e0f0] flex items-center gap-1">
                <Sparkles size={12} className="text-[#4ade80]" />
                Cache system promptu (~50% taniej)
              </div>
              <div className="text-[10px] text-[#6b6b8d] mt-0.5">
                Oznacza system prompt jako <code className="text-[#fbbf24]">cache_control: ephemeral</code>. OpenRouter / Anthropic liczą go raz, potem z 50% zniżką. Dla BOKA (duży soul + memory context) to oszczędność 30-50% na każdym zapytaniu.
              </div>
            </div>
          </label>

          {/* Stop sequences */}
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2.5">
            <div className="text-sm text-[#e0e0f0] flex items-center gap-1 mb-1">
              <Square size={12} className="text-[#fbbf24]" />
              Stop sequences
              <span className="text-[10px] text-[#6b6b8d] font-normal">— wymusza krótsze odpowiedzi (max 4)</span>
            </div>
            <input
              type="text"
              value={(settings.stopSequences || []).join(', ')}
              onChange={e => {
                const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean).slice(0, 4);
                update('stopSequences', arr);
              }}
              placeholder="np. \n\n\n (przecinek = nowy sekwens)"
              className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs font-mono text-[#e0e0f0]"
            />
            <div className="text-[10px] text-[#6b6b8d] mt-1">
              Np. <code className="text-[#fbbf24]">{'\\n\\n\\n'}</code> zatrzyma generowanie po 3 pustych liniach. Puste = wyłączone.
            </div>
          </div>
        </div>

        {/* ── ASR ENGINE SELECTOR ── */}
        <div className="mb-6 space-y-3">
          <div className="flex items-center gap-2 mb-2">
            <Mic size={16} className="text-[#ff6b6b]" />
            <span className="text-sm font-mono text-[#e0e0f0]">Rozpoznawanie mowy (ASR)</span>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            {([
              { id: 'auto' as const, label: 'Auto', desc: 'Whisper lokalny jeśli dostępny, inaczej chmura', icon: <Zap size={14} /> },
              { id: 'whisper' as const, label: 'Whisper (lokalny)', desc: 'Najlepsza jakość PL, wymaga serwera na :5100', icon: <Mic size={14} /> },
              { id: 'z-ai-sdk' as const, label: 'Chmura (Z-AI)', desc: 'Zawsze działa, wymaga internetu', icon: <Globe size={14} /> },
            ]).map(e => (
              <button
                key={e.id}
                onClick={() => update('asrEngine', e.id)}
                className={`p-3 rounded-lg border text-left transition-all ${
                  settings.asrEngine === e.id
                    ? 'bg-[#ff6b6b]/10 border-[#ff6b6b]/50 text-[#ff6b6b]'
                    : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d] hover:border-[#ff6b6b]/30'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {e.icon}
                  <span className="text-sm font-mono">{e.label}</span>
                </div>
                <div className="text-[10px] font-mono opacity-70">{e.desc}</div>
              </button>
            ))}
          </div>
          {(settings.asrEngine === 'whisper' || settings.asrEngine === 'auto') && (
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Whisper URL</label>
                <input type="text" value={settings.whisperUrl} onChange={e => update('whisperUrl', e.target.value)} placeholder="http://127.0.0.1:5100" className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#ff6b6b]/50 font-mono" />
              </div>
              <div>
                <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Model Whisper</label>
                <select value={settings.whisperModel} onChange={e => update('whisperModel', e.target.value)} className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] focus:outline-none focus:border-[#ff6b6b]/50 font-mono">
                  <option value="tiny">tiny — najszybszy, podstawowa jakość</option>
                  <option value="base">base — szybki, dobra jakość</option>
                  <option value="small">small — szybkość + jakość</option>
                  <option value="medium">medium — najlepsza jakość PL (zalecany)</option>
                  <option value="large-v3">large-v3 — maksymalna jakość (wolny)</option>
                </select>
              </div>
            </div>
          )}
          <div className="text-[10px] font-mono text-[#6b6b8d]">
            Uruchom Whisper: python3 scripts/whisper/whisper-server.py --model {settings.whisperModel}
          </div>
        </div>

        <div className="flex items-center gap-3 mb-4">
          <button onClick={save} disabled={saving} className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#00f5d4] text-[#0a0a0f] font-mono text-sm disabled:opacity-50 hover:bg-[#00dbc4] transition-all">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
            Zapisz
          </button>
          <button onClick={test} disabled={testing} className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a] text-[#e0e0f0] font-mono text-sm disabled:opacity-50 hover:border-[#00f5d4]/50 transition-all">
            {testing ? <Loader2 size={16} className="animate-spin" /> : <Wifi size={16} />}
            Test
          </button>
        </div>

        {testResult && (
          <div className={`p-3 rounded-lg border text-sm font-mono ${testResult.ok ? 'bg-[#4ade80]/10 border-[#4ade80]/30 text-[#4ade80]' : 'bg-[#ff6b6b]/10 border-[#ff6b6b]/30 text-[#ff6b6b]'}`}>
            <div className="flex items-center gap-2">
              {testResult.ok ? <CheckCircle size={16} /> : <XCircle size={16} />}
              {testResult.message}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// GGUF SETTINGS — wybór pliku .gguf z dysku
// ═══════════════════════════════════════════
function GgufSettings({ settings, update }: {
  settings: SettingsState;
  update: (key: keyof SettingsState, value: string | number) => void;
}) {
  const [ggufStatus, setGgufStatus] = useState<{ running: boolean; model: string; port: number; llamaServerDetected: string | null } | null>(null);
  const [ggufBusy, setGgufBusy] = useState<'start' | 'stop' | null>(null);
  const [ggufMessage, setGgufMessage] = useState<{ ok: boolean; message: string } | null>(null);
  const [detectedModels, setDetectedModels] = useState<string[]>([]);
  const [scanning, setScanning] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const serverInputRef = useRef<HTMLInputElement>(null);

  // Load status on mount + when provider switches to gguf
  const loadStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/gguf-server');
      if (res.ok) {
        const data = await res.json();
        setGgufStatus(data);
      }
    } catch { /* ignore */ }
  }, []);

  useEffect(() => { loadStatus(); }, [loadStatus]);

  // Scan for .gguf files in common locations
  const scanForModels = async () => {
    setScanning(true);
    try {
      const res = await fetch('/api/gguf-scan');
      if (res.ok) {
        const data = await res.json();
        setDetectedModels(data.files || []);
      }
    } catch { /* ignore */ }
    setScanning(false);
  };

  const startServer = async () => {
    setGgufBusy('start');
    setGgufMessage(null);
    try {
      // Save settings first so server reads latest config
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      const res = await fetch('/api/gguf-server', { method: 'POST' });
      const data = await res.json();
      setGgufMessage({ ok: !!data.ok, message: data.ok ? 'Serwer uruchomiony' : (data.error || 'Błąd uruchamiania') });
      loadStatus();
    } catch (e) {
      setGgufMessage({ ok: false, message: e instanceof Error ? e.message : 'Błąd' });
    }
    setGgufBusy(null);
    setTimeout(() => setGgufMessage(null), 6000);
  };

  const stopServer = async () => {
    setGgufBusy('stop');
    try {
      await fetch('/api/gguf-server', { method: 'DELETE' });
      setGgufMessage({ ok: true, message: 'Serwer zatrzymany' });
      loadStatus();
    } catch (e) {
      setGgufMessage({ ok: false, message: e instanceof Error ? e.message : 'Błąd' });
    }
    setGgufBusy(null);
    setTimeout(() => setGgufMessage(null), 4000);
  };

  const pickFile = () => fileInputRef.current?.click();
  const pickServer = () => serverInputRef.current?.click();

  const onFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In browser we can't get full path, but file.name is available
      // User must type the path manually OR we use file.path (Electron only)
      const filePath = (file as File & { path?: string }).path || file.name;
      update('ggufFilePath', filePath);
    }
  };

  const onServerPicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const filePath = (file as File & { path?: string }).path || file.name;
      update('ggufServerPath', filePath);
    }
  };

  return (
    <div className="mb-6 space-y-3">
      <div className="flex items-center gap-2 mb-2">
        <HardDrive size={16} className="text-[#fbbf24]" />
        <span className="text-sm font-mono text-[#e0e0f0]">Plik GGUF (lokalny przez llama.cpp)</span>
      </div>

      <div className="bg-[#fbbf24]/5 border border-[#fbbf24]/20 rounded-lg p-3 text-[11px] font-mono text-[#6b6b8d] leading-relaxed">
        <div className="text-[#e0e0f0] mb-1">Jak to działa?</div>
        Wskaż plik <code className="text-[#fbbf24]">.gguf</code> na dysku (np. z HuggingFace).
        BOKA uruchomi <code className="text-[#fbbf24]">llama-server</code> (z llama.cpp) w tle,
        który załaduje ten model i wystawi OpenAI-compat API na wybranym porcie.
        Pełna prywatność — model działa lokalnie, bez internetu.
      </div>

      {/* Plik GGUF */}
      <div>
        <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">📁 Plik modelu .gguf</label>
        <div className="flex gap-2">
          <input
            type="text"
            value={settings.ggufFilePath}
            onChange={e => update('ggufFilePath', e.target.value)}
            placeholder="C:\Models\llama-3-8b-instruct.Q4_K_M.gguf"
            className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#fbbf24]/50 font-mono"
          />
          <button
            onClick={pickFile}
            className="px-3 py-2 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] hover:border-[#fbbf24]/30 text-xs font-mono flex items-center gap-1"
            title="Wybierz plik (wymaga Electron/full path — w przeglądarce wpisz ścieżkę ręcznie)"
          >
            <FolderOpen size={14} /> Wybierz
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".gguf,.bin"
            onChange={onFilePicked}
            className="hidden"
          />
        </div>
        <div className="text-[10px] text-[#6b6b8d] font-mono mt-1">
          💡 Pobierz modele GGUF z <a href="https://huggingface.co/models?other=gguf" target="_blank" rel="noopener" className="text-[#fbbf24] hover:underline">HuggingFace</a>.
          Polecam kwantyzację <code className="text-[#fbbf24]">Q4_K_M</code> (dobry kompromis rozmiar/jakość).
        </div>
      </div>

      {/* Skanuj dysk w poszukiwaniu modeli */}
      <div>
        <button
          onClick={scanForModels}
          disabled={scanning}
          className="text-[11px] font-mono text-[#fbbf24] hover:underline disabled:opacity-50"
        >
          {scanning ? '🔍 Skanuję...' : '🔍 Skanuj dysk w poszukiwaniu plików .gguf'}
        </button>
        {detectedModels.length > 0 && (
          <div className="mt-2 space-y-1 max-h-40 overflow-y-auto">
            {detectedModels.map(p => (
              <button
                key={p}
                onClick={() => update('ggufFilePath', p)}
                className={`block w-full text-left text-[11px] font-mono px-2 py-1.5 rounded border ${
                  settings.ggufFilePath === p
                    ? 'bg-[#fbbf24]/10 border-[#fbbf24]/40 text-[#fbbf24]'
                    : 'bg-[#1e1e2e] border-[#2a2a3a] text-[#6b6b8d] hover:border-[#fbbf24]/30'
                }`}
                title={p}
              >
                📦 {p.split(/[\\/]/).pop()} <span className="opacity-60">— {p}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Ścieżka do llama-server */}
      <div>
        <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">
          ⚙️ Plik wykonywalny llama-server <span className="opacity-60">(opcjonalny — auto-detekcja)</span>
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={settings.ggufServerPath}
            onChange={e => update('ggufServerPath', e.target.value)}
            placeholder="C:\llama.cpp\build\bin\Release\llama-server.exe"
            className="flex-1 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#6b6b8d] focus:outline-none focus:border-[#fbbf24]/50 font-mono"
          />
          <button
            onClick={pickServer}
            className="px-3 py-2 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] hover:border-[#fbbf24]/30 text-xs font-mono flex items-center gap-1"
          >
            <FolderOpen size={14} /> Wybierz
          </button>
          <input
            ref={serverInputRef}
            type="file"
            accept=".exe,.bin,llama-server"
            onChange={onServerPicked}
            className="hidden"
          />
        </div>
        {ggufStatus?.llamaServerDetected ? (
          <div className="text-[10px] text-[#4ade80] font-mono mt-1">
            ✓ Wykryto: {ggufStatus.llamaServerDetected}
          </div>
        ) : (
          <div className="text-[10px] text-[#ff6b6b] font-mono mt-1">
            ✗ Nie wykryto llama-server. Pobierz z <a href="https://github.com/ggerganov/llama.cpp/releases" target="_blank" rel="noopener" className="underline">github.com/ggerganov/llama.cpp/releases</a>
          </div>
        )}
      </div>

      {/* Port + kontekst + GPU layers */}
      <div className="grid grid-cols-3 gap-2">
        <div>
          <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Port</label>
          <input
            type="number"
            value={settings.ggufPort}
            onChange={e => update('ggufPort', parseInt(e.target.value) || 8080)}
            className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] focus:outline-none focus:border-[#fbbf24]/50 font-mono"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">Kontekst</label>
          <input
            type="number"
            value={settings.ggufContextSize}
            onChange={e => update('ggufContextSize', parseInt(e.target.value) || 4096)}
            step={512}
            className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] focus:outline-none focus:border-[#fbbf24]/50 font-mono"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#6b6b8d] mb-1 block">GPU layers (-1=all)</label>
          <input
            type="number"
            value={settings.ggufGpuLayers}
            onChange={e => update('ggufGpuLayers', parseInt(e.target.value))}
            className="w-full bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-[#e0e0f0] focus:outline-none focus:border-[#fbbf24]/50 font-mono"
          />
        </div>
      </div>

      {/* Sterowanie serwerem */}
      <div className="flex items-center gap-2 pt-2">
        {ggufStatus?.running ? (
          <button
            onClick={stopServer}
            disabled={ggufBusy !== null}
            className="px-4 py-2 rounded-lg bg-[#ff6b6b]/10 border border-[#ff6b6b]/40 text-[#ff6b6b] hover:bg-[#ff6b6b]/20 text-xs font-mono flex items-center gap-2 disabled:opacity-50"
          >
            <Square size={14} /> {ggufBusy === 'stop' ? 'Zatrzymuję...' : 'Zatrzymaj serwer'}
          </button>
        ) : (
          <button
            onClick={startServer}
            disabled={ggufBusy !== null || !settings.ggufFilePath}
            className="px-4 py-2 rounded-lg bg-[#4ade80]/10 border border-[#4ade80]/40 text-[#4ade80] hover:bg-[#4ade80]/20 text-xs font-mono flex items-center gap-2 disabled:opacity-50"
          >
            <Play size={14} /> {ggufBusy === 'start' ? 'Uruchamiam (do 60s)...' : 'Uruchom serwer'}
          </button>
        )}
        <button
          onClick={loadStatus}
          className="px-3 py-2 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] hover:border-[#fbbf24]/30 text-xs font-mono"
        >
          Odśwież status
        </button>
      </div>

      {/* Status serwera */}
      {ggufStatus && (
        <div className={`text-[11px] font-mono px-3 py-2 rounded-lg border ${
          ggufStatus.running
            ? 'bg-[#4ade80]/10 border-[#4ade80]/30 text-[#4ade80]'
            : 'bg-[#6b6b8d]/10 border-[#6b6b8d]/30 text-[#6b6b8d]'
        }`}>
          {ggufStatus.running ? (
            <span>
              ✓ Serwer działa na porcie {ggufStatus.port}
              {ggufStatus.model && <span className="opacity-70"> · model: {ggufStatus.model.split(/[\\/]/).pop()}</span>}
            </span>
          ) : (
            <span>○ Serwer zatrzymany</span>
          )}
        </div>
      )}

      {/* Wiadomość akcji */}
      {ggufMessage && (
        <div className={`text-[11px] font-mono px-3 py-2 rounded-lg ${
          ggufMessage.ok ? 'bg-[#4ade80]/10 text-[#4ade80]' : 'bg-[#ff6b6b]/10 text-[#ff6b6b]'
        }`}>
          {ggufMessage.ok ? '✓ ' : '✗ '}{ggufMessage.message}
        </div>
      )}

      {/* Instrukcja instalacji llama-server */}
      {!ggufStatus?.llamaServerDetected && (
        <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 text-[11px] font-mono text-[#6b6b8d] space-y-1">
          <div className="text-[#e0e0f0]">Jak zainstalować llama-server:</div>
          <div>1. Wejdź na <a href="https://github.com/ggerganov/llama.cpp/releases" target="_blank" rel="noopener" className="text-[#fbbf24] underline">github.com/ggerganov/llama.cpp/releases</a></div>
          <div>2. Pobierz <code className="text-[#fbbf24]">llama-bXXXX-bin-win-cublas-cu12.X.zip</code> (dla NVIDIA GPU)</div>
          <div>   lub <code className="text-[#fbbf24]">llama-bXXXX-bin-win-avx2.zip</code> (dla CPU)</div>
          <div>3. Rozpakuj np. do <code className="text-[#fbbf24]">C:\llama.cpp\</code></div>
          <div>4. Wskaż <code className="text-[#fbbf24]">llama-server.exe</code> w polu powyżej</div>
          <div>5. Wskaż plik <code className="text-[#fbbf24]">.gguf</code> i kliknij „Uruchom serwer”</div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
// APPS TAB — zarządzanie własnymi appkami
// ═══════════════════════════════════════════
interface BokaApp {
  id: string;
  name: string;
  description?: string;
  language: string;
  filePath: string;
  fileName: string;
  sizeBytes: number;
  modifiedAt: string;
  commands?: string[];
  tags?: string[];
  author?: string;
  version?: string;
  isDir: boolean;
  files?: string[];
  isRunning?: boolean;
}

function AppsTab() {
  const [apps, setApps] = useState<BokaApp[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [view, setView] = useState<'list' | 'code' | 'analyze' | 'create' | 'marketplace' | 'agent' | 'lab'>('list');
  const [code, setCode] = useState<string>('');
  const [analysis, setAnalysis] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [appsDir, setAppsDir] = useState<string>('');

  // Create form
  const [newName, setNewName] = useState('');
  const [newLang, setNewLang] = useState<'go' | 'python' | 'html' | 'css' | 'javascript' | 'typescript' | 'bash'>('python');
  const [newDesc, setNewDesc] = useState('');

  const loadApps = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/apps');
      const data = await res.json();
      setApps(data.apps || []);
      setAppsDir(data.appsDir || '');
    } catch (e) {
      setMessage({ ok: false, text: `Błąd ładowania: ${e instanceof Error ? e.message : 'unknown'}` });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadApps(); }, [loadApps]);

  const selectedApp = apps.find(a => a.id === selectedId);

  const handleRun = async (id: string) => {
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch('/api/apps/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      setMessage({ ok: data.ok, text: data.message });
      if (data.ok) {
        // Odśwież po 1s żeby pokazać że działa
        setTimeout(loadApps, 1000);
      }
    } catch (e) {
      setMessage({ ok: false, text: `Błąd: ${e instanceof Error ? e.message : 'unknown'}` });
    } finally {
      setBusy(false);
    }
  };

  const handleStop = async (id: string) => {
    setBusy(true);
    try {
      const res = await fetch('/api/apps/stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      setMessage({ ok: data.ok, text: data.message });
      loadApps();
    } finally {
      setBusy(false);
    }
  };

  const handleViewCode = async (id: string) => {
    setBusy(true);
    try {
      const res = await fetch(`/api/apps/code?id=${encodeURIComponent(id)}`);
      const data = await res.json();
      if (data.ok) {
        setCode(data.code || '');
        setSelectedId(id);
        setView('code');
      } else {
        setMessage({ ok: false, text: data.error || 'Błąd czytania kodu' });
      }
    } finally {
      setBusy(false);
    }
  };

  const handleAnalyze = async (id: string) => {
    setBusy(true);
    setView('analyze');
    setSelectedId(id);
    setAnalysis('');
    setMessage(null);
    try {
      const res = await fetch('/api/apps/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, focus: 'ogólna analiza jakości, bezpieczeństwa i wydajności' }),
      });
      const data = await res.json();
      if (data.ok) {
        setAnalysis(data.analysis || '(brak analizy)');
      } else {
        setAnalysis(`Błąd: ${data.error}`);
      }
    } finally {
      setBusy(false);
    }
  };

  const handleAutoFix = async (id: string, mode: 'suggest' | 'apply') => {
    if (mode === 'apply' && !confirm('Na pewno zapisać AI-poprawiony kod? Oryginał zostanie zbackupowany.')) return;
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch('/api/apps/fix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id,
          instructions: 'Napraw bugi, popraw bezpieczeństwo i wydajność, zachowaj funkcjonalność i metadata BOKA-APP',
          mode,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        if (mode === 'apply') {
          setMessage({ ok: true, text: `Zastosowano poprawki. Backup: ${data.backupPath || '(brak)'}` });
          loadApps();
          if (view === 'code' && selectedId === id) {
            handleViewCode(id);
          }
        } else {
          setCode(data.fixedCode || '');
          setView('code');
          setMessage({ ok: true, text: 'AI zaproponował poprawki — przejrzyj kod poniżej' });
        }
      } else {
        setMessage({ ok: false, text: data.error || 'Błąd AI fix' });
      }
    } finally {
      setBusy(false);
    }
  };

  const handleCreate = async () => {
    if (!newName.trim()) { setMessage({ ok: false, text: 'Podaj nazwę' }); return; }
    setBusy(true);
    try {
      const res = await fetch('/api/apps/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim(), language: newLang, description: newDesc.trim() }),
      });
      const data = await res.json();
      if (data.ok) {
        setMessage({ ok: true, text: `Utworzono: ${data.filePath}` });
        setNewName(''); setNewDesc('');
        setView('list');
        loadApps();
      } else {
        setMessage({ ok: false, text: data.error || 'Błąd tworzenia' });
      }
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm(`Na pewno usunąć apkę ${id}?`)) return;
    setBusy(true);
    try {
      const res = await fetch('/api/apps/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.ok) {
        setMessage({ ok: true, text: `Usunięto ${id}` });
        if (selectedId === id) { setSelectedId(null); setView('list'); }
        loadApps();
      } else {
        setMessage({ ok: false, text: data.error || 'Błąd usuwania' });
      }
    } finally {
      setBusy(false);
    }
  };

  const languageColor: Record<string, string> = {
    go: '#00add8', python: '#3776ab', html: '#e34c26', css: '#563d7c',
    javascript: '#f7df1e', typescript: '#3178c6', bash: '#4eaa25', unknown: '#6b6b8d',
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#e0e0f0] flex items-center gap-2">
            <Wrench size={24} className="text-[#00f5d4]" />
            Moje Apki
          </h1>
          <p className="text-xs text-[#6b6b8d] mt-1 font-mono">{appsDir || '(ładowanie...)'}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setView('create')}
            className="px-3 py-2 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-sm hover:bg-[#00f5d4]/20 flex items-center gap-1"
          >
            <Plus size={14} /> Nowa apka
          </button>
          <button
            onClick={() => setView('marketplace')}
            className="px-3 py-2 bg-[#fbbf24]/10 border border-[#fbbf24]/30 text-[#fbbf24] rounded text-sm hover:bg-[#fbbf24]/20 flex items-center gap-1"
          >
            <Globe size={14} /> Marketplace
          </button>
          <button
            onClick={() => setView('lab')}
            className="px-3 py-2 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-sm hover:bg-[#a855f7]/20 flex items-center gap-1"
          >
            <Beaker size={14} /> Test Lab
          </button>
          <button
            onClick={loadApps}
            disabled={loading}
            className="px-3 py-2 bg-[#1e1e2e] border border-[#2a2a3a] text-[#e0e0f0] rounded text-sm hover:bg-[#2a2a3a] flex items-center gap-1 disabled:opacity-50"
          >
            <Loader2 size={14} className={loading ? 'animate-spin' : 'hidden'} /> Odśwież
          </button>
        </div>
      </div>

      {message && (
        <div className={`mb-4 p-3 rounded text-sm border ${message.ok ? 'bg-[#4ade80]/10 border-[#4ade80]/30 text-[#4ade80]' : 'bg-[#ff6b6b]/10 border-[#ff6b6b]/30 text-[#ff6b6b]'}`}>
          {message.text}
          <button onClick={() => setMessage(null)} className="float-right"><X size={14} /></button>
        </div>
      )}

      {/* LIST VIEW */}
      {view === 'list' && (
        <div>
          {loading ? (
            <div className="text-center py-12 text-[#6b6b8d]">
              <Loader2 className="animate-spin mx-auto mb-2" size={24} />
              Ładowanie apek...
            </div>
          ) : apps.length === 0 ? (
            <div className="text-center py-16 text-[#6b6b8d]">
              <FolderOpen size={48} className="mx-auto mb-3 opacity-40" />
              <p className="text-lg mb-2">Brak apek w folderze</p>
              <p className="text-sm mb-4">Wrzuć pliki .go, .py, .html, .css, .js do folderu:</p>
              <code className="text-xs bg-[#1e1e2e] px-2 py-1 rounded text-[#fbbf24]">{appsDir}</code>
              <p className="text-xs mt-4 text-[#6b6b8d]">lub utwórz nową apkę z szablonu ↑</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {apps.map(app => (
                <div key={app.id} className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 hover:border-[#00f5d4]/30 transition-all">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                        style={{ backgroundColor: `${languageColor[app.language] || '#6b6b8d'}20`, color: languageColor[app.language] || '#6b6b8d' }}
                      >
                        {app.language}
                      </span>
                      <h3 className="text-[#e0e0f0] font-semibold">{app.name}</h3>
                      {app.isRunning && (
                        <span className="flex items-center gap-1 text-[10px] text-[#4ade80]">
                          <span className="w-2 h-2 bg-[#4ade80] rounded-full animate-pulse" /> DZIAŁA
                        </span>
                      )}
                    </div>
                    {app.version && <span className="text-[10px] text-[#6b6b8d]">v{app.version}</span>}
                  </div>

                  {app.description && <p className="text-sm text-[#a0a0c0] mb-2">{app.description}</p>}

                  <div className="flex flex-wrap gap-1 mb-3">
                    {app.commands?.map(cmd => (
                      <span key={cmd} className="text-[10px] bg-[#0f0f1a] px-1.5 py-0.5 rounded font-mono text-[#fbbf24]">/{cmd}</span>
                    ))}
                    {app.tags?.map(tag => (
                      <span key={tag} className="text-[10px] bg-[#0f0f1a] px-1.5 py-0.5 rounded text-[#6b6b8d]">#{tag}</span>
                    ))}
                  </div>

                  <div className="text-[10px] text-[#6b6b8d] font-mono mb-3">
                    📁 {app.fileName} ({(app.sizeBytes / 1024).toFixed(1)} KB){app.isDir && ` · ${app.files?.length || 0} plików`}
                    {app.author && ` · ✍ ${app.author}`}
                  </div>

                  <div className="flex gap-1 flex-wrap">
                    {app.isRunning ? (
                      <button onClick={() => handleStop(app.id)} disabled={busy}
                        className="px-2 py-1 bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 text-[#ff6b6b] rounded text-xs hover:bg-[#ff6b6b]/20 flex items-center gap-1 disabled:opacity-50">
                        <Square size={12} /> Stop
                      </button>
                    ) : (
                      <button onClick={() => handleRun(app.id)} disabled={busy}
                        className="px-2 py-1 bg-[#4ade80]/10 border border-[#4ade80]/30 text-[#4ade80] rounded text-xs hover:bg-[#4ade80]/20 flex items-center gap-1 disabled:opacity-50">
                        <Play size={12} /> Uruchom
                      </button>
                    )}
                    <button onClick={() => handleViewCode(app.id)} disabled={busy}
                      className="px-2 py-1 bg-[#1e1e2e] border border-[#2a2a3a] text-[#a0a0c0] rounded text-xs hover:bg-[#2a2a3a] flex items-center gap-1">
                      <Eye size={12} /> Kod
                    </button>
                    <button onClick={() => handleAnalyze(app.id)} disabled={busy}
                      className="px-2 py-1 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-xs hover:bg-[#a855f7]/20 flex items-center gap-1">
                      <Brain size={12} /> Analizuj
                    </button>
                    <button onClick={() => handleAutoFix(app.id, 'suggest')} disabled={busy}
                      className="px-2 py-1 bg-[#fbbf24]/10 border border-[#fbbf24]/30 text-[#fbbf24] rounded text-xs hover:bg-[#fbbf24]/20 flex items-center gap-1">
                      <Zap size={12} /> AI Fix
                    </button>
                    <button onClick={() => { setSelectedId(app.id); setView('agent'); }}
                      className="px-2 py-1 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-xs hover:bg-[#a855f7]/20 flex items-center gap-1">
                      <Eye size={12} /> BOKA steruje
                    </button>
                    <button onClick={() => handleDelete(app.id)} disabled={busy}
                      className="px-2 py-1 bg-[#1e1e2e] border border-[#2a2a3a] text-[#6b6b8d] rounded text-xs hover:bg-[#ff6b6b]/10 hover:text-[#ff6b6b]">
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Info box dla usera */}
          <div className="mt-6 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 text-xs text-[#6b6b8d]">
            <div className="text-[#e0e0f0] font-semibold mb-2 flex items-center gap-1"><Sparkles size={14} /> Jak dodawać apki</div>
            <ol className="space-y-1 list-decimal list-inside">
              <li>Wrzuć pliki <code className="text-[#fbbf24]">.go, .py, .html, .css, .js, .ts, .sh</code> do folderu <code className="text-[#fbbf24]">{appsDir}</code></li>
              <li>Możesz też tworzyć foldery (np. <code className="text-[#fbbf24]">moja-appka/main.py</code>) — BOKA wykryje plik główny</li>
              <li>Dodaj metadata w komentarzach na początku pliku:</li>
            </ol>
            <pre className="mt-2 bg-[#0f0f1a] p-2 rounded font-mono text-[10px] text-[#a0a0c0] overflow-x-auto">{`# BOKA-APP: name=Moja Apka
# BOKA-APP: description=Co ta apka robi
# BOKA-APP: commands=uruchom, start
# BOKA-APP: tags=tools, demo
# BOKA-APP: author=Michał
# BOKA-APP: version=1.0`}</pre>
            <p className="mt-2">Format komentarzy: <code className="text-[#fbbf24]">#</code> dla Python/Bash, <code className="text-[#fbbf24]">//</code> dla Go/JS/TS, <code className="text-[#fbbf24]">&lt;!-- --&gt;</code> dla HTML, <code className="text-[#fbbf24]">/* */</code> dla CSS.</p>
          </div>
        </div>
      )}

      {/* CODE VIEW */}
      {view === 'code' && selectedApp && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <button onClick={() => setView('list')} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
                <ChevronRight size={16} className="rotate-180" />
              </button>
              <h2 className="text-lg font-semibold text-[#e0e0f0]">{selectedApp.name} — kod</h2>
              {selectedApp.isDir && <span className="text-xs text-[#6b6b8d]">({selectedApp.files?.length || 0} plików)</span>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleAutoFix(selectedApp.id, 'suggest')} disabled={busy}
                className="px-2 py-1 bg-[#fbbf24]/10 border border-[#fbbf24]/30 text-[#fbbf24] rounded text-xs hover:bg-[#fbbf24]/20 flex items-center gap-1">
                <Zap size={12} /> AI Popraw
              </button>
              <button onClick={() => handleAutoFix(selectedApp.id, 'apply')} disabled={busy}
                className="px-2 py-1 bg-[#4ade80]/10 border border-[#4ade80]/30 text-[#4ade80] rounded text-xs hover:bg-[#4ade80]/20 flex items-center gap-1">
                <CheckCircle size={12} /> Zastosuj AI Fix
              </button>
            </div>
          </div>
          <pre className="bg-[#0f0f1a] border border-[#2a2a3a] rounded-lg p-4 text-xs font-mono text-[#a0a0c0] overflow-x-auto max-h-[60vh] overflow-y-auto">{code || '(pusty)'}</pre>
        </div>
      )}

      {/* ANALYZE VIEW */}
      {view === 'analyze' && selectedApp && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <button onClick={() => setView('list')} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
                <ChevronRight size={16} className="rotate-180" />
              </button>
              <h2 className="text-lg font-semibold text-[#e0e0f0]">{selectedApp.name} — analiza AI</h2>
            </div>
            <button onClick={() => handleAnalyze(selectedApp.id)} disabled={busy}
              className="px-2 py-1 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-xs hover:bg-[#a855f7]/20 flex items-center gap-1">
              <Loader2 size={12} className={busy ? 'animate-spin' : 'hidden'} /> Ponów
            </button>
          </div>
          {busy && !analysis ? (
            <div className="text-center py-12 text-[#6b6b8d]">
              <Loader2 className="animate-spin mx-auto mb-2" size={24} />
              AI analizuje kod...
            </div>
          ) : (
            <div className="bg-[#0f0f1a] border border-[#2a2a3a] rounded-lg p-4 text-sm text-[#a0a0c0] prose prose-invert max-w-none">
              <MarkdownRenderer content={analysis} />
            </div>
          )}
        </div>
      )}

      {/* CREATE VIEW */}
      {view === 'create' && (
        <div className="max-w-md">
          <div className="flex items-center gap-2 mb-4">
            <button onClick={() => setView('list')} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
              <ChevronRight size={16} className="rotate-180" />
            </button>
            <h2 className="text-lg font-semibold text-[#e0e0f0]">Nowa apka z szablonu</h2>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#6b6b8d] mb-1">Nazwa apki</label>
              <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="np. weather-check"
                className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none" />
            </div>
            <div>
              <label className="block text-xs text-[#6b6b8d] mb-1">Język</label>
              <select value={newLang} onChange={e => setNewLang(e.target.value as typeof newLang)}
                className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none">
                <option value="python">Python (.py)</option>
                <option value="go">Go (.go)</option>
                <option value="javascript">JavaScript (.js)</option>
                <option value="typescript">TypeScript (.ts)</option>
                <option value="html">HTML (.html)</option>
                <option value="css">CSS (.css)</option>
                <option value="bash">Bash (.sh)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#6b6b8d] mb-1">Opis (opcjonalny)</label>
              <input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Krótki opis"
                className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none" />
            </div>
            <button onClick={handleCreate} disabled={busy}
              className="w-full py-2 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-sm hover:bg-[#00f5d4]/20 flex items-center justify-center gap-2 disabled:opacity-50">
              {busy && <Loader2 size={14} className="animate-spin" />} Utwórz apkę
            </button>
            <p className="text-[10px] text-[#6b6b8d]">Szablon automatycznie doda metadata BOKA-APP. Folder: <code className="text-[#fbbf24]">{appsDir}</code></p>
          </div>
        </div>
      )}

      {/* AGENT VIEW — BOKA steruje ekranem */}
      {view === 'agent' && selectedApp && (
        <DesktopAgentView app={selectedApp} onBack={() => setView('list')} />
      )}

      {/* MARKETPLACE VIEW */}
      {view === 'marketplace' && <MarketplaceSection onPickModel={async (modelId) => {
        if (!modelId) return;
        // Zapisz wybrany model do ustawień — przełącz provider na openrouter
        try {
          const settingsRes = await fetch('/api/settings');
          const settingsData = await settingsRes.json();
          const current = settingsData.settings || {};
          const merged = {
            ...current,
            // Masked klucz zostanie zachowany przez backend (POST /api/settings)
            provider: 'openrouter',
            openrouterModel: modelId,
          };
          const saveRes = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings: merged }),
          });
          const saveData = await saveRes.json();
          if (saveData.ok) {
            setMessage({
              ok: true,
              text: `✓ Ustawiono model: ${modelId} — provider: OpenRouter. Kliknij "Testuj połączenie" w Ustawieniach.`,
            });
          } else {
            setMessage({ ok: false, text: `Błąd zapisu ustawień: ${saveData.error || 'unknown'}` });
          }
        } catch (e) {
          setMessage({ ok: false, text: `Błąd: ${e instanceof Error ? e.message : 'unknown'}` });
        }
        setView('list');
      }} />}
      {view === 'lab' && <ModelTestLab onBack={() => setView('list')} onPickModel={(modelId) => {
        setView('marketplace');
      }} />}
    </div>
  );
}

// ═══════════════════════════════════════════
// MODEL TEST LAB — test konkretnego modelu w różnych kategoriach
// ═══════════════════════════════════════════

interface TestResult {
  ok: boolean;
  modality?: string;
  category?: string;
  model?: string;
  response?: string;
  imageUrl?: string;
  latencyMs?: number;
  tokensIn?: number;
  tokensOut?: number;
  score?: {
    score: number;
    matchedKeywords: string[];
    length: number;
    notes: string[];
  };
  promptUsed?: string;
  error?: string;
}

function ModelTestLab({ onBack, onPickModel }: { onBack: () => void; onPickModel?: (modelId: string) => void }) {
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('');
  const [baseUrl, setBaseUrl] = useState('https://openrouter.ai/api/v1');
  const [modality, setModality] = useState<'text' | 'image' | 'audio' | 'file' | 'video' | 'multi'>('text');
  const [category, setCategory] = useState<'coding' | 'finance' | 'technology' | 'science' | 'humanity' | 'general' | 'creative'>('coding');
  const [customPrompt, setCustomPrompt] = useState('');
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);
  const [history, setHistory] = useState<Array<TestResult & { timestamp: string }>>([]);

  // Auto-load saved OpenRouter key from settings
  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        if (data.settings?.openrouterKey && !data.settings.openrouterKey.includes('...')) {
          setApiKey(data.settings.openrouterKey);
        }
        if (data.settings?.openrouterModel) {
          setModel(data.settings.openrouterModel);
        }
      })
      .catch(() => {});
  }, []);

  const categories = [
    { id: 'coding' as const, label: 'Programowanie', icon: '💻', desc: 'Quicksort w Pythonie' },
    { id: 'finance' as const, label: 'Finanse', icon: '💰', desc: 'Procent składany' },
    { id: 'technology' as const, label: 'Technologia', icon: '⚙️', desc: 'Architektura transformer' },
    { id: 'science' as const, label: 'Nauka', icon: '🔬', desc: 'II zasada dynamiki' },
    { id: 'humanity' as const, label: 'Humanistyka', icon: '📚', desc: 'Etyka Arystotelesa' },
    { id: 'creative' as const, label: 'Kreatywne', icon: '🎨', desc: 'Wiersz o świcie' },
    { id: 'general' as const, label: 'Ogólne', icon: '💬', desc: 'Podsumowanie dnia' },
  ];

  const modalities = [
    { id: 'text' as const, label: 'Tekst', color: '#00f5d4', desc: 'chat/completions' },
    { id: 'image' as const, label: 'Obraz', color: '#a855f7', desc: 'images/generations' },
    { id: 'audio' as const, label: 'Audio (TTS)', color: '#fbbf24', desc: 'audio/speech' },
    { id: 'multi' as const, label: 'Multi-modal', color: '#60a5fa', desc: 'vision + text' },
    { id: 'file' as const, label: 'Plik', color: '#4ade80', desc: 'file processing (custom)' },
    { id: 'video' as const, label: 'Video', color: '#ff6b6b', desc: 'video generation (custom)' },
  ];

  const runTest = async () => {
    if (!apiKey || !model) return;
    setRunning(true);
    setResult(null);
    try {
      const res = await fetch('/api/model-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey, model, baseUrl, modality, category,
          customPrompt: customPrompt || undefined,
        }),
      });
      const data: TestResult = await res.json();
      setResult(data);
      setHistory(prev => [{ ...data, timestamp: new Date().toISOString() }, ...prev].slice(0, 10));
    } catch (e) {
      setResult({ ok: false, error: e instanceof Error ? e.message : 'unknown' });
    } finally {
      setRunning(false);
    }
  };

  const runAllCategories = async () => {
    if (!apiKey || !model) return;
    setRunning(true);
    for (const cat of categories) {
      setCategory(cat.id);
      try {
        const res = await fetch('/api/model-test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ apiKey, model, baseUrl, modality, category: cat.id }),
        });
        const data: TestResult = await res.json();
        setResult(data);
        setHistory(prev => [{ ...data, timestamp: new Date().toISOString(), category: cat.id }, ...prev].slice(0, 30));
      } catch (e) {
        setHistory(prev => [{ ok: false, error: e instanceof Error ? e.message : 'unknown', timestamp: new Date().toISOString(), category: cat.id }, ...prev].slice(0, 30));
      }
    }
    setRunning(false);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <button onClick={onBack} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
          <ChevronRight size={16} className="rotate-180" />
        </button>
        <Beaker size={20} className="text-[#a855f7]" />
        <h2 className="text-lg font-semibold text-[#e0e0f0]">Model Test Lab</h2>
        <span className="text-xs text-[#6b6b8d]">— przetestuj model zanim go użyjesz</span>
      </div>

      {/* Config */}
      <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4 mb-4">
        <div className="grid gap-3 md:grid-cols-2 mb-3">
          <div>
            <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">API Key (Bearer)</label>
            <input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)}
              placeholder="sk-or-v1-..."
              className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm font-mono text-[#e0e0f0]" />
          </div>
          <div>
            <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Model ID</label>
            <input type="text" value={model} onChange={e => setModel(e.target.value)}
              placeholder="np. openai/gpt-oss-120b:free"
              className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm font-mono text-[#e0e0f0]" />
          </div>
        </div>
        <div className="mb-3">
          <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Base URL (OpenAI-compat)</label>
          <input type="text" value={baseUrl} onChange={e => setBaseUrl(e.target.value)}
            className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm font-mono text-[#e0e0f0]" />
          <div className="text-[10px] text-[#6b6b8d] mt-1">
            Domyślnie OpenRouter. Inne: <code className="text-[#fbbf24]">https://api.openai.com/v1</code>, <code className="text-[#fbbf24]">https://api.deepseek.com/v1</code>, <code className="text-[#fbbf24]">https://api.together.xyz/v1</code>
          </div>
        </div>

        {/* Modality picker */}
        <div className="mb-3">
          <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Modalność</label>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
            {modalities.map(m => (
              <button key={m.id} onClick={() => setModality(m.id)}
                className={`px-2 py-2 rounded border text-xs transition-all ${
                  modality === m.id
                    ? 'border-2 bg-[#1e1e2e]'
                    : 'border opacity-60 hover:opacity-100 bg-[#0f0f1a]'
                }`}
                style={{ borderColor: m.color, color: m.color }}>
                <div className="font-bold">{m.label}</div>
                <div className="text-[9px] opacity-70 font-mono">{m.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Category picker — only for text/multi */}
        {(modality === 'text' || modality === 'multi') && (
          <div className="mb-3">
            <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">Kategoria testu</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {categories.map(c => (
                <button key={c.id} onClick={() => setCategory(c.id)}
                  className={`px-2 py-2 rounded border text-xs text-left transition-all ${
                    category === c.id
                      ? 'bg-[#a855f7]/15 border-[#a855f7]/50 text-[#a855f7]'
                      : 'bg-[#0f0f1a] border-[#2a2a3a] text-[#a0a0c0] hover:border-[#a855f7]/30'
                  }`}>
                  <div className="font-bold flex items-center gap-1">{c.icon} {c.label}</div>
                  <div className="text-[9px] opacity-70">{c.desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Custom prompt override */}
        <div className="mb-3">
          <label className="text-xs text-[#6b6b8d] font-mono mb-1 block">
            Custom prompt (opcjonalnie — puste = domyślny dla kategorii)
          </label>
          <textarea value={customPrompt} onChange={e => setCustomPrompt(e.target.value)}
            rows={2}
            placeholder="Zostaw puste aby użyć domyślnego promptu dla tej kategorii"
            className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] font-mono" />
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <button onClick={runTest} disabled={running || !apiKey || !model}
            className="px-4 py-2 bg-[#a855f7]/15 border border-[#a855f7]/50 text-[#a855f7] rounded text-sm hover:bg-[#a855f7]/25 disabled:opacity-50 flex items-center gap-1">
            {running ? <Loader2 size={14} className="animate-spin" /> : <Beaker size={14} />}
            {running ? 'Testuję...' : 'Uruchom test'}
          </button>
          <button onClick={runAllCategories} disabled={running || !apiKey || !model || modality !== 'text'}
            className="px-4 py-2 bg-[#fbbf24]/10 border border-[#fbbf24]/30 text-[#fbbf24] rounded text-sm hover:bg-[#fbbf24]/20 disabled:opacity-50 flex items-center gap-1"
            title="Uruchom test dla wszystkich kategorii (tylko text)">
            <Zap size={14} /> Testuj wszystkie kategorie
          </button>
          {onPickModel && model && (
            <button onClick={() => onPickModel(model)}
              className="px-4 py-2 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-sm hover:bg-[#00f5d4]/20 flex items-center gap-1 ml-auto">
              <CheckCircle size={14} /> Użyj tego modelu
            </button>
          )}
        </div>
      </div>

      {/* Current result */}
      {result && (
        <div className={`mb-4 rounded-lg border p-4 ${result.ok ? 'bg-[#1e1e2e] border-[#4ade80]/30' : 'bg-[#1e1e2e] border-[#ff6b6b]/30'}`}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-[#e0e0f0] flex items-center gap-2">
              {result.ok ? <CheckCircle size={14} className="text-[#4ade80]" /> : <XCircle size={14} className="text-[#ff6b6b]" />}
              {result.ok ? 'Test zakończony' : 'Test nieudany'}
              {result.category && (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#a855f7]/15 text-[#a855f7]">
                  {result.category}
                </span>
              )}
              {result.modality && (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#00f5d4]/15 text-[#00f5d4]">
                  {result.modality}
                </span>
              )}
            </h3>
            {result.latencyMs !== undefined && (
              <span className="text-xs text-[#6b6b8d] font-mono">
                ⏱ {result.latencyMs < 1000 ? `${result.latencyMs}ms` : `${(result.latencyMs / 1000).toFixed(1)}s`}
              </span>
            )}
          </div>

          {/* Stats row */}
          {result.ok && (
            <div className="grid grid-cols-3 md:grid-cols-4 gap-2 mb-3 text-xs">
              {result.tokensIn !== undefined && (
                <div className="bg-[#0f0f1a] p-2 rounded">
                  <div className="text-[#6b6b8d] text-[10px]">Tokens IN</div>
                  <div className="text-[#4ade80] font-mono font-bold">{result.tokensIn}</div>
                </div>
              )}
              {result.tokensOut !== undefined && (
                <div className="bg-[#0f0f1a] p-2 rounded">
                  <div className="text-[#6b6b8d] text-[10px]">Tokens OUT</div>
                  <div className="text-[#fbbf24] font-mono font-bold">{result.tokensOut}</div>
                </div>
              )}
              {result.score && (
                <div className="bg-[#0f0f1a] p-2 rounded">
                  <div className="text-[#6b6b8d] text-[10px]">Score</div>
                  <div className={`font-mono font-bold ${result.score.score >= 70 ? 'text-[#4ade80]' : result.score.score >= 40 ? 'text-[#fbbf24]' : 'text-[#ff6b6b]'}`}>
                    {result.score.score}/100
                  </div>
                </div>
              )}
              {result.response && (
                <div className="bg-[#0f0f1a] p-2 rounded">
                  <div className="text-[#6b6b8d] text-[10px]">Długość</div>
                  <div className="text-[#a0a0c0] font-mono">{result.response.length} znaków</div>
                </div>
              )}
            </div>
          )}

          {/* Score notes */}
          {result.score && result.score.notes.length > 0 && (
            <div className="mb-3 p-2 bg-[#0f0f1a] rounded text-xs">
              <div className="text-[#6b6b8d] mb-1">Notatki oceny:</div>
              <ul className="space-y-0.5">
                {result.score.notes.map((n, i) => (
                  <li key={i} className="text-[#a0a0c0]">• {n}</li>
                ))}
                {result.score.matchedKeywords.length > 0 && (
                  <li className="text-[#4ade80]">• Słowa kluczowe: {result.score.matchedKeywords.join(', ')}</li>
                )}
              </ul>
            </div>
          )}

          {/* Image preview */}
          {result.imageUrl && typeof result.imageUrl === 'string' && result.imageUrl.startsWith('http') && (
            <div className="mb-3">
              <img src={result.imageUrl} alt="Wygenerowany obraz" className="max-w-md rounded border border-[#2a2a3a]" />
            </div>
          )}

          {/* Response text */}
          {result.response && (
            <div>
              <div className="text-[10px] text-[#6b6b8d] font-mono mb-1">ODPOWIEDŹ:</div>
              <pre className="bg-[#0f0f1a] border border-[#2a2a3a] rounded p-3 text-xs text-[#a0a0c0] font-mono whitespace-pre-wrap max-h-96 overflow-y-auto">{result.response}</pre>
            </div>
          )}

          {/* Error */}
          {result.error && (
            <div className="p-3 bg-[#ff6b6b]/5 border border-[#ff6b6b]/20 rounded text-xs text-[#ff6b6b] font-mono">
              {result.error}
            </div>
          )}

          {/* Prompt used */}
          {result.promptUsed && (
            <details className="mt-3">
              <summary className="text-[10px] text-[#6b6b8d] font-mono cursor-pointer">Pokaż prompt</summary>
              <pre className="mt-1 p-2 bg-[#0f0f1a] rounded text-[10px] text-[#6b6b8d] font-mono whitespace-pre-wrap">{result.promptUsed}</pre>
            </details>
          )}
        </div>
      )}

      {/* History */}
      {history.length > 0 && (
        <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-[#e0e0f0]">Historia testów ({history.length})</h3>
            <button onClick={() => setHistory([])} className="text-[10px] text-[#6b6b8d] hover:text-[#ff6b6b]">
              Wyczyść
            </button>
          </div>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {history.map((h, i) => (
              <div key={i} className="flex items-center gap-2 text-xs p-2 bg-[#0f0f1a] rounded">
                <span className={`w-2 h-2 rounded-full ${h.ok ? 'bg-[#4ade80]' : 'bg-[#ff6b6b]'}`} />
                <span className="text-[#a0a0c0]">{h.category || '?'}</span>
                <span className="text-[#6b6b8d] font-mono">·</span>
                <span className="text-[#a0a0c0]">{h.modality || '?'}</span>
                {h.latencyMs !== undefined && (
                  <>
                    <span className="text-[#6b6b8d] font-mono">·</span>
                    <span className="text-[#fbbf24] font-mono">{h.latencyMs}ms</span>
                  </>
                )}
                {h.score && (
                  <>
                    <span className="text-[#6b6b8d] font-mono">·</span>
                    <span className={`font-mono ${h.score.score >= 70 ? 'text-[#4ade80]' : h.score.score >= 40 ? 'text-[#fbbf24]' : 'text-[#ff6b6b]'}`}>{h.score.score}/100</span>
                  </>
                )}
                {!h.ok && h.error && (
                  <span className="text-[#ff6b6b] truncate flex-1" title={h.error}>— {h.error.slice(0, 80)}</span>
                )}
                <span className="text-[#6b6b8d] text-[10px] ml-auto">
                  {new Date(h.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Info box */}
      <div className="mt-4 p-3 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg text-xs text-[#6b6b8d]">
        <div className="text-[#e0e0f0] font-semibold mb-1">💡 Jak działa Test Lab?</div>
        <p>• Wpisz klucz API + ID modelu (lub użyj zapisanych z Ustawień)</p>
        <p>• Wybierz <b className="text-[#00f5d4]">modalność</b>: tekst, obraz, audio, file, video, multi-modal</p>
        <p>• Wybierz <b className="text-[#a855f7]">kategorię</b>: kod, finanse, technologia, nauka, humanistyka, kreatywne, ogólne</p>
        <p>• BOKA wyśle standardowy testowy prompt i oceni odpowiedź (słowa kluczowe, długość, czas)</p>
        <p>• „Testuj wszystkie" przebiega przez 7 kategorii — porównaj jak model radzi sobie w różnych dziedzinach</p>
        <p>• Każdy test trafia do historii — możesz porównać wyniki różnych modeli obok siebie</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// MARKETPLACE SECTION — porównywarka tanich modeli
// ═══════════════════════════════════════════
interface MarketplaceModel {
  source: string;
  id: string;
  name: string;
  description?: string;
  contextWindow?: number;
  maxOutput?: number;
  priceInputPerM: number;
  priceOutputPerM: number;
  currency: string;
  modalities?: string[];
  releasedAt?: string;
  popularity?: number;
  family?: string;
  homepage?: string;
  estimateCostPer1000Calls?: number;
  isFree?: boolean;
}

function MarketplaceSection({ onPickModel }: { onPickModel?: (modelId: string) => void }) {
  const [models, setModels] = useState<MarketplaceModel[]>([]);
  const [catalogs, setCatalogs] = useState<Array<{
    source: string; name: string; homepage: string; pricingPage: string;
    apiKeyUrl: string; notes: string; popularCheapModels: Array<{ id: string; name: string; priceInputPerM: number; priceOutputPerM: number; contextWindow: number; notes: string }>;
  }>>([]);
  const [stats, setStats] = useState<{ totalModels: number; freeCount?: number; sources: Record<string, number>; errors: string[]; cheapestInput: MarketplaceModel | null; cheapestOutput: MarketplaceModel | null; largestContext: MarketplaceModel | null } | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'cheapest-total' | 'cheapest-input' | 'cheapest-output' | 'largest-context' | 'newest' | 'popular'>('cheapest-total');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [freeOnly, setFreeOnly] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      params.set('sort', sort);
      if (search) params.set('search', search);
      if (sourceFilter !== 'all') params.set('source', sourceFilter);
      if (maxPrice) {
        params.set('maxInputPrice', maxPrice);
        params.set('maxOutputPrice', maxPrice);
      }
      if (freeOnly) params.set('freeOnly', '1');
      params.set('limit', '200');

      const res = await fetch(`/api/model-marketplace?${params}`);
      const data = await res.json();
      if (data.error && !data.models?.length) {
        setError(data.error);
      }
      setModels(data.models || []);
      setStats(data.stats || null);
      setCatalogs(data.catalogs || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'unknown');
    } finally {
      setLoading(false);
    }
  }, [sort, search, sourceFilter, maxPrice, freeOnly]);

  useEffect(() => { load(); }, [load]);

  const fmtPrice = (p: number) => p === 0 ? 'FREE' : `$${p.toFixed(4)}`;
  const fmtContext = (c?: number) => c ? `${(c / 1000).toFixed(0)}K` : '?';

  const sourceColor: Record<string, string> = {
    openrouter: '#fbbf24', muapi: '#a855f7', deepseek: '#4ade80', together: '#60a5fa', fireworks: '#ff6b6b',
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <button onClick={() => onPickModel ? onPickModel('') : null} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
          <ChevronRight size={16} className="rotate-180" />
        </button>
        <h2 className="text-lg font-semibold text-[#e0e0f0]">Marketplace modeli AI</h2>
        <span className="text-xs text-[#6b6b8d]">— porównaj ceny i wybierz tanio</span>
      </div>

      {/* Stats bar */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2">
            <div className="text-[10px] text-[#6b6b8d]">Wszystkich modeli</div>
            <div className="text-lg font-bold text-[#00f5d4]">{stats.totalModels}</div>
          </div>
          {stats.cheapestInput && (
            <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2">
              <div className="text-[10px] text-[#6b6b8d]">Najtańszy input</div>
              <div className="text-sm font-bold text-[#4ade80]">{fmtPrice(stats.cheapestInput.priceInputPerM)}/M</div>
              <div className="text-[10px] text-[#a0a0c0] truncate">{stats.cheapestInput.name}</div>
            </div>
          )}
          {stats.cheapestOutput && (
            <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2">
              <div className="text-[10px] text-[#6b6b8d]">Najtańszy output</div>
              <div className="text-sm font-bold text-[#4ade80]">{fmtPrice(stats.cheapestOutput.priceOutputPerM)}/M</div>
              <div className="text-[10px] text-[#a0a0c0] truncate">{stats.cheapestOutput.name}</div>
            </div>
          )}
          {stats.largestContext && (
            <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded p-2">
              <div className="text-[10px] text-[#6b6b8d]">Największy kontekst</div>
              <div className="text-sm font-bold text-[#a855f7]">{fmtContext(stats.largestContext.contextWindow)}</div>
              <div className="text-[10px] text-[#a0a0c0] truncate">{stats.largestContext.name}</div>
            </div>
          )}
        </div>
      )}

      {/* Free-mode explainer banner */}
      {freeOnly && (
        <div className="mb-4 p-3 bg-[#4ade80]/8 border border-[#4ade80]/30 rounded-lg text-xs text-[#a0a0c0]">
          <div className="text-[#4ade80] font-semibold mb-1 flex items-center gap-1">
            <Sparkles size={12} /> Tryb darmowych modeli
          </div>
          <p>
            Pokazuję tylko modele z ceną <b className="text-[#4ade80]">$0 input</b> i <b className="text-[#4ade80]">$0 output</b>.
            Te warianty (często z sufiksem <code className="text-[#fbbf24]">:free</code> w OpenRouter)
            nie zużywają Twoich kredytów — mają limity rate-limit, ale żadnych opłat.
            Idealne gdy konto OpenRouter mało zasobne, albo robot ma działać non-stop.
          </p>
          <p className="mt-1 text-[#6b6b8d]">
            Wskazówka: darmowe modele mają mniejszy rate-limit (np. 20 req/min) — dla intensywnego użytkowania przełącz na płatny.
          </p>
        </div>
      )}

      {/* Filters */}
      <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 mb-4 flex flex-wrap gap-2 items-center">
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="🔍 szukaj modelu (llama, gpt, claude, qwen...)"
          className="flex-1 min-w-[200px] bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-1.5 text-sm text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none"
        />
        <select value={sourceFilter} onChange={e => setSourceFilter(e.target.value)}
          className="bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1.5 text-sm text-[#e0e0f0]">
          <option value="all">Wszystkie źródła</option>
          <option value="openrouter">OpenRouter</option>
          <option value="muapi">MUAPI</option>
          <option value="catalogs">Katalogi (DeepSeek/Together/Fireworks)</option>
        </select>
        <select value={sort} onChange={e => setSort(e.target.value as typeof sort)}
          className="bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1.5 text-sm text-[#e0e0f0]">
          <option value="cheapest-total">Najtańsze łącznie</option>
          <option value="cheapest-input">Najtańszy input</option>
          <option value="cheapest-output">Najtańszy output</option>
          <option value="largest-context">Największy kontekst</option>
          <option value="newest">Najnowsze</option>
          <option value="popular">Najpopularniejsze</option>
        </select>
        <input
          type="number" value={maxPrice} onChange={e => setMaxPrice(e.target.value)}
          placeholder="max $/M"
          step="0.1" min="0"
          className="w-24 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1.5 text-sm text-[#e0e0f0]"
        />
        <label
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border cursor-pointer text-sm transition-colors ${
            freeOnly
              ? 'bg-[#4ade80]/15 border-[#4ade80]/40 text-[#4ade80]'
              : 'bg-[#0f0f1a] border-[#2a2a3a] text-[#a0a0c0] hover:border-[#4ade80]/30'
          }`}
          title="Pokaż tylko modele z ceną $0 input i $0 output (np. warianty OpenRouter :free)"
        >
          <input
            type="checkbox"
            checked={freeOnly}
            onChange={e => setFreeOnly(e.target.checked)}
            className="sr-only"
          />
          {freeOnly ? <Check size={14} /> : <Sparkles size={14} />}
          Tylko darmowe
          {stats?.freeCount ? (
            <span className="ml-1 text-[10px] opacity-70">({stats.freeCount})</span>
          ) : null}
        </label>
        <button onClick={load} disabled={loading}
          className="px-3 py-1.5 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-sm hover:bg-[#00f5d4]/20 flex items-center gap-1 disabled:opacity-50">
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />} Szukaj
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 text-[#ff6b6b] rounded text-sm">
          ⚠ {error}
          {stats?.errors?.length ? (
            <ul className="mt-1 text-xs">{stats.errors.map((e, i) => <li key={i}>• {e}</li>)}</ul>
          ) : null}
        </div>
      )}

      {/* Models table */}
      {loading ? (
        <div className="text-center py-12 text-[#6b6b8d]">
          <Loader2 className="animate-spin mx-auto mb-2" size={24} />
          Pobieranie modeli z marketplace...
        </div>
      ) : models.length === 0 ? (
        <div className="text-center py-12 text-[#6b6b8d]">
          Brak modeli pasujących do filtrów
        </div>
      ) : (
        <div className="overflow-x-auto bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg">
          <table className="w-full text-sm">
            <thead className="bg-[#0f0f1a] text-[#6b6b8d] text-xs uppercase">
              <tr>
                <th className="text-left px-3 py-2">Model</th>
                <th className="text-left px-3 py-2">Źródło</th>
                <th className="text-right px-3 py-2">Input $/M</th>
                <th className="text-right px-3 py-2">Output $/M</th>
                <th className="text-right px-3 py-2">~1000 zapytań</th>
                <th className="text-right px-3 py-2">Kontekst</th>
                <th className="text-left px-3 py-2">Modalności</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {models.slice(0, 100).map((m, i) => (
                <tr key={`${m.source}-${m.id}-${i}`} className="border-t border-[#2a2a3a] hover:bg-[#2a2a3a]/30">
                  <td className="px-3 py-2">
                    <div className="font-medium text-[#e0e0f0] flex items-center gap-1.5">
                      {m.name}
                      {m.isFree && (
                        <span
                          className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-[#4ade80]/15 border border-[#4ade80]/40 text-[#4ade80]"
                          title="Cena $0 za input i output — ten model nie zużywa kredytów"
                        >
                          FREE
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-[#6b6b8d] font-mono">{m.id}</div>
                  </td>
                  <td className="px-3 py-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                      style={{ backgroundColor: `${sourceColor[m.source] || '#6b6b8d'}20`, color: sourceColor[m.source] || '#6b6b8d' }}>
                      {m.source}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-right font-mono text-[#4ade80]">{fmtPrice(m.priceInputPerM)}</td>
                  <td className="px-3 py-2 text-right font-mono text-[#fbbf24]">{fmtPrice(m.priceOutputPerM)}</td>
                  <td className="px-3 py-2 text-right font-mono text-[#a0a0c0] text-xs">
                    {m.isFree ? <span className="text-[#4ade80]">$0.00</span> : `$${m.estimateCostPer1000Calls?.toFixed(4) || '?'}`}
                  </td>
                  <td className="px-3 py-2 text-right font-mono text-[#a855f7]">{fmtContext(m.contextWindow)}</td>
                  <td className="px-3 py-2 text-[10px] text-[#6b6b8d]">
                    {m.modalities?.slice(0, 3).join(', ') || 'text'}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {onPickModel && (
                      <button onClick={() => onPickModel(m.id)}
                        className={`px-2 py-1 rounded text-[10px] ${
                          m.isFree
                            ? 'bg-[#4ade80]/15 border border-[#4ade80]/40 text-[#4ade80] hover:bg-[#4ade80]/25'
                            : 'bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] hover:bg-[#00f5d4]/20'
                        }`}>
                        Wybierz
                      </button>
                    )}
                    {m.homepage && (
                      <a href={m.homepage} target="_blank" rel="noopener" className="ml-1 text-[#6b6b8d] hover:text-[#00f5d4]">
                        <Globe size={12} />
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {models.length > 100 && (
            <div className="p-2 text-center text-xs text-[#6b6b8d]">
              Wyświetlono 100 z {models.length} modeli. Użyj filtrów, aby zawęzić.
            </div>
          )}
        </div>
      )}

      {/* Provider catalogs */}
      {catalogs.length > 0 && (
        <div className="mt-6">
          <h3 className="text-sm font-semibold text-[#e0e0f0] mb-3">📋 Katalogi providerów (rejestracja API keys)</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {catalogs.map(cat => (
              <div key={cat.source} className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-[#e0e0f0]" style={{ color: sourceColor[cat.source] || '#e0e0f0' }}>{cat.name}</h4>
                  <span className="text-[10px] uppercase text-[#6b6b8d]">{cat.source}</span>
                </div>
                <p className="text-xs text-[#a0a0c0] mb-2">{cat.notes}</p>
                <div className="text-[10px] space-y-1 mb-2">
                  {cat.popularCheapModels.map(m => (
                    <div key={m.id} className="font-mono">
                      <span className="text-[#fbbf24]">{m.id}</span>
                      <span className="text-[#4ade80]"> ${m.priceInputPerM}/${m.priceOutputPerM}/M</span>
                      <span className="text-[#6b6b8d]"> · {m.notes}</span>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 text-[10px]">
                  <a href={cat.apiKeyUrl} target="_blank" rel="noopener" className="text-[#00f5d4] hover:underline flex items-center gap-1">
                    <Key size={10} /> API Keys
                  </a>
                  <a href={cat.pricingPage} target="_blank" rel="noopener" className="text-[#fbbf24] hover:underline flex items-center gap-1">
                    <Globe size={10} /> Cennik
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Info box */}
      <div className="mt-6 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 text-xs text-[#6b6b8d]">
        <div className="text-[#e0e0f0] font-semibold mb-1">💡 Jak to działa?</div>
        <p>• <b className="text-[#fbbf24]">OpenRouter</b> — agregator 300+ modeli. Wpisz klucz w Ustawieniach, wybierz model, gotowe.</p>
        <p>• <b className="text-[#a855f7]">MUAPI</b> — polski agregator. Endpoint OpenAI-compat: <code className="text-[#fbbf24]">https://muapi.net/api/v1</code></p>
        <p>• <b className="text-[#4ade80]">DeepSeek/Together/Fireworks</b> — bezpośrednie API. Skonfiguruj w Ustawieniach jako „Własny API" z URL: <code className="text-[#fbbf24]">https://api.deepseek.com/v1</code> (lub podobnym).</p>
        <p>• Kiedy robot będzie połączony na stałe z siecią, automatycznie odświeży listę modeli.</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// DESKTOP AGENT VIEW — BOKA steruje ekranem
// ═══════════════════════════════════════════
interface AgentStep {
  step: number;
  actionType: string;
  description: string;
  reasoning: string;
  screenshotBefore?: string;
  screenshotAfter?: string;
  executed: boolean;
  error?: string;
  timestamp: string;
}

function DesktopAgentView({ app, onBack }: { app: BokaApp; onBack: () => void }) {
  const [status, setStatus] = useState<{
    capabilities?: { screenshot: { available: boolean; tool?: string; note?: string }; input: { available: boolean; tool?: string; note?: string }; platform: string };
    vision?: { supported: boolean; note: string; provider: string; model: string };
  } | null>(null);
  const [liveScreenshot, setLiveScreenshot] = useState<string>('');
  const [instruction, setInstruction] = useState(`Otwórz apkę "${app.name}" i użyj jej`);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [running, setRunning] = useState(false);
  const [stopRequested, setStopRequested] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [previewWindow, setPreviewWindow] = useState<Window | null>(null);

  // Załaduj status capabilities
  useEffect(() => {
    fetch('/api/desktop/status')
      .then(r => r.json())
      .then(d => setStatus(d))
      .catch(e => console.error(e));
  }, []);

  // Auto-refresh screenshot co 3s gdy nie uruchomiony agent
  useEffect(() => {
    if (!autoRefresh || running) return;
    const refresh = () => {
      fetch('/api/desktop/screenshot')
        .then(r => r.json())
        .then(d => { if (d.ok && d.base64) setLiveScreenshot(d.base64); })
        .catch(() => {});
    };
    refresh();
    const id = setInterval(refresh, 3000);
    return () => clearInterval(id);
  }, [autoRefresh, running]);

  const openAppInWindow = () => {
    if (app.language === 'html') {
      // Otwórz preview w osobnym oknie
      const w = window.open(`/api/apps/preview?id=${encodeURIComponent(app.id)}`, `boka-app-${app.id}`, 'width=800,height=600,resizable=yes,scrollbars=yes');
      setPreviewWindow(w);
      setMessage?.({ ok: true, text: `Otwarto ${app.name} w osobnym oknie` });
    } else {
      // Uruchom przez API (Python, Go, JS)
      fetch('/api/apps/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: app.id }),
      }).then(r => r.json()).then(d => {
        setMessage?.({ ok: d.ok, text: d.message });
      });
    }
  };

  // Pomocnicza funkcja setMessage — przekazana przez props by uniknąć TS błędu
  function setMessage(msg: { ok: boolean; text: string }) {
    // Użyj custom event żeby komunikować z AppsTab
    window.dispatchEvent(new CustomEvent('boka-message', { detail: msg }));
  }

  const runAgentLoop = async () => {
    if (!instruction.trim()) return;
    setRunning(true);
    setStopRequested(false);
    setSteps([]);
    setCurrentStep(0);

    const maxSteps = 15;
    const localSteps: AgentStep[] = [];

    for (let i = 1; i <= maxSteps; i++) {
      if (stopRequested) break;
      setCurrentStep(i);

      try {
        const res = await fetch('/api/desktop/agent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            instruction,
            step: i,
            appId: app.id,
            maxSteps,
            previousActions: localSteps.slice(-5).map(s => ({
              step: s.step,
              action: { type: s.actionType, reasoning: s.reasoning },
              screenshotBefore: s.screenshotBefore,
              screenshotAfter: s.screenshotAfter,
              executed: s.executed,
              timestamp: s.timestamp,
            })),
          }),
        });
        const data = await res.json();

        if (!data.ok) {
          localSteps.push({
            step: i,
            actionType: 'failed',
            description: 'Błąd API',
            reasoning: data.error || 'unknown',
            executed: false,
            error: data.error,
            timestamp: new Date().toISOString(),
          });
          setSteps([...localSteps]);
          break;
        }

        const step = data.step;
        const action = step.action;
        const description = describeAgentAction(action);

        const localStep: AgentStep = {
          step: i,
          actionType: action.type,
          description,
          reasoning: action.reasoning || '',
          screenshotBefore: step.screenshotBefore,
          screenshotAfter: step.screenshotAfter,
          executed: step.executed,
          error: step.error,
          timestamp: step.timestamp,
        };
        localSteps.push(localStep);
        setSteps([...localSteps]);

        // Zaktualizuj live screenshot
        if (step.screenshotAfter) setLiveScreenshot(step.screenshotAfter);
        else if (step.screenshotBefore) setLiveScreenshot(step.screenshotBefore);

        // Koniec pętli?
        if (action.type === 'done' || action.type === 'failed') break;
      } catch (e) {
        localSteps.push({
          step: i,
          actionType: 'failed',
          description: 'Network error',
          reasoning: e instanceof Error ? e.message : 'unknown',
          executed: false,
          error: e instanceof Error ? e.message : 'unknown',
          timestamp: new Date().toISOString(),
        });
        setSteps([...localSteps]);
        break;
      }
    }

    setRunning(false);
    setCurrentStep(0);
  };

  const stop = () => setStopRequested(true);

  const manualClick = async (e: React.MouseEvent<HTMLImageElement>) => {
    // Klik w screenshot — wyślij akcję klik w tych współrzędnych
    const img = e.currentTarget;
    const rect = img.getBoundingClientRect();
    const scaleX = (img.naturalWidth || rect.width) / rect.width;
    const scaleY = (img.naturalHeight || rect.height) / rect.height;
    const x = Math.round((e.clientX - rect.left) * scaleX);
    const y = Math.round((e.clientY - rect.top) * scaleY);

    fetch('/api/desktop/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'click', x, y, button: 'left' }),
    }).then(() => {
      // Odśwież screenshot po 500ms
      setTimeout(() => {
        fetch('/api/desktop/screenshot')
          .then(r => r.json())
          .then(d => { if (d.ok && d.base64) setLiveScreenshot(d.base64); });
      }, 500);
    });
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <button onClick={onBack} className="text-[#6b6b8d] hover:text-[#e0e0f0]">
          <ChevronRight size={16} className="rotate-180" />
        </button>
        <h2 className="text-lg font-semibold text-[#e0e0f0]">BOKA steruje: {app.name}</h2>
        <span className="text-xs text-[#6b6b8d]">— AI widzi ekran i klika</span>
      </div>

      {/* Status capabilities */}
      {status && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
          <div className={`bg-[#1e1e2e] border rounded p-2 ${status.capabilities?.screenshot.available ? 'border-[#4ade80]/30' : 'border-[#ff6b6b]/30'}`}>
            <div className="text-[10px] text-[#6b6b8d]">Screenshot</div>
            <div className={`text-sm font-bold ${status.capabilities?.screenshot.available ? 'text-[#4ade80]' : 'text-[#ff6b6b]'}`}>
              {status.capabilities?.screenshot.available ? '✓ Działa' : '✗ Niedostępny'}
            </div>
            <div className="text-[10px] text-[#a0a0c0]">{status.capabilities?.screenshot.tool || status.capabilities?.screenshot.note}</div>
          </div>
          <div className={`bg-[#1e1e2e] border rounded p-2 ${status.capabilities?.input.available ? 'border-[#4ade80]/30' : 'border-[#ff6b6b]/30'}`}>
            <div className="text-[10px] text-[#6b6b8d]">Input (mysz/klawa)</div>
            <div className={`text-sm font-bold ${status.capabilities?.input.available ? 'text-[#4ade80]' : 'text-[#ff6b6b]'}`}>
              {status.capabilities?.input.available ? '✓ Działa' : '✗ Niedostępny'}
            </div>
            <div className="text-[10px] text-[#a0a0c0]">{status.capabilities?.input.tool || status.capabilities?.input.note}</div>
          </div>
          <div className={`bg-[#1e1e2e] border rounded p-2 ${status.vision?.supported ? 'border-[#4ade80]/30' : 'border-[#fbbf24]/30'}`}>
            <div className="text-[10px] text-[#6b6b8d]">Vision model</div>
            <div className={`text-sm font-bold ${status.vision?.supported ? 'text-[#4ade80]' : 'text-[#fbbf24]'}`}>
              {status.vision?.supported ? '✓ Wspierany' : '⚠ Wymagany'}
            </div>
            <div className="text-[10px] text-[#a0a0c0]">{status.vision?.note}</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Lewa kolumna: screenshot + controls */}
        <div>
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-[#e0e0f0]">Podgląd ekranu</h3>
              <div className="flex items-center gap-2">
                <label className="text-[10px] text-[#6b6b8d] flex items-center gap-1">
                  <input type="checkbox" checked={autoRefresh} onChange={e => setAutoRefresh(e.target.checked)} className="w-3 h-3" />
                  Auto-refresh
                </label>
                <button
                  onClick={() => fetch('/api/desktop/screenshot').then(r => r.json()).then(d => { if (d.ok && d.base64) setLiveScreenshot(d.base64); })}
                  className="text-[10px] px-2 py-0.5 bg-[#0f0f1a] border border-[#2a2a3a] rounded text-[#a0a0c0] hover:bg-[#2a2a3a]"
                >
                  📸 Odśwież
                </button>
              </div>
            </div>
            {liveScreenshot ? (
              <img
                src={`data:image/png;base64,${liveScreenshot}`}
                alt="Ekran"
                onClick={manualClick}
                className="w-full rounded border border-[#2a2a3a] cursor-crosshair"
                style={{ imageRendering: 'auto' }}
              />
            ) : (
              <div className="aspect-video bg-[#0f0f1a] rounded flex items-center justify-center text-[#6b6b8d] text-sm">
                {status?.capabilities?.screenshot.available ? 'Ładowanie screenshota...' : 'Screenshot niedostępny'}
              </div>
            )}
            <p className="text-[10px] text-[#6b6b8d] mt-1">💡 Kliknij w screenshot aby ręcznie wykonać klik w tej pozycji</p>
          </div>

          {/* Controls */}
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 mt-3">
            <h3 className="text-sm font-semibold text-[#e0e0f0] mb-2">Sterowanie</h3>
            <div className="flex flex-wrap gap-1 mb-3">
              <button onClick={openAppInWindow}
                className="px-3 py-1.5 bg-[#00f5d4]/10 border border-[#00f5d4]/30 text-[#00f5d4] rounded text-xs hover:bg-[#00f5d4]/20 flex items-center gap-1">
                <Play size={12} /> Otwórz apkę
              </button>
              {previewWindow && (
                <button onClick={() => { previewWindow.close(); setPreviewWindow(null); }}
                  className="px-3 py-1.5 bg-[#1e1e2e] border border-[#2a2a3a] text-[#a0a0c0] rounded text-xs hover:bg-[#2a2a3a]">
                  Zamknij okienko
                </button>
              )}
            </div>

            <label className="block text-xs text-[#6b6b8d] mb-1">Instrukcja dla BOKA:</label>
            <textarea
              value={instruction}
              onChange={e => setInstruction(e.target.value)}
              placeholder="np. 'Kliknij przycisk Submit, wpisz w pole hello world, wyślij formularz'"
              rows={3}
              className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none mb-2"
              disabled={running}
            />
            <div className="flex gap-2">
              {!running ? (
                <button onClick={runAgentLoop} disabled={!instruction.trim()}
                  className="flex-1 py-2 bg-[#a855f7]/10 border border-[#a855f7]/30 text-[#a855f7] rounded text-sm hover:bg-[#a855f7]/20 flex items-center justify-center gap-2 disabled:opacity-50">
                  <Sparkles size={14} /> Uruchom agenta (max 15 kroków)
                </button>
              ) : (
                <button onClick={stop}
                  className="flex-1 py-2 bg-[#ff6b6b]/10 border border-[#ff6b6b]/30 text-[#ff6b6b] rounded text-sm hover:bg-[#ff6b6b]/20 flex items-center justify-center gap-2">
                  <Square size={14} /> Zatrzymaj (krok {currentStep})
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Prawa kolumna: historia kroków */}
        <div>
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3">
            <h3 className="text-sm font-semibold text-[#e0e0f0] mb-2">
              Historia kroków {running && <span className="text-[#a855f7] text-xs animate-pulse">• krok {currentStep}...</span>}
            </h3>
            {steps.length === 0 ? (
              <div className="text-center py-8 text-[#6b6b8d] text-sm">
                {running ? 'Agent pracuje...' : 'Brak kroków. Wpisz instrukcję i kliknij Uruchom.'}
              </div>
            ) : (
              <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                {steps.map((s, i) => (
                  <div key={i} className={`bg-[#0f0f1a] border rounded p-2 text-xs ${
                    s.actionType === 'done' ? 'border-[#4ade80]/40' :
                    s.actionType === 'failed' ? 'border-[#ff6b6b]/40' :
                    s.executed ? 'border-[#2a2a3a]' : 'border-[#fbbf24]/40'
                  }`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        s.actionType === 'done' ? 'bg-[#4ade80]/20 text-[#4ade80]' :
                        s.actionType === 'failed' ? 'bg-[#ff6b6b]/20 text-[#ff6b6b]' :
                        'bg-[#00f5d4]/20 text-[#00f5d4]'
                      }`}>{s.step}</span>
                      <span className="font-mono text-[10px] uppercase text-[#6b6b8d]">{s.actionType}</span>
                      {s.executed ? <CheckCircle size={12} className="text-[#4ade80]" /> : <XCircle size={12} className="text-[#fbbf24]" />}
                    </div>
                    <div className="text-[#e0e0f0] mb-1">{s.description}</div>
                    {s.reasoning && <div className="text-[10px] text-[#a0a0c0] italic">→ {s.reasoning}</div>}
                    {s.error && <div className="text-[10px] text-[#ff6b6b] mt-1">⚠ {s.error}</div>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Manual action buttons */}
          <div className="bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 mt-3">
            <h3 className="text-sm font-semibold text-[#e0e0f0] mb-2">Ręczne akcje</h3>
            <div className="grid grid-cols-2 gap-1 text-[10px]">
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'key', combo: 'Return' }) }).then(() => setTimeout(() => location.reload(), 500))}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Enter</button>
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'key', combo: 'Escape' }) }).then(() => setTimeout(() => location.reload(), 500))}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Esc</button>
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'key', combo: 'Control+c' }) })}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Ctrl+C</button>
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'key', combo: 'Control+v' }) })}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Ctrl+V</button>
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'scroll', deltaY: 3 }) }).then(() => setTimeout(() => location.reload(), 500))}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Scroll ↓</button>
              <button onClick={() => fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'scroll', deltaY: -3 }) }).then(() => setTimeout(() => location.reload(), 500))}
                className="px-2 py-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded hover:bg-[#2a2a3a] text-[#a0a0c0]">Scroll ↑</button>
            </div>
            <input
              type="text"
              placeholder="Wpisz tekst i Enter → wpisz na ekranie"
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  const text = (e.target as HTMLInputElement).value;
                  if (text) {
                    fetch('/api/desktop/act', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'type', text }) });
                    (e.target as HTMLInputElement).value = '';
                  }
                }
              }}
              className="w-full mt-2 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-xs text-[#e0e0f0] focus:border-[#00f5d4]/50 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Info box */}
      <div className="mt-4 bg-[#1e1e2e] border border-[#2a2a3a] rounded-lg p-3 text-xs text-[#6b6b8d]">
        <div className="text-[#e0e0f0] font-semibold mb-1">🤖 Jak działa BOKA Agent?</div>
        <p>1. BOKA robi screenshot ekranu</p>
        <p>2. Wysyła go do modelu AI z capability <b className="text-[#fbbf24]">vision</b> (Claude 3.5, GPT-4V, Qwen-VL, Llava...)</p>
        <p>3. AI analizuje obraz i decyduje co kliknąć / wpisać / wciśnąć</p>
        <p>4. BOKA wykonuje akcję (mysz/klawiatura przez PowerShell/xdotool)</p>
        <p>5. Robi nowy screenshot — i tak w kółko aż skończy</p>
        <p className="mt-2">⚠ <b className="text-[#fbbf24]">Uwaga:</b> daj BOCIE wyraźną instrukcję. Agent ma max 15 kroków na zadanie. Współrzędne kliknięć są w pikselach ekranu — działa na całym pulpicie, nie tylko na apce.</p>
        <p className="mt-1">💡 Jeśli model nie wspiera vision, przełącz w Ustawieniach na model z vision capability (sprawdź Marketplace → filtr modalities=vision).</p>
      </div>
    </div>
  );
}

function describeAgentAction(action: { type: string; x?: number; y?: number; button?: string; text?: string; combo?: string; deltaY?: number; reasoning?: string; summary?: string; error?: string }): string {
  switch (action.type) {
    case 'click': return `Klik ${action.button || 'left'} @ (${action.x}, ${action.y})`;
    case 'double_click': return `Dwuklik @ (${action.x}, ${action.y})`;
    case 'type': return `Wpisz: "${(action.text || '').slice(0, 60)}${(action.text || '').length > 60 ? '...' : ''}"`;
    case 'key': return `Klawisz: ${action.combo}`;
    case 'scroll': return `Scroll ${action.deltaY && action.deltaY > 0 ? '↓' : '↑'}`;
    case 'wait': return `Czekaj`;
    case 'done': return `ZROBIONE: ${action.summary || ''}`;
    case 'failed': return `BŁĄD: ${action.error || ''}`;
    default: return action.type;
  }
}

// ═══════════════════════════════════════════
// Simple Markdown renderer (no external deps)
// ═══════════════════════════════════════════
function MarkdownRenderer({ content }: { content: string }) {
  // Bardzo prosty markdown: nagłówki, bold, listy, code blocks
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let inCode = false;
  let codeBuffer: string[] = [];

  lines.forEach((line, i) => {
    if (line.startsWith('```')) {
      if (inCode) {
        elements.push(<pre key={`code-${i}`} className="bg-[#0f0f1a] p-2 rounded text-[11px] font-mono text-[#a0a0c0] my-2 overflow-x-auto">{codeBuffer.join('\n')}</pre>);
        codeBuffer = [];
        inCode = false;
      } else {
        inCode = true;
      }
      return;
    }
    if (inCode) { codeBuffer.push(line); return; }

    if (line.startsWith('### ')) {
      elements.push(<h4 key={i} className="text-sm font-bold text-[#e0e0f0] mt-3 mb-1">{line.slice(4)}</h4>);
    } else if (line.startsWith('## ')) {
      elements.push(<h3 key={i} className="text-base font-bold text-[#00f5d4] mt-3 mb-2">{line.slice(3)}</h3>);
    } else if (line.startsWith('# ')) {
      elements.push(<h2 key={i} className="text-lg font-bold text-[#e0e0f0] mt-3 mb-2">{line.slice(2)}</h2>);
    } else if (line.startsWith('- ') || line.startsWith('* ')) {
      elements.push(<div key={i} className="text-sm text-[#a0a0c0] pl-3 py-0.5">• {renderInline(line.slice(2))}</div>);
    } else if (/^\d+\.\s/.test(line)) {
      const m = line.match(/^(\d+)\.\s(.*)/);
      if (m) elements.push(<div key={i} className="text-sm text-[#a0a0c0] pl-3 py-0.5"><span className="text-[#fbbf24]">{m[1]}.</span> {renderInline(m[2])}</div>);
    } else if (line.trim()) {
      elements.push(<p key={i} className="text-sm text-[#a0a0c0] my-1">{renderInline(line)}</p>);
    } else {
      elements.push(<div key={i} className="h-2" />);
    }
  });

  if (codeBuffer.length > 0) {
    elements.push(<pre key="code-final" className="bg-[#0f0f1a] p-2 rounded text-[11px] font-mono text-[#a0a0c0] my-2 overflow-x-auto">{codeBuffer.join('\n')}</pre>);
  }

  return <div>{elements}</div>;
}

function renderInline(text: string): React.ReactNode {
  // **bold** i `code`
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/);
  return parts.map((p, i) => {
    if (p.startsWith('**') && p.endsWith('**')) return <strong key={i} className="text-[#e0e0f0]">{p.slice(2, -2)}</strong>;
    if (p.startsWith('`') && p.endsWith('`')) return <code key={i} className="bg-[#0f0f1a] px-1 rounded text-[#fbbf24] text-[11px]">{p.slice(1, -1)}</code>;
    return p;
  });
}


