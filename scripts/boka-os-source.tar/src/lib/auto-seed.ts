/**
 * Auto-seed: tworzy domyślną rodzinę i członków jeśli baza jest pusta.
 * Idempotentny — można wywoływać wielokrotnie.
 * Uruchamiany automatycznie przez API routes gdy brakuje członków rodziny.
 */
import { db } from '@/lib/db';

export interface SeedResult {
  seeded: boolean;
  familyId?: string;
  memberIds?: { tata?: string; mama?: string; syn?: string };
  reason?: string;
}

export async function ensureFamilySeeded(): Promise<SeedResult> {
  // Sprawdź czy już są jacyś członkowie
  const existingMembers = await db.familyMember.count();
  if (existingMembers > 0) {
    return { seeded: false, reason: 'already_seeded' };
  }

  // Utwórz rodzinę (jeśli nie ma)
  let family = await db.family.findFirst();
  if (!family) {
    family = await db.family.create({
      data: {
        name: 'Rodzina',
        settings: JSON.stringify({
          language: 'pl',
          childNearbyMode: true,
          safeLanguageFilter: true,
        }),
      },
    });
  }

  // Utwórz członków rodziny — Tata, Mama, Syn
  const tata = await db.familyMember.create({
    data: {
      familyId: family.id,
      name: 'Michał',
      role: 'parent',
      age: 40,
      avatarEmoji: '👨',
      preferences: JSON.stringify({
        interests: ['technologia', 'AI', 'robotyka', 'programowanie'],
        communicationStyle: 'technical',
        language: 'pl',
        zodiacSign: 'Baran',
      }),
      isActive: true,
    },
  });

  const mama = await db.familyMember.create({
    data: {
      familyId: family.id,
      name: 'Ewa',
      role: 'partner',
      age: 31,
      avatarEmoji: '👩',
      preferences: JSON.stringify({
        interests: ['matematyka', 'nauka', 'sztuka'],
        communicationStyle: 'balanced',
        language: 'pl',
        zodiacSign: 'Koziorożec',
      }),
      isActive: true,
    },
  });

  const syn = await db.familyMember.create({
    data: {
      familyId: family.id,
      name: 'Jaś',
      role: 'child',
      age: 7,
      avatarEmoji: '👦',
      preferences: JSON.stringify({
        interests: ['Minecraft', 'LEGO', 'SuperThings', 'Poppy Playtime', 'Sprunki'],
        communicationStyle: 'playful',
        language: 'pl',
        sensitivity: 'moderate',
        favoriteGames: ['Minecraft', 'LEGO'],
        zodiacSign: 'Strzelec',
      }),
      isActive: false, // nie w pobliżu domyślnie
    },
  });

  // Profile
  await db.memberProfile.create({ data: { memberId: tata.id, domain: 'tech', data: JSON.stringify({ focus: ['AI', 'robotyka', 'ROS2'], level: 'advanced' }) } });
  await db.memberProfile.create({ data: { memberId: tata.id, domain: 'finance', data: JSON.stringify({ riskTolerance: 'moderate', currency: 'PLN' }) } });
  await db.memberProfile.create({ data: { memberId: tata.id, domain: 'legal', data: JSON.stringify({ jurisdiction: 'Poland', needs: ['residence_permit', 'tax'] }) } });
  await db.memberProfile.create({ data: { memberId: mama.id, domain: 'education', data: JSON.stringify({ mathLevel: 'advanced', interests: ['algebra', 'calculus'] }) } });
  await db.memberProfile.create({ data: { memberId: mama.id, domain: 'art', data: JSON.stringify({ stylePreference: 'modern', mediums: ['digital', 'photography'] }) } });
  await db.memberProfile.create({ data: { memberId: syn.id, domain: 'child_culture', data: JSON.stringify({ games: ['Minecraft', 'LEGO', 'SuperThings'], sensitivity: 'moderate', ageAppropriate: true }) } });
  await db.memberProfile.create({ data: { memberId: syn.id, domain: 'education', data: JSON.stringify({ level: 'early_primary', subjects: ['math', 'reading', 'science'], learningStyle: 'visual' }) } });

  // Początkowe wspomnienia
  await db.memoryEntry.create({
    data: {
      familyId: family.id,
      memberId: tata.id,
      entryType: 'semantic',
      domain: 'general',
      title: 'Preferencje Michała',
      content: 'Michał ma 40 lat, znak zodiaku Baran. Interesuje się technologią, AI, robotyką i programowaniem. Woli komunikację techniczną i szczegółową. Buduje system Family AGI dla rodziny.',
      importance: 0.9,
      tags: JSON.stringify(['michał', 'preferencje', 'technologia']),
      source: 'manual',
    },
  });
  await db.memoryEntry.create({
    data: {
      familyId: family.id,
      memberId: mama.id,
      entryType: 'semantic',
      domain: 'general',
      title: 'Preferencje Ewy',
      content: 'Ewa ma 31 lat, znak zodiaku Koziorożec. Interesuje się matematyką, nauką i sztuką. Woli zrównoważony styl komunikacji. Lubi uczyć się nowych rzeczy.',
      importance: 0.9,
      tags: JSON.stringify(['ewa', 'preferencje', 'matematyka']),
      source: 'manual',
    },
  });
  await db.memoryEntry.create({
    data: {
      familyId: family.id,
      memberId: syn.id,
      entryType: 'semantic',
      domain: 'child_culture',
      title: 'Profil Jasia',
      content: 'Jaś ma 7 lat, znak zodiaku Strzelec. Lubi grać w Minecraft, budować z LEGO, kolekcjonuje SuperThings. Uczy się w szkole podstawowej. Wrażliwość: umiarkowana. Gdy jest w pobliżu, asystent musi używać tylko odpowiedniego języka — bez wulgaryzmów, bez straszenia, bez treści 18+.',
      importance: 1.0,
      emotionalValence: 0.5,
      tags: JSON.stringify(['jaś', 'dziecko', 'bezpieczeństwo', 'gry', 'Minecraft']),
      source: 'manual',
    },
  });

  // Budżety
  const categories = [
    { category: 'spożywcze', limit: 2500 },
    { category: 'rachunki', limit: 1500 },
    { category: 'transport', limit: 800 },
    { category: 'rozrywka', limit: 500 },
    { category: 'edukacja', limit: 400 },
  ];
  for (const cat of categories) {
    await db.budget.create({
      data: {
        familyId: family.id,
        category: cat.category,
        monthlyLimit: cat.limit,
        currency: 'PLN',
        activeFrom: new Date(),
      },
    });
  }

  // Rytuały
  const rituals = [
    {
      familyId: family.id,
      name: 'poranne_powitanie',
      type: 'daily',
      time: '07:00',
      prompt: 'Dzień dobry! ☀️ Nowy dzień — zapytaj krótko jak kto spał, wspomnij o pogodzie i czy są jakieś plany na dziś. Bądź ciepły i naturalny, nie za długi.',
    },
    {
      familyId: family.id,
      name: 'wieczorne_podsumowanie',
      type: 'daily',
      time: '20:00',
      prompt: 'Dobry wieczór! 🌙 Zapytaj jak minął dzień, czy coś dobrego się wydarzyło. Bądź czuły i uważny — to czas na refleksję i wyciszenie.',
    },
    {
      familyId: family.id,
      memberId: syn.id,
      name: 'po_szkole',
      type: 'daily',
      time: '14:30',
      prompt: 'Hej Jaś! 🎒 Jak w szkole? Co ciekawego się działo? Pogadaj z nim o jego dzień — Minecraft, LEGO, SuperThings — daj mu przestrzeń do opowiedzenia.',
    },
    {
      familyId: family.id,
      name: 'weekend_poranek',
      type: 'weekly',
      time: '09:00',
      dayOfWeek: 6,
      prompt: 'Weekend! 🎉 Zapytaj co planują na weekend, czy mają jakieś pomysły. Może wycieczka? Może grilling? Bądź entuzjastyczny!',
    },
  ];
  for (const ritual of rituals) {
    await db.ritual.create({ data: { ...ritual, isActive: true } });
  }

  return {
    seeded: true,
    familyId: family.id,
    memberIds: { tata: tata.id, mama: mama.id, syn: syn.id },
  };
}
