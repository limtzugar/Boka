// ═══════════════════════════════════════════════════════════
// BOKA — Home Assistant Service (v0.3.17)
// L11 Desktop/Home Manipulation — most między BOKA a fizycznym domem.
// REST API client do Home Assistant.
// ═══════════════════════════════════════════════════════════

import { prisma } from './db';
import { loadSettings } from './ai-providers';
import { logDecision } from './audit-service';

// ── HA Config (stored in boka-settings.json) ─
export interface HAConfig {
  haUrl?: string;       // np. http://homeassistant.local:8123
  haToken?: string;     // Long-Lived Access Token
  haEnabled?: boolean;
}

// ── Load HA config from settings ─────────────
export function loadHAConfig(): HAConfig {
  const settings = loadSettings() as any;
  return {
    haUrl: settings.haUrl ?? '',
    haToken: settings.haToken ?? '',
    haEnabled: settings.haEnabled ?? false,
  };
}

// ── Save HA config ───────────────────────────
export function saveHAConfig(config: HAConfig): void {
  const settings = loadSettings() as any;
  settings.haUrl = config.haUrl;
  settings.haToken = config.haToken;
  settings.haEnabled = config.haEnabled;
  // saveSettings is loaded from ai-providers
  const { saveSettings } = require('./ai-providers');
  saveSettings(settings);
}

// ── REST API call to HA ──────────────────────
async function haFetch(path: string, options: RequestInit = {}): Promise<any> {
  const config = loadHAConfig();
  if (!config.haEnabled || !config.haUrl || !config.haToken) {
    throw new Error('Home Assistant not configured. Set haUrl + haToken in settings.');
  }

  const url = `${config.haUrl.replace(/\/$/, '')}${path}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${config.haToken}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`HA ${response.status}: ${text.slice(0, 200)}`);
  }

  // Some HA endpoints return empty body (e.g. POST services)
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

// ── Get HA status (test connection) ──────────
export async function getStatus(): Promise<{
  ok: boolean;
  version?: string;
  locationName?: string;
  error?: string;
}> {
  try {
    const data = await haFetch('/api/');
    return {
      ok: true,
      version: data.version,
      locationName: data.location_name,
    };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
}

// ── Get all states ───────────────────────────
export async function getAllStates(): Promise<any[]> {
  return await haFetch('/api/states');
}

// ── Get single entity state ──────────────────
export async function getEntityState(entityId: string): Promise<any> {
  return await haFetch(`/api/states/${entityId}`);
}

// ── Call service ─────────────────────────────
// domain: light, switch, climate, media_player, ...
// service: turn_on, turn_off, toggle, set_temperature, ...
// data: { entity_id, brightness, ... }
export async function callService(
  domain: string,
  service: string,
  data: Record<string, any> = {},
): Promise<{ ok: boolean; result?: any; error?: string }> {
  try {
    const result = await haFetch(`/api/services/${domain}/${service}`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return { ok: true, result };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
}

// ── Sync entities to local DB (cache) ────────
export async function syncEntities(familyId: string): Promise<{
  synced: number;
  byDomain: Record<string, number>;
}> {
  const states = await getAllStates();

  // Group by domain
  const byDomain: Record<string, number> = {};

  for (const state of states) {
    const entityId: string = state.entity_id;
    const domain = entityId.split('.')[0];

    if (!domain) continue;
    byDomain[domain] = (byDomain[domain] ?? 0) + 1;

    const friendlyName = state.attributes?.friendly_name ?? entityId;
    const attributes = state.attributes ?? {};

    await prisma.homeAssistantEntity.upsert({
      where: { familyId_entityId: { familyId, entityId } },
      create: {
        familyId,
        entityId,
        friendlyName,
        domain,
        state: state.state ?? '',
        attributesJson: JSON.stringify(attributes),
        lastUpdated: state.last_updated ? new Date(state.last_updated) : null,
      },
      update: {
        friendlyName,
        state: state.state ?? '',
        attributesJson: JSON.stringify(attributes),
        lastUpdated: state.last_updated ? new Date(state.last_updated) : null,
      },
    });
  }

  await logDecision({
    familyId,
    agentId: 'boka-ha-bridge',
    action: 'ha_synced',
    category: 'home_automation',
    reasoning: `Zsynchronizowano ${states.length} encji z Home Assistant.`,
    outputSummary: `${states.length} entities, ${Object.keys(byDomain).length} domen`,
    riskLevel: 'info',
    contextJson: { count: states.length, byDomain },
  });

  return { synced: states.length, byDomain };
}

// ── Get cached entities (from DB) ────────────
export async function getCachedEntities(
  familyId: string,
  domain?: string,
): Promise<any[]> {
  const where: any = { familyId };
  if (domain) where.domain = domain;

  const entities = await prisma.homeAssistantEntity.findMany({
    where,
    orderBy: { domain: 'asc' },
  });

  return entities.map((e) => ({
    ...e,
    attributes: JSON.parse(e.attributesJson),
  }));
}

// ── Get sensor history ───────────────────────
// Returns sensors from cached entities.
export async function getSensors(familyId: string): Promise<any[]> {
  return getCachedEntities(familyId, 'sensor');
}

// ── Natural language command router ──────────
// Detects Polish commands like "włącz światło w salonie" → service call
export async function routeNaturalLanguageCommand(
  familyId: string,
  message: string,
): Promise<{
  matched: boolean;
  domain?: string;
  service?: string;
  entityId?: string;
  data?: Record<string, any>;
  response?: string;
}> {
  const lower = message.toLowerCase().trim();

  // Pattern: włącz/wyłącz/przełącz [światło|włącznik|...] [w|w_w] <room>
  const turnOnMatch = lower.match(/(włącz|zapal|uruchom)\s+(.+)/i);
  const turnOffMatch = lower.match(/(wyłącz|zgaś|zatrzymaj)\s+(.+)/i);
  const toggleMatch = lower.match(/(przełącz|toggle)\s+(.+)/i);

  let action: 'turn_on' | 'turn_off' | 'toggle' | null = null;
  let rest = '';

  if (turnOnMatch) {
    action = 'turn_on';
    rest = turnOnMatch[2];
  } else if (turnOffMatch) {
    action = 'turn_off';
    rest = turnOffMatch[2];
  } else if (toggleMatch) {
    action = 'toggle';
    rest = toggleMatch[2];
  }

  if (!action) {
    // Check for temperature query
    if (lower.match(/temperatura|jaka jest temp/)) {
      const sensors = await getSensors(familyId);
      const tempSensors = sensors.filter((s) =>
        s.attributes?.unit_of_measurement === '°C' ||
        s.attributes?.device_class === 'temperature',
      );
      if (tempSensors.length > 0) {
        const readings = tempSensors
          .slice(0, 5)
          .map((s) => `${s.friendlyName}: ${s.state}°C`)
          .join(', ');
        return {
          matched: true,
          response: `Aktualne temperatury: ${readings}`,
        };
      }
    }
    return { matched: false };
  }

  // Detect entity type from "rest"
  let domain = 'light'; // default
  if (rest.match(/światło|lampę|lampę|oświetlenie/i)) {
    domain = 'light';
  } else if (rest.match(/włącznik|gniazdko|contact/i)) {
    domain = 'switch';
  } else if (rest.match(/termostat|ogrzewanie|klima/i)) {
    domain = 'climate';
  } else if (rest.match(/telewizor|tv|radio|muzyk/i)) {
    domain = 'media_player';
  }

  // Find matching entity by room name
  const entities = await getCachedEntities(familyId, domain);
  if (entities.length === 0) {
    return {
      matched: true,
      domain,
      service: action,
      response: `Nie znalazłam urządzeń typu ${domain}. Najpierw zsynchronizuj z Home Assistant.`,
    };
  }

  // Try to match by room: "salon", "kuchnia", "sypialnia", "łazienka", "biuro"
  const roomMatch = rest.match(/(salon|sal|kuchn|sypialn|łazienk|biur|garaż|strych|jadaln|dziec|koridor|korytarz|przedsion)/i);
  let target = entities[0]; // fallback to first
  if (roomMatch) {
    const roomWord = roomMatch[1].toLowerCase();
    const match = entities.find((e) =>
      e.friendlyName.toLowerCase().includes(roomWord) ||
      e.entityId.toLowerCase().includes(roomWord),
    );
    if (match) target = match;
  }

  const result = await callService(domain, action, { entity_id: target.entityId });

  if (result.ok) {
    await logDecision({
      familyId,
      agentId: 'boka-ha-bridge',
      action: 'ha_called',
      category: 'home_automation',
      reasoning: `User poprosił o "${message}" — wywołałam ${domain}.${action} dla ${target.friendlyName}.`,
      inputSummary: message,
      outputSummary: `${domain}.${action}(${target.entityId})`,
      riskLevel: 'low',
      contextJson: { domain, service: action, entity: target.entityId, friendlyName: target.friendlyName },
    });

    const actionWord = action === 'turn_on' ? 'Włączam' : action === 'turn_off' ? 'Wyłączam' : 'Przełączam';
    return {
      matched: true,
      domain,
      service: action,
      entityId: target.entityId,
      data: { entity_id: target.entityId },
      response: `${actionWord} ${target.friendlyName}.`,
    };
  }

  return {
    matched: true,
    domain,
    service: action,
    entityId: target.entityId,
    response: `Nie udało się: ${result.error}`,
  };
}
