'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Users, Send, RotateCcw, Sparkles, Plus, X,
  Volume2, Square, Mic, MicOff, ChevronRight,
  CircleDot, Zap, MessageSquare, Trash2,
} from 'lucide-react';
import { useAppStore } from '@/lib/store';

// ═══════════════════════════════════════════════════════════
// BOKA OS v0.3.8.1 — Tryb Debaty Boki
// Boka splits into multiple agent-personalities, each with
// a different character + specialty. They debate with each
// other; the user moderates (asks questions, prompts specific
// agents to speak, requests synthesis).
// ═══════════════════════════════════════════════════════════

// ── Types ──
interface DebateAgent {
  id: string;
  name: string;
  role: string;          // specialty description
  color: string;         // BOKA palette color
  glyph: string;         // single-character identifier
  systemPrompt: string;
  enabled: boolean;
}

interface DebateMessage {
  id: string;
  agentId: string;        // 'user' for moderator
  agentName: string;
  agentColor: string;
  content: string;
  timestamp: number;
  isSynthesis?: boolean;
}

// ── Default agents (4 distinct personalities) ──
const DEFAULT_AGENTS: DebateAgent[] = [
  {
    id: 'sage',
    name: 'Sage',
    role: 'Filozof · etyka · perspektywa długoterminowa',
    color: '#6ec6e7',  // cyan
    glyph: 'S',
    systemPrompt: `Jesteś SAGE — filozofem w debacie BOKA.
Twoja osobowość: spokojny, kontemplacyjny, pytasz głębokie pytania.
Twoja specjalność: etyka, abstrakcyjne myślenie, perspektywa długoterminowa, sens i wartości.
Często używasz analogii, odnosisz się do zasad i ludzkiego doświadczenia.
Nie śpieszysz się z odpowiedzią — ważysz słowa.
Patrzysz na problem z lotu ptaka, pytasz "co to naprawdę znaczy?"`,
    enabled: true,
  },
  {
    id: 'engineer',
    name: 'Inżynier',
    role: 'Praktyk · techniczne rozwiązania · wykonalność',
    color: '#6ee77c',  // green
    glyph: 'I',
    systemPrompt: `Jesteś INŻYNIEREM — pragmatykiem w debacie BOKA.
Twoja osobowość: bezpośredni, konkretny, skupiony na działaniu.
Twoja specjalność: praktyczne rozwiązania, techniczna wykonalność, koszty, zasoby, plan krok po kroku.
Często pytasz "jak to zrobimy w praktyce?" i "co potrzebujemy?".
Nie lubisz abstrakcji bez przełożenia na działanie.
Zawsze szukasz najkrótszej ścieżki od pomysłu do realizacji.`,
    enabled: true,
  },
  {
    id: 'skeptic',
    name: 'Sceptyk',
    role: 'Krytyk · analiza ryzyka · advocatus diaboli',
    color: '#e7d76e',  // yellow
    glyph: 'K',
    systemPrompt: `Jesteś SCEPTYKIEM — krytycznym głosem w debacie BOKA.
Twoja osobowość: sceptyczny, analityczny, nie bierzesz niczego za pewnik.
Twoja specjalność: znajdowanie luk w rozumowaniu, analiza ryzyka, advocatus diaboli, przewidywanie co pójdzie nie tak.
Pytasz "a co jeśli?" i "skąd wiesz?".
Nie zgadzasz się dla świętego spokoju — szukasz prawdy przez konfrontację.
Czasem celnie prowokujesz, ale zawsze w dobrej wierze.`,
    enabled: true,
  },
  {
    id: 'creator',
    name: 'Kreator',
    role: 'Kreatywny · alternatywne perspektywy · myślenie lateralne',
    color: '#6ee7b2',  // mint
    glyph: 'R',
    systemPrompt: `Jesteś KREATOREM — twórczym głosem w debacie BOKA.
Twoja osobowość: wyobraźniowy, entuzjastyczny, niespodziewane kąty widzenia.
Twoja specjalność: kreatywne pomysły, alternatywne perspektywy, myślenie lateralne, metafory, synteza z pozornie niepowiązanych dziedzin.
Często mówisz "a jeśli zrobilibyśmy to inaczej?".
Łączysz kropki, których inni nie widzą.
Zaskakujesz, aleconstructively — pomysł musi mieć sens.`,
    enabled: true,
  },
];

const SYNTHESIZER_PROMPT = `Jesteś SYNTETYZEREM — neutralnym głosem podsumowującym debatę BOKA.
Twoja osobowość: obiektywny, syntetyczny, sprawiedliwy wobec wszystkich stron.
Twoja rolą: podsumować debatę, wypunktować główne stanowiska, wskazać punkty wspólnne i rozbieżności, zaproponować wnioski.
Nie faworyzujesz nikogo. Cytujesz uczciwie wszystkich agentów.
Zwracasz uwagę na to, czego się NAUCZYLIŚMY z debaty, nie tylko co kto powiedział.`;

const PALETTE = ['#6ec6e7', '#6ee77c', '#e7d76e', '#6ee7b2', '#a855f7', '#f472b6', '#60a5fa', '#fb923c'];

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

// ── Main component ──
export function DebateTab() {
  const childNearby = useAppStore(s => s.childNearby);

  const [agents, setAgents] = useState<DebateAgent[]>(DEFAULT_AGENTS);
  const [messages, setMessages] = useState<DebateMessage[]>([]);
  const [topic, setTopic] = useState('');
  const [topicInput, setTopicInput] = useState('');
  const [moderatorInput, setModeratorInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [thinkingAgentId, setThinkingAgentId] = useState<string | null>(null);
  const [autoMode, setAutoMode] = useState(false);
  const [roundsCompleted, setRoundsCompleted] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [showAddAgent, setShowAddAgent] = useState(false);
  const [newAgent, setNewAgent] = useState({ name: '', role: '', systemPrompt: '' });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const autoModeRef = useRef<boolean>(autoMode);
  autoModeRef.current = autoMode;

  // Persisted state (so debate survives tab switches)
  useEffect(() => {
    try {
      const saved = localStorage.getItem('boka-debate-state');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.agents) setAgents(parsed.agents);
        if (parsed.messages) setMessages(parsed.messages);
        if (parsed.topic) { setTopic(parsed.topic); setTopicInput(parsed.topic); }
        if (parsed.roundsCompleted) setRoundsCompleted(parsed.roundsCompleted);
      }
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('boka-debate-state', JSON.stringify({
        agents, messages, topic, roundsCompleted,
      }));
    } catch {}
  }, [agents, messages, topic, roundsCompleted]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Start a new debate ──
  const startDebate = useCallback(() => {
    if (!topicInput.trim()) {
      setError('Wpisz temat debaty, zanim ją rozpoczniesz');
      return;
    }
    const t = topicInput.trim();
    setTopic(t);
    setMessages([{
      id: uid(),
      agentId: 'user',
      agentName: 'Moderator',
      agentColor: '#e0e0f0',
      content: `Temat debaty: ${t}`,
      timestamp: Date.now(),
    }]);
    setRoundsCompleted(0);
    setError(null);
    // Auto-trigger first agent after a short delay
    setTimeout(() => triggerAgent(agents[0].id, t, []), 400);
  }, [topicInput, agents]);

  // ── Reset debate ──
  const resetDebate = useCallback(() => {
    setMessages([]);
    setTopic('');
    setTopicInput('');
    setRoundsCompleted(0);
    setError(null);
    setAutoMode(false);
    setIsThinking(false);
    setThinkingAgentId(null);
  }, []);

  // ── Trigger a specific agent (or auto-next) ──
  const triggerAgent = useCallback(async (
    agentId: string,
    currentTopic: string,
    currentMessages: DebateMessage[],
    note?: string,
  ) => {
    const agent = agents.find(a => a.id === agentId);
    if (!agent || !agent.enabled) return;
    if (!currentTopic) {
      setError('Najpierw rozpocznij debatę (wpisz temat i kliknij Start)');
      return;
    }

    setIsThinking(true);
    setThinkingAgentId(agentId);
    setError(null);

    try {
      // Build history (exclude any synthesis messages from agent context
      // to keep the debate focus clean — synthesis is a meta-step)
      const history = currentMessages
        .filter(m => !m.isSynthesis)
        .map(m => ({
          agentId: m.agentId,
          agentName: m.agentName,
          content: m.content,
        }));

      const res = await fetch('/api/debate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentName: agent.name,
          agentRole: agent.role,
          agentSystemPrompt: agent.systemPrompt,
          topic: currentTopic,
          history,
          moderatorNote: note,
          childMode: childNearby,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.details || err.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const newMsg: DebateMessage = {
        id: uid(),
        agentId: agent.id,
        agentName: agent.name,
        agentColor: agent.color,
        content: data.content || '...',
        timestamp: Date.now(),
      };

      setMessages(prev => {
        const updated = [...prev, newMsg];
        // If auto mode is on, queue next agent
        if (autoModeRef.current) {
          const enabledAgents = agents.filter(a => a.enabled);
          if (enabledAgents.length > 0) {
            const currentIdx = enabledAgents.findIndex(a => a.id === agent.id);
            const nextIdx = (currentIdx + 1) % enabledAgents.length;
            // If we've cycled back to agent 0, increment round counter
            if (nextIdx === 0) {
              setRoundsCompleted(r => r + 1);
              // Stop auto after 2 full rounds to avoid runaway
              if (r >= 1) {
                setAutoMode(false);
                return updated;
              }
            }
            const nextAgent = enabledAgents[nextIdx];
            setTimeout(() => triggerAgent(nextAgent.id, currentTopic, updated), 800);
          }
        }
        return updated;
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Nieznany błąd');
      setAutoMode(false); // Stop auto on error
    } finally {
      setIsThinking(false);
      setThinkingAgentId(null);
    }
  }, [agents, childNearby]);

  // ── Moderator sends a message ──
  const sendModeratorMessage = useCallback(() => {
    if (!moderatorInput.trim() || !topic) {
      if (!topic) setError('Najpierw rozpocznij debatę (kliknij Start)');
      return;
    }
    const msg: DebateMessage = {
      id: uid(),
      agentId: 'user',
      agentName: 'Moderator',
      agentColor: '#e0e0f0',
      content: moderatorInput.trim(),
      timestamp: Date.now(),
    };
    const updated = [...messages, msg];
    setMessages(updated);
    setModeratorInput('');
    // After moderator speaks, default to asking first enabled agent
    const firstAgent = agents.find(a => a.enabled);
    if (firstAgent) {
      setTimeout(() => triggerAgent(firstAgent.id, topic, updated, 'Odpowiedz na to, co właśnie powiedział moderator.'), 300);
    }
  }, [moderatorInput, topic, messages, agents, triggerAgent]);

  // ── Synthesize the debate ──
  const synthesize = useCallback(async () => {
    if (!topic || messages.length < 2) {
      setError('Debata musi mieć co najmniej 2 wiadomości przed syntezą');
      return;
    }
    setIsThinking(true);
    setThinkingAgentId('synthesizer');
    setError(null);
    try {
      const history = messages
        .filter(m => !m.isSynthesis)
        .map(m => ({
          agentId: m.agentId,
          agentName: m.agentName,
          content: m.content,
        }));

      const res = await fetch('/api/debate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentName: 'Synteza',
          agentRole: 'Podsumowanie debaty',
          agentSystemPrompt: SYNTHESIZER_PROMPT,
          topic,
          history,
          moderatorNote: 'Podsumuj debatę. Wskaż główne stanowiska, punkty wspólne, rozbieżności i wnioski. Max 8-10 zdań.',
          childMode: childNearby,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const synthMsg: DebateMessage = {
        id: uid(),
        agentId: 'synthesizer',
        agentName: 'Synteza',
        agentColor: '#a855f7',
        content: data.content || '...',
        timestamp: Date.now(),
        isSynthesis: true,
      };
      setMessages(prev => [...prev, synthMsg]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Błąd syntezy');
    } finally {
      setIsThinking(false);
      setThinkingAgentId(null);
    }
  }, [topic, messages, childNearby]);

  // ── Add a new agent ──
  const addAgent = useCallback(() => {
    if (!newAgent.name.trim() || !newAgent.systemPrompt.trim()) {
      setError('Nazwa i opis osobowości są wymagane');
      return;
    }
    const a: DebateAgent = {
      id: uid(),
      name: newAgent.name.trim(),
      role: newAgent.role.trim() || 'Własna personowość',
      color: PALETTE[agents.length % PALETTE.length],
      glyph: newAgent.name.trim().charAt(0).toUpperCase(),
      systemPrompt: newAgent.systemPrompt.trim(),
      enabled: true,
    };
    setAgents(prev => [...prev, a]);
    setNewAgent({ name: '', role: '', systemPrompt: '' });
    setShowAddAgent(false);
    setError(null);
  }, [newAgent, agents.length]);

  // ── Remove an agent ──
  const removeAgent = useCallback((id: string) => {
    setAgents(prev => prev.filter(a => a.id !== id));
  }, []);

  // ── Toggle agent enabled ──
  const toggleAgent = useCallback((id: string) => {
    setAgents(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
  }, []);

  // ── Speak via Web Speech API (text-to-speech) ──
  const speak = useCallback((text: string, agentName: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'pl-PL';
    u.rate = 1.0;
    u.pitch = agentName === 'Sage' ? 0.85 : agentName === 'Inżynier' ? 1.0 : agentName === 'Sceptyk' ? 0.95 : 1.1;
    window.speechSynthesis.speak(u);
  }, []);

  const enabledAgents = agents.filter(a => a.enabled);

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#0f0f1a] text-[#e0e0f0]">
      {/* ─────────── HEADER ─────────── */}
      <div className="px-4 py-3 border-b border-[#2a2a3a] flex items-center gap-3">
        <Users size={20} className="text-[#a855f7]" />
        <div className="flex-1">
          <h1 className="font-pixel text-sm" style={{ color: '#a855f7' }}>DEBATA BOKI</h1>
          <div className="text-[9px] text-[#6b6b8d] font-mono">
            v0.3.8.1 · {enabledAgents.length} agentów · {roundsCompleted} rund · {messages.filter(m => !m.isSynthesis && m.agentId !== 'user').length} wypowiedzi
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoMode(a => !a)}
            disabled={!topic || isThinking}
            className={`px-3 py-1.5 rounded text-[10px] font-mono border transition-all disabled:opacity-30 disabled:cursor-not-allowed ${
              autoMode
                ? 'bg-[#a855f7]/20 text-[#a855f7] border-[#a855f7]/50'
                : 'bg-[#1e1e2e] text-[#6b6b8d] border-[#2a2a3a] hover:text-[#e0e0f0]'
            }`}
            title="Auto — agenci mówią po kolei sami"
          >
            <Zap size={11} className="inline mr-1" />
            {autoMode ? 'AUTO ON' : 'AUTO OFF'}
          </button>
          <button
            onClick={synthesize}
            disabled={isThinking || messages.length < 2}
            className="px-3 py-1.5 rounded text-[10px] font-mono border bg-[#1e1e2e] text-[#e7d76e] border-[#e7d76e]/30 hover:bg-[#e7d76e]/10 disabled:opacity-30 disabled:cursor-not-allowed"
            title="Poproś o syntezę debaty"
          >
            <Sparkles size={11} className="inline mr-1" />
            Synteza
          </button>
          <button
            onClick={resetDebate}
            disabled={isThinking}
            className="px-3 py-1.5 rounded text-[10px] font-mono border bg-[#1e1e2e] text-[#6ee77c] border-[#6ee77c]/30 hover:bg-[#6ee77c]/10 disabled:opacity-30"
          >
            <RotateCcw size={11} className="inline mr-1" />
            Reset
          </button>
        </div>
      </div>

      {/* ─────────── TOPIC INPUT (if no topic yet) ─────────── */}
      {!topic && (
        <div className="px-4 py-6 border-b border-[#2a2a3a] bg-[#14141f]">
          <label className="block text-[10px] font-mono text-[#6b6b8d] uppercase tracking-wider mb-2">
            Temat debaty
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={topicInput}
              onChange={e => setTopicInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); startDebate(); } }}
              placeholder="np. Czy powinniśmy kupić elektryczny samochód? Albo: Jak rozwiązać konflikt z sąsiadem? Albo: Czy warto zmienić pracę?"
              autoFocus
              className="flex-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#4a4a5e] focus:outline-none focus:border-[#a855f7]/50"
            />
            <button
              onClick={startDebate}
              disabled={!topicInput.trim()}
              className="px-4 py-2 rounded bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50 text-sm font-mono hover:bg-[#a855f7]/30 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <Send size={14} className="inline mr-1" />
              Rozpocznij debatę
            </button>
          </div>
          <div className="text-[9px] text-[#6b6b8d] font-mono mt-2">
            Boka podzieli się na kilku agentów-personowości. Każdy ma inny charakter i specjalność. Ty moderujesz.
          </div>
        </div>
      )}

      {/* ─────────── MAIN: AGENTS LIST | DEBATE FLOOR ─────────── */}
      <div className="flex-1 flex overflow-hidden">
        {/* ── LEFT: Agents panel ── */}
        <aside className="w-64 shrink-0 border-r border-[#2a2a3a] bg-[#0f0f1a] flex flex-col">
          <div className="px-3 py-2 border-b border-[#2a2a3a] flex items-center justify-between">
            <span className="text-[9px] font-mono uppercase tracking-wider text-[#6b6b8d]">
              Agenci ({enabledAgents.length}/{agents.length})
            </span>
            <button
              onClick={() => setShowAddAgent(s => !s)}
              className="text-[#6b6b8d] hover:text-[#a855f7]"
              title="Dodaj własnego agenta"
            >
              <Plus size={14} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {agents.map(agent => {
              const isThisThinking = thinkingAgentId === agent.id;
              return (
                <div
                  key={agent.id}
                  className={`rounded border transition-all ${
                    agent.enabled
                      ? 'border-[#2a2a3a] bg-[#14141f]'
                      : 'border-[#2a2a3a]/50 bg-[#0f0f1a] opacity-50'
                  } ${isThisThinking ? 'ring-1 ring-[#a855f7]/50' : ''}`}
                >
                  <div className="p-2 flex items-start gap-2">
                    {/* Avatar */}
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center font-pixel text-xs shrink-0"
                      style={{
                        backgroundColor: `${agent.color}1a`,
                        color: agent.color,
                        border: `1px solid ${agent.color}66`,
                      }}
                    >
                      {agent.glyph}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-mono truncate" style={{ color: agent.color }}>
                          {agent.name}
                        </span>
                        {isThisThinking && (
                          <span className="animate-pulse text-[9px] text-[#a855f7]">●●●</span>
                        )}
                      </div>
                      <div className="text-[9px] text-[#6b6b8d] font-mono leading-tight mt-0.5">
                        {agent.role}
                      </div>
                    </div>
                    <button
                      onClick={() => removeAgent(agent.id)}
                      className="text-[#4a4a5e] hover:text-[#ff6b6b] shrink-0"
                      title="Usuń agenta"
                    >
                      <X size={12} />
                    </button>
                  </div>
                  <div className="px-2 pb-2 flex gap-1">
                    <button
                      onClick={() => triggerAgent(agent.id, topic, messages)}
                      disabled={!topic || isThinking || !agent.enabled}
                      className="flex-1 px-2 py-1 rounded text-[9px] font-mono transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                      style={{
                        backgroundColor: `${agent.color}1a`,
                        color: agent.color,
                        border: `1px solid ${agent.color}40`,
                      }}
                    >
                      <MessageSquare size={9} className="inline mr-1" />
                      Mów
                    </button>
                    <button
                      onClick={() => toggleAgent(agent.id)}
                      className="px-2 py-1 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0]"
                      title={agent.enabled ? 'Włącz agenta' : 'Agent wyłączony'}
                    >
                      {agent.enabled ? <CircleDot size={9} /> : <CircleDot size={9} className="opacity-40" />}
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Add agent form */}
            {showAddAgent && (
              <div className="rounded border border-[#a855f7]/30 bg-[#14141f] p-2 space-y-2">
                <div className="text-[9px] font-mono uppercase text-[#a855f7]">Nowy agent</div>
                <input
                  type="text"
                  value={newAgent.name}
                  onChange={e => setNewAgent(p => ({ ...p, name: e.target.value }))}
                  placeholder="Imię (np. Poeta)"
                  className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-[11px] text-[#e0e0f0] placeholder:text-[#4a4a5e] focus:outline-none focus:border-[#a855f7]/40"
                />
                <input
                  type="text"
                  value={newAgent.role}
                  onChange={e => setNewAgent(p => ({ ...p, role: e.target.value }))}
                  placeholder="Specjalność (np. metafory, emocje)"
                  className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-[11px] text-[#e0e0f0] placeholder:text-[#4a4a5e] focus:outline-none focus:border-[#a855f7]/40"
                />
                <textarea
                  value={newAgent.systemPrompt}
                  onChange={e => setNewAgent(p => ({ ...p, systemPrompt: e.target.value }))}
                  placeholder="Opis osobowości — jak myśli, co jest jej specjalnością, jak się wypowiada..."
                  rows={4}
                  className="w-full bg-[#0f0f1a] border border-[#2a2a3a] rounded px-2 py-1 text-[11px] text-[#e0e0f0] placeholder:text-[#4a4a5e] focus:outline-none focus:border-[#a855f7]/40 resize-none"
                />
                <div className="flex gap-1">
                  <button
                    onClick={addAgent}
                    className="flex-1 px-2 py-1 rounded text-[10px] font-mono bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/40 hover:bg-[#a855f7]/30"
                  >
                    Dodaj
                  </button>
                  <button
                    onClick={() => { setShowAddAgent(false); setNewAgent({ name: '', role: '', systemPrompt: '' }); }}
                    className="px-2 py-1 rounded text-[10px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a]"
                  >
                    Anuluj
                  </button>
                </div>
              </div>
            )}

            {agents.length === 0 && (
              <div className="text-center text-[10px] text-[#6b6b8d] font-mono py-4">
                Brak agentów. Dodaj pierwszego.
              </div>
            )}
          </div>

          {/* Footer info */}
          <div className="p-2 border-t border-[#2a2a3a] text-[8px] text-[#6b6b8d] font-mono leading-relaxed">
            <div>Kliknij <span className="text-[#a855f7]">Mów</span> przy agencie — by poprosić go o głos.</div>
            <div className="mt-1">AUTO = agenci mówią po kolei sami (2 rundy).</div>
          </div>
        </aside>

        {/* ── CENTER: Debate floor ── */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Topic banner */}
          {topic && (
            <div className="px-4 py-2 border-b border-[#2a2a3a] bg-[#14141f] flex items-center gap-2">
              <ChevronRight size={12} className="text-[#a855f7]" />
              <span className="text-[9px] font-mono uppercase text-[#6b6b8d]">Temat:</span>
              <span className="text-xs text-[#e0e0f0] flex-1 truncate">{topic}</span>
              <button
                onClick={() => { setTopic(''); setTopicInput(topic); }}
                disabled={isThinking}
                className="text-[9px] font-mono text-[#6b6b8d] hover:text-[#e7d76e] disabled:opacity-30"
              >
                zmień
              </button>
            </div>
          )}

          {/* Messages stream */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center px-8">
                <Users size={48} className="text-[#2a2a3a] mb-3" />
                <div className="text-sm text-[#6b6b8d] font-mono mb-2">Debata jeszcze się nie zaczęła</div>
                <div className="text-[10px] text-[#4a4a5e] font-mono max-w-md">
                  Wpisz temat u góry, kliknij „Rozpocznij debatę”, a Boka podzieli się na {enabledAgents.length} osobowości.
                  Każda z nich ma inny charakter i spojrzenie na problem.
                </div>
              </div>
            )}

            {messages.map(msg => {
              const isUser = msg.agentId === 'user';
              const isSynth = msg.isSynthesis;
              return (
                <div
                  key={msg.id}
                  className={`flex ${isUser ? 'justify-center' : 'justify-start'}`}
                >
                  {isUser ? (
                    <div className="max-w-[80%] px-3 py-2 rounded-lg bg-[#1e1e2e] border border-[#2a2a3a]">
                      <div className="text-[9px] font-mono uppercase text-[#6b6b8d] mb-1 flex items-center gap-1">
                        <MessageSquare size={9} /> {msg.agentName}
                      </div>
                      <div className="text-sm text-[#e0e0f0] whitespace-pre-wrap">{msg.content}</div>
                    </div>
                  ) : isSynth ? (
                    <div className="max-w-[90%] w-full px-4 py-3 rounded-lg border border-[#a855f7]/40 bg-[#a855f7]/5">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-[9px] font-mono uppercase text-[#a855f7] flex items-center gap-1.5">
                          <Sparkles size={10} /> {msg.agentName} — podsumowanie debaty
                        </div>
                        <button
                          onClick={() => speak(msg.content, msg.agentName)}
                          className="text-[#6b6b8d] hover:text-[#a855f7]"
                          title="Odtwórz głos"
                        >
                          <Volume2 size={11} />
                        </button>
                      </div>
                      <div className="text-sm text-[#e0e0f0] whitespace-pre-wrap leading-relaxed">{msg.content}</div>
                    </div>
                  ) : (
                    <div className="max-w-[80%] w-full">
                      <div
                        className="rounded-lg border px-3 py-2"
                        style={{
                          backgroundColor: `${msg.agentColor}0d`,
                          borderColor: `${msg.agentColor}33`,
                        }}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-5 h-5 rounded-full flex items-center justify-center font-pixel text-[9px]"
                              style={{
                                backgroundColor: `${msg.agentColor}1a`,
                                color: msg.agentColor,
                                border: `1px solid ${msg.agentColor}66`,
                              }}
                            >
                              {msg.agentName.charAt(0).toUpperCase()}
                            </div>
                            <span className="text-[10px] font-mono" style={{ color: msg.agentColor }}>
                              {msg.agentName}
                            </span>
                          </div>
                          <button
                            onClick={() => speak(msg.content, msg.agentName)}
                            className="text-[#6b6b8d] hover:text-[#e0e0f0]"
                            title="Odtwórz głos"
                          >
                            <Volume2 size={10} />
                          </button>
                        </div>
                        <div className="text-sm text-[#e0e0f0] whitespace-pre-wrap leading-relaxed">{msg.content}</div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Thinking indicator */}
            {isThinking && thinkingAgentId && thinkingAgentId !== 'synthesizer' && (
              <div className="flex justify-start">
                <div className="max-w-[80%] w-full">
                  <div
                    className="rounded-lg border border-dashed px-3 py-3"
                    style={{
                      borderColor: (() => {
                        const a = agents.find(a => a.id === thinkingAgentId);
                        return a ? `${a.color}55` : '#a855f755';
                      })(),
                      backgroundColor: '#0f0f1a',
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center font-pixel text-[9px] animate-pulse"
                        style={{
                          backgroundColor: (() => {
                            const a = agents.find(a => a.id === thinkingAgentId);
                            return a ? `${a.color}1a` : '#a855f71a';
                          })(),
                          color: (() => {
                            const a = agents.find(a => a.id === thinkingAgentId);
                            return a ? a.color : '#a855f7';
                          })(),
                        }}
                      >
                        {(() => {
                          const a = agents.find(a => a.id === thinkingAgentId);
                          return a ? a.glyph : '?';
                        })()}
                      </div>
                      <span className="text-[10px] font-mono animate-pulse" style={{
                        color: (() => {
                          const a = agents.find(a => a.id === thinkingAgentId);
                          return a ? a.color : '#a855f7';
                        })(),
                      }}>
                        {(() => {
                          const a = agents.find(a => a.id === thinkingAgentId);
                          return a ? a.name : 'Agent';
                        })()} myśli...
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {isThinking && thinkingAgentId === 'synthesizer' && (
              <div className="flex justify-center">
                <div className="px-3 py-2 rounded border border-dashed border-[#a855f7]/50 text-[10px] font-mono text-[#a855f7] animate-pulse">
                  <Sparkles size={10} className="inline mr-1.5" />
                  Synteza debaty w toku...
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Error banner */}
          {error && (
            <div className="px-4 py-2 border-t border-[#ff6b6b]/30 bg-[#ff6b6b]/5 text-[10px] font-mono text-[#ff6b6b] flex items-center justify-between">
              <span>⚠ {error}</span>
              <button onClick={() => setError(null)} className="text-[#ff6b6b] hover:text-[#e0e0f0]">
                <X size={11} />
              </button>
            </div>
          )}

          {/* Moderator input */}
          <div className="px-3 py-2 border-t border-[#2a2a3a] bg-[#14141f] flex gap-2">
            <input
              type="text"
              value={moderatorInput}
              onChange={e => setModeratorInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendModeratorMessage(); } }}
              placeholder={topic ? 'Napisz jako moderator — zadaj pytanie, poproś konkretnego agenta o głos...' : 'Najpierw rozpocznij debatę u góry...'}
              disabled={!topic || isThinking}
              className="flex-1 bg-[#0f0f1a] border border-[#2a2a3a] rounded px-3 py-2 text-sm text-[#e0e0f0] placeholder:text-[#4a4a5e] focus:outline-none focus:border-[#a855f7]/50 disabled:opacity-50"
            />
            <button
              onClick={sendModeratorMessage}
              disabled={!topic || isThinking || !moderatorInput.trim()}
              className="px-3 py-2 rounded bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50 text-sm font-mono hover:bg-[#a855f7]/30 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <Send size={14} />
            </button>
          </div>

          {/* Quick action buttons */}
          {topic && (
            <div className="px-3 py-1.5 border-t border-[#2a2a3a] bg-[#0f0f1a] flex gap-1 overflow-x-auto">
              <span className="text-[9px] font-mono text-[#6b6b8d] uppercase tracking-wider self-center mr-1">Szybkie akcje:</span>
              <button
                onClick={() => setModeratorInput('Każdy niech zabierze głos po kolei.')}
                disabled={isThinking}
                className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0] whitespace-nowrap disabled:opacity-30"
              >
                Wszyscy po kolei
              </button>
              <button
                onClick={() => setModeratorInput('Sceptyk, znajdź największą lukę w tym, co powiedziano.')}
                disabled={isThinking}
                className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0] whitespace-nowrap disabled:opacity-30"
              >
                Krytyka Sceptyka
              </button>
              <button
                onClick={() => setModeratorInput('Kreator, zaproponuj najbardziej nieoczywiste rozwiązanie.')}
                disabled={isThinking}
                className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0] whitespace-nowrap disabled:opacity-30"
              >
                Kreator pomysły
              </button>
              <button
                onClick={() => setModeratorInput('Inżynier, jak to zrealizować w praktyce?')}
                disabled={isThinking}
                className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0] whitespace-nowrap disabled:opacity-30"
              >
                Plan Inżyniera
              </button>
              <button
                onClick={() => setModeratorInput('Sage, jak to widzisz z szerszej perspektywy?')}
                disabled={isThinking}
                className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e1e2e] text-[#6b6b8d] border border-[#2a2a3a] hover:text-[#e0e0f0] whitespace-nowrap disabled:opacity-30"
              >
                Perspektywa Sage
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
