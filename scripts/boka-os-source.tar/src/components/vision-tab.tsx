'use client';

// ═══════════════════════════════════════════════════════════
// BOKA — Vision Tab (v0.3.17 — Proactive BOKA + Local Vision)
// L7 Perception. Webcam snapshot → Moondream via Ollama.
// ═══════════════════════════════════════════════════════════

import { useState, useEffect, useCallback, useRef } from 'react';
import { Camera, Eye, Settings, Play, Pause, Trash2, AlertCircle } from 'lucide-react';

const FAMILY_ID = 'boka-family';

interface Snapshot {
  id: string;
  capturedAt: string;
  description: string;
  sceneSummary: string | null;
  detectedObjects: string[];
  moodLabel: string | null;
  model: string;
  triggerReason: string;
  triggeredAction: string | null;
  imageExists: boolean;
}

export function VisionTab() {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [response, setResponse] = useState('');
  const [error, setError] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Settings
  const [visionEnabled, setVisionEnabled] = useState(false);
  const [visionModel, setVisionModel] = useState('moondream:1.8b');
  const [visionIntervalSec, setVisionIntervalSec] = useState(60);

  const loadSnapshots = useCallback(async () => {
    try {
      const r = await fetch(`/api/vision/snapshots?familyId=${FAMILY_ID}&limit=30`);
      const data = await r.json();
      setSnapshots(data.snapshots ?? []);
    } catch (e) {
      console.error(e);
    }
  }, []);

  useEffect(() => {
    loadSnapshots();
  }, [loadSnapshots]);

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStreaming(true);
      setError('');
    } catch (e: any) {
      setError(`Nie udało się uruchomić kamery: ${e.message}`);
    }
  }

  function stopCamera() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setStreaming(false);
  }

  async function captureOnce() {
    if (!videoRef.current || !streaming) return;
    setLoading(true);
    setError('');
    try {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas 2D context unavailable');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
      const base64 = dataUrl.split(',')[1];

      const r = await fetch('/api/vision/snapshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          familyId: FAMILY_ID,
          image: base64,
          triggerReason: 'command',
          evaluate: true,
        }),
      });
      const data = await r.json();
      if (data.ok) {
        setResponse(
          `${data.description}\n\n` +
          `Obiekty: ${data.objects?.join(', ') || '—'}\n` +
          `Nastrój: ${data.mood || '—'}\n` +
          (data.trigger?.triggered ? `⚡ Trigger: ${data.trigger.action}\n${data.trigger.message}` : '')
        );
        loadSnapshots();
      } else {
        setError(data.error || 'Snapshot failed');
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    setLoading(true);
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          visionEnabled,
          visionModel,
          visionIntervalSec,
        }),
      });
      setShowSettings(false);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    return () => stopCamera();
  }, []);

  return (
    <div className="h-full flex flex-col bg-[#0f0f1a] text-gray-200">
      {/* Header */}
      <header className="px-6 py-4 border-b border-white/5 flex items-center gap-3">
        <Eye size={22} className="text-[#a855f7]" />
        <h1 className="text-lg font-semibold">Wizja (Moondream)</h1>
        <span className="text-xs text-gray-500 ml-2">v0.3.17 · L7</span>
        <div className="ml-auto flex gap-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-1.5 rounded hover:bg-white/5"
          >
            <Settings size={16} />
          </button>
        </div>
      </header>

      {/* Settings */}
      {showSettings && (
        <div className="px-6 py-4 border-b border-white/5 bg-black/30 space-y-2">
          <h3 className="text-sm font-semibold text-gray-300">Konfiguracja wizji</h3>
          <label className="flex items-center gap-2 text-xs">
            <input type="checkbox" checked={visionEnabled} onChange={(e) => setVisionEnabled(e.target.checked)} />
            Wizja włączona
          </label>
          <div className="grid grid-cols-2 gap-2">
            <select
              value={visionModel}
              onChange={(e) => setVisionModel(e.target.value)}
              className="bg-black/40 text-xs px-2 py-1.5 rounded border border-white/10"
            >
              <option value="moondream:1.8b">moondream:1.8b (lokalnie, 1.8B)</option>
              <option value="llava:7b">llava:7b (lokalnie, 7B)</option>
              <option value="llava:13b">llava:13b (lokalnie, 13B)</option>
              <option value="glm-4v">glm-4v (chmura Z.ai)</option>
            </select>
            <input
              type="number"
              value={visionIntervalSec}
              onChange={(e) => setVisionIntervalSec(parseInt(e.target.value))}
              min={10}
              max={3600}
              className="bg-black/40 text-xs px-2 py-1.5 rounded border border-white/10"
              placeholder="Interwał auto-snapshot (s)"
            />
          </div>
          <button
            onClick={saveSettings}
            disabled={loading}
            className="px-3 py-1 text-xs bg-[#a855f7]/20 text-[#a855f7] hover:bg-[#a855f7]/30 rounded"
          >
            Zapisz
          </button>
          <p className="text-[10px] text-gray-500">
            Wymaga Ollama z modelem Moondream (ollama pull moondream:1.8b) — działa lokalnie, bez chmury.
          </p>
        </div>
      )}

      {/* Live camera */}
      <div className="px-6 py-4 border-b border-white/5">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-full aspect-video bg-black rounded border border-white/10"
            />
            {!streaming && (
              <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-xs">
                Kamera wyłączona
              </div>
            )}
          </div>
          <div className="flex flex-col gap-2 w-32">
            <button
              onClick={streaming ? stopCamera : startCamera}
              className={`flex items-center justify-center gap-2 p-3 rounded text-xs ${
                streaming ? 'bg-red-500/20 text-red-300' : 'bg-green-500/20 text-green-300'
              }`}
            >
              {streaming ? <Pause size={14} /> : <Play size={14} />}
              {streaming ? 'Stop' : 'Start'}
            </button>
            <button
              onClick={captureOnce}
              disabled={!streaming || loading}
              className="flex items-center justify-center gap-2 p-3 rounded text-xs bg-[#a855f7]/20 text-[#a855f7] disabled:opacity-50"
            >
              <Camera size={14} />
              {loading ? 'Analizuję...' : 'Snap'}
            </button>
          </div>
        </div>
        {error && (
          <div className="mt-2 p-2 rounded bg-red-500/10 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle size={14} />
            {error}
          </div>
        )}
        {response && (
          <div className="mt-2 p-3 rounded bg-[#a855f7]/10 text-[#a855f7] text-xs whitespace-pre-wrap">
            {response}
          </div>
        )}
      </div>

      {/* Snapshots history */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <h3 className="text-sm font-semibold text-gray-300 mb-3">
          Ostatnie snapshoty ({snapshots.length})
        </h3>
        {snapshots.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-sm">
            Brak snapshotów. Uruchom kamerę i kliknij &quot;Snap&quot; aby przechwycić scenę.
          </div>
        ) : (
          <div className="space-y-2">
            {snapshots.map((snap) => (
              <div key={snap.id} className="p-3 rounded border border-white/5 bg-black/30">
                <div className="flex items-center gap-2 text-xs mb-1">
                  <span className="text-[#a855f7]">{snap.model}</span>
                  <span className="text-gray-500">·</span>
                  <span className="text-gray-400">{snap.triggerReason}</span>
                  {snap.moodLabel && (
                    <>
                      <span className="text-gray-500">·</span>
                      <span className="text-yellow-300">{snap.moodLabel}</span>
                    </>
                  )}
                  {snap.triggeredAction && (
                    <>
                      <span className="text-gray-500">·</span>
                      <span className="text-green-300">⚡ {snap.triggeredAction}</span>
                    </>
                  )}
                  <span className="ml-auto text-gray-500 text-[10px]">
                    {new Date(snap.capturedAt).toLocaleString('pl-PL')}
                  </span>
                </div>
                <p className="text-xs text-gray-300">{snap.description}</p>
                {snap.detectedObjects.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {snap.detectedObjects.map((obj, i) => (
                      <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-gray-400">
                        {obj}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
