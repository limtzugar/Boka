'use client';

// ═══════════════════════════════════════════════════════════
// BOKA — Home Assistant Tab (v0.3.17)
// L11 Desktop/Home Manipulation
// Most między BOKA a fizycznym domem.
// ═══════════════════════════════════════════════════════════

import { useState, useEffect, useCallback } from 'react';
import { Home, Lightbulb, Thermometer, Power, RefreshCw, Settings, Plus, Cpu } from 'lucide-react';

const FAMILY_ID = 'boka-family';

interface HAEntity {
  id: string;
  entityId: string;
  friendlyName: string;
  domain: string;
  state: string;
  attributes: any;
  lastUpdated: string | null;
}

interface HAStatus {
  ok: boolean;
  version?: string;
  locationName?: string;
  error?: string;
}

const DOMAIN_ICONS: Record<string, any> = {
  light: Lightbulb,
  switch: Power,
  sensor: Thermometer,
  climate: Thermometer,
  media_player: Cpu,
};

const DOMAIN_COLORS: Record<string, string> = {
  light: '#6ee77c',
  switch: '#6ec6e7',
  sensor: '#e7d76e',
  climate: '#e7a86e',
  media_player: '#a855f7',
};

export function HomeAssistantTab() {
  const [status, setStatus] = useState<HAStatus | null>(null);
  const [entities, setEntities] = useState<HAEntity[]>([]);
  const [filterDomain, setFilterDomain] = useState<string>('');
  const [command, setCommand] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Settings state
  const [haUrl, setHaUrl] = useState('');
  const [haToken, setHaToken] = useState('');
  const [haEnabled, setHaEnabled] = useState(false);

  const checkStatus = useCallback(async () => {
    try {
      const r = await fetch(`/api/homeassistant/status?familyId=${FAMILY_ID}`);
      const data = await r.json();
      setStatus(data);
    } catch (e: any) {
      setStatus({ ok: false, error: e.message });
    }
  }, []);

  const loadEntities = useCallback(async () => {
    try {
      const params = new URLSearchParams({ familyId: FAMILY_ID });
      if (filterDomain) params.set('domain', filterDomain);
      const r = await fetch(`/api/homeassistant/entities?${params}`);
      const data = await r.json();
      setEntities(data.entities ?? []);
    } catch (e) {
      console.error(e);
    }
  }, [filterDomain]);

  useEffect(() => {
    checkStatus();
    loadEntities();
  }, [checkStatus, loadEntities]);

  async function syncEntities() {
    setLoading(true);
    try {
      const r = await fetch(`/api/homeassistant/status?familyId=${FAMILY_ID}`, { method: 'POST' });
      const data = await r.json();
      if (data.ok) {
        setResponse(`Zsynchronizowano ${data.synced} encji z ${Object.keys(data.byDomain ?? {}).length} domen.`);
        loadEntities();
      } else {
        setResponse(`✗ ${data.error}`);
      }
    } catch (e: any) {
      setResponse(`✗ ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function sendCommand() {
    if (!command.trim()) return;
    setLoading(true);
    setResponse('');
    try {
      const r = await fetch('/api/homeassistant/service', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ familyId: FAMILY_ID, message: command }),
      });
      const data = await r.json();
      setResponse(data.response ?? data.error ?? 'Brak odpowiedzi');
      if (data.matched) loadEntities();
    } catch (e: any) {
      setResponse(`✗ ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function toggleEntity(entity: HAEntity) {
    const domain = entity.domain;
    const service = entity.state === 'on' ? 'turn_off' : 'turn_on';
    setLoading(true);
    try {
      const r = await fetch('/api/homeassistant/service', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          familyId: FAMILY_ID,
          domain,
          service,
          data: { entity_id: entity.entityId },
        }),
      });
      const data = await r.json();
      if (data.ok) {
        setTimeout(loadEntities, 500);
      } else {
        setResponse(`✗ ${data.error}`);
      }
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    setLoading(true);
    try {
      // Save via /api/settings (which calls saveSettings in ai-providers.ts)
      const r = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          haUrl,
          haToken,
          haEnabled,
        }),
      });
      const data = await r.json();
      if (data.ok) {
        setShowSettings(false);
        checkStatus();
      }
    } finally {
      setLoading(false);
    }
  }

  // Group entities by domain
  const domains = Array.from(new Set(entities.map((e) => e.domain))).sort();
  const filteredEntities = filterDomain ? entities.filter((e) => e.domain === filterDomain) : entities;

  return (
    <div className="h-full flex flex-col bg-[#0f0f1a] text-gray-200">
      {/* Header */}
      <header className="px-6 py-4 border-b border-white/5 flex items-center gap-3">
        <Home size={22} className="text-[#6ee7b2]" />
        <h1 className="text-lg font-semibold">Home Assistant</h1>
        <span className="text-xs text-gray-500 ml-2">v0.3.17 · L11</span>
        <div className="ml-auto flex items-center gap-2">
          {status && (
            <span className={`text-xs ${status.ok ? 'text-green-300' : 'text-red-300'}`}>
              ● {status.ok ? `${status.locationName ?? 'HA'} ${status.version ?? ''}` : 'Offline'}
            </span>
          )}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-1.5 rounded hover:bg-white/5"
          >
            <Settings size={16} />
          </button>
          <button
            onClick={syncEntities}
            disabled={loading}
            className="flex items-center gap-1 px-2 py-1 text-xs bg-white/5 hover:bg-white/10 rounded"
          >
            <RefreshCw size={12} className={loading ? 'animate-spin' : ''} />
            Sync
          </button>
        </div>
      </header>

      {/* Settings panel */}
      {showSettings && (
        <div className="px-6 py-4 border-b border-white/5 bg-black/30 space-y-2">
          <h3 className="text-sm font-semibold text-gray-300">Konfiguracja Home Assistant</h3>
          <div className="grid grid-cols-3 gap-2">
            <input
              value={haUrl}
              onChange={(e) => setHaUrl(e.target.value)}
              placeholder="http://homeassistant.local:8123"
              className="bg-black/40 text-xs px-2 py-1.5 rounded border border-white/10 col-span-2"
            />
            <label className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={haEnabled}
                onChange={(e) => setHaEnabled(e.target.checked)}
              />
              Włączony
            </label>
          </div>
          <input
            value={haToken}
            onChange={(e) => setHaToken(e.target.value)}
            placeholder="Long-Lived Access Token (z HA Profile)"
            type="password"
            className="w-full bg-black/40 text-xs px-2 py-1.5 rounded border border-white/10"
          />
          <button
            onClick={saveSettings}
            disabled={loading}
            className="px-3 py-1 text-xs bg-[#6ee7b2]/20 text-[#6ee7b2] hover:bg-[#6ee7b2]/30 rounded"
          >
            Zapisz
          </button>
          <p className="text-[10px] text-gray-500">
            Token: HA → Profile → Long-Lived Access Tokens → Create Token.
          </p>
        </div>
      )}

      {/* Command bar */}
      <div className="px-6 py-3 border-b border-white/5">
        <div className="flex gap-2">
          <input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder='np. "włącz światło w salonie" albo "wyłącz przełącznik w kuchni"'
            className="flex-1 bg-black/40 text-sm px-3 py-2 rounded border border-white/10"
            onKeyDown={(e) => e.key === 'Enter' && sendCommand()}
          />
          <button
            onClick={sendCommand}
            disabled={loading || !command.trim()}
            className="px-4 py-2 text-xs bg-[#6ee7b2]/20 text-[#6ee7b2] hover:bg-[#6ee7b2]/30 rounded disabled:opacity-50"
          >
            Wyślij
          </button>
        </div>
        {response && (
          <div className="mt-2 p-2 rounded bg-[#6ee7b2]/10 text-[#6ee7b2] text-xs">{response}</div>
        )}
      </div>

      {/* Domain filter */}
      <div className="px-6 py-2 flex gap-1 border-b border-white/5 overflow-x-auto">
        <button
          onClick={() => setFilterDomain('')}
          className={`px-2 py-1 text-xs rounded whitespace-nowrap ${
            !filterDomain ? 'bg-[#6ee7b2]/20 text-[#6ee7b2]' : 'text-gray-400 hover:bg-white/5'
          }`}
        >
          Wszystko ({entities.length})
        </button>
        {domains.map((d) => (
          <button
            key={d}
            onClick={() => setFilterDomain(d)}
            className={`px-2 py-1 text-xs rounded whitespace-nowrap ${
              filterDomain === d ? 'bg-[#6ee7b2]/20 text-[#6ee7b2]' : 'text-gray-400 hover:bg-white/5'
            }`}
          >
            {d} ({entities.filter((e) => e.domain === d).length})
          </button>
        ))}
      </div>

      {/* Entities grid */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {entities.length === 0 ? (
          <div className="text-center py-12 text-gray-500 text-sm">
            {status?.ok
              ? 'Brak zsynchronizowanych encji. Kliknij "Sync" aby pobrać z HA.'
              : 'Home Assistant nie jest skonfigurowany. Kliknij ⚙️ aby ustawić URL i token.'}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredEntities.slice(0, 200).map((entity) => {
              const Icon = DOMAIN_ICONS[entity.domain] ?? Power;
              const color = DOMAIN_COLORS[entity.domain] ?? '#6ec6e7';
              const isOn = entity.state === 'on';
              return (
                <button
                  key={entity.id}
                  onClick={() => ['light', 'switch', 'media_player', 'climate'].includes(entity.domain) && toggleEntity(entity)}
                  className={`p-3 rounded border border-white/5 text-left transition-colors ${
                    isOn ? 'bg-white/10' : 'bg-black/30 hover:bg-black/40'
                  } ${!['light', 'switch', 'media_player', 'climate'].includes(entity.domain) ? 'cursor-default' : ''}`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon size={14} style={{ color }} />
                    <span className="text-xs font-medium truncate">{entity.friendlyName}</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className={`px-1.5 py-0.5 rounded ${isOn ? 'bg-green-500/20 text-green-300' : 'text-gray-500'}`}>
                      {entity.state}
                    </span>
                    <span className="text-gray-600">{entity.domain}</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
