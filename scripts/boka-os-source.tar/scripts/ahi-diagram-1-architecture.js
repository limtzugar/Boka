// Diagram 1: Full Architecture Diagram - AHI-BOKA 6-Layer System
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 50px; }

  .title { font-size: 28px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 8px; letter-spacing: 2px; }
  .subtitle { font-size: 14px; color: #97948e; text-align: center; margin-bottom: 40px; }

  .layers { display: flex; flex-direction: column; gap: 14px; }

  .layer {
    display: flex; align-items: stretch; border-radius: 10px; overflow: hidden;
    border: 1px solid #4b4636; position: relative;
  }
  .layer-num {
    width: 56px; display: flex; align-items: center; justify-content: center;
    font-size: 22px; font-weight: 900; color: #0b0b0a; flex-shrink: 0;
  }
  .layer-body { flex: 1; padding: 16px 20px; }
  .layer-title { font-size: 16px; font-weight: 700; margin-bottom: 8px; }
  .layer-desc { font-size: 12px; color: #97948e; margin-bottom: 10px; line-height: 1.5; }
  .modules { display: flex; flex-wrap: wrap; gap: 6px; }
  .mod {
    font-size: 11px; padding: 4px 10px; border-radius: 4px;
    background: rgba(214,183,93,0.08); border: 1px solid rgba(214,183,93,0.2); color: #d6b75d;
  }

  .l6 .layer-num { background: #d6b75d; }
  .l6 { background: rgba(214,183,93,0.04); }
  .l5 .layer-num { background: #c7ba93; color: #0b0b0a; }
  .l5 { background: rgba(199,186,147,0.04); }
  .l4 .layer-num { background: #75b189; }
  .l4 { background: rgba(117,177,137,0.04); }
  .l4 .mod { background: rgba(117,177,137,0.08); border-color: rgba(117,177,137,0.2); color: #75b189; }
  .l3 .layer-num { background: #7b96b1; }
  .l3 { background: rgba(123,150,177,0.04); }
  .l3 .mod { background: rgba(123,150,177,0.08); border-color: rgba(123,150,177,0.2); color: #7b96b1; }
  .l2 .layer-num { background: #8672c3; }
  .l2 { background: rgba(134,114,195,0.04); }
  .l2 .mod { background: rgba(134,114,195,0.08); border-color: rgba(134,114,195,0.2); color: #8672c3; }
  .l1 .layer-num { background: #b69e6f; }
  .l1 { background: rgba(182,158,111,0.04); }
  .l1 .mod { background: rgba(182,158,111,0.08); border-color: rgba(182,158,111,0.2); color: #b69e6f; }

  .flow-arrows {
    position: absolute; right: 18px; top: 50%; transform: translateY(-50%);
    display: flex; flex-direction: column; gap: 6px; align-items: center;
  }
  .arrow-down { color: #4b4636; font-size: 18px; }
  .arrow-label { font-size: 9px; color: #97948e; writing-mode: vertical-rl; }

  .side-extensions {
    position: absolute; right: -220px; top: 0; bottom: 0; width: 210px;
    display: flex; flex-direction: column; gap: 10px; justify-content: center;
  }
  .ext-box {
    padding: 10px; border-radius: 6px; background: #161614; border: 1px solid #4b4636;
    font-size: 11px; color: #97948e;
  }
  .ext-box .ext-title { color: #d6b75d; font-weight: 600; margin-bottom: 4px; font-size: 12px; }

  .main-container { position: relative; display: flex; }
  .left-layers { flex: 1; }
  .right-extensions { width: 230px; padding-left: 20px; display: flex; flex-direction: column; gap: 10px; justify-content: center; }
  .ext-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .ext-card-title { color: #d6b75d; font-weight: 700; font-size: 13px; margin-bottom: 6px; }
  .ext-card-body { font-size: 11px; color: #97948e; line-height: 1.5; }

  .connector-line { position: absolute; }

  .legend { display: flex; gap: 20px; justify-content: center; margin-top: 20px; }
  .legend-item { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #97948e; }
  .legend-dot { width: 10px; height: 10px; border-radius: 2px; }
</style></head><body>
  <div class="title">AHI — Artificial Harmonizing Intelligence</div>
  <div class="subtitle">Full 6-Layer Architecture + 8 Extensions | Family-First Scale</div>

  <div class="main-container">
    <div class="left-layers">
      <div class="layers">
        <div class="layer l6">
          <div class="layer-num">6</div>
          <div class="layer-body">
            <div class="layer-title">HUMAN OVERSIGHT LAYER</div>
            <div class="layer-desc">Humans remain part of the system — define values, approve critical interventions, audit AI behavior, supervise ethical boundaries, tune equilibrium thresholds</div>
            <div class="modules">
              <span class="mod">Value Definition</span><span class="mod">Intervention Approval</span><span class="mod">Behavior Audit</span><span class="mod">Boundary Supervision</span><span class="mod">Threshold Tuning</span>
            </div>
          </div>
        </div>

        <div class="layer l5">
          <div class="layer-num">5</div>
          <div class="layer-body">
            <div class="layer-title">ETHICS & ALIGNMENT LAYER</div>
            <div class="layer-desc">Prevent authoritarian misuse — audit logs, explainability, human veto, intervention transparency, decentralized governance, ethical policy engine, disagreement protection, privacy</div>
            <div class="modules">
              <span class="mod">Audit Logs</span><span class="mod">Explainability</span><span class="mod">Human Veto</span><span class="mod">Transparency</span><span class="mod">Decentralized Governance</span><span class="mod">Ethics Engine</span><span class="mod">Disagreement Protection</span><span class="mod">Privacy</span>
            </div>
          </div>
        </div>

        <div class="layer l4">
          <div class="layer-num">4</div>
          <div class="layer-body">
            <div class="layer-title">HARMONIZATION LAYER</div>
            <div class="layer-desc">Subtle stabilization — slow escalation, contextualize debates, highlight uncertainty, promote de-escalation, detect manipulation, encourage reflective dialogue</div>
            <div class="modules">
              <span class="mod">Escalation Slowdown</span><span class="mod">Context Enrichment</span><span class="mod">Uncertainty Highlight</span><span class="mod">De-escalation</span><span class="mod">Manipulation Detection</span><span class="mod">Reflective Dialogue</span>
            </div>
          </div>
        </div>

        <div class="layer l3">
          <div class="layer-num">3</div>
          <div class="layer-body">
            <div class="layer-title">PREDICTION LAYER</div>
            <div class="layer-desc">Simulate possible futures — multi-agent simulations, social behavior forecasting, intervention outcome simulation, probabilistic forecasting, cascade analysis</div>
            <div class="modules">
              <span class="mod">Multi-Agent Sim</span><span class="mod">Behavior Forecast</span><span class="mod">Intervention Sim</span><span class="mod">Probabilistic Forecast</span><span class="mod">Cascade Analysis</span>
            </div>
          </div>
        </div>

        <div class="layer l2">
          <div class="layer-num">2</div>
          <div class="layer-body">
            <div class="layer-title">SYSTEM MODELING LAYER</div>
            <div class="layer-desc">Understand WHY instability appears — causal inference, graph-based social dynamics, narrative propagation, tension maps, system dependency, cybernetic feedback loops</div>
            <div class="modules">
              <span class="mod">Causal Inference</span><span class="mod">Social Dynamics Graph</span><span class="mod">Narrative Mapping</span><span class="mod">Tension Maps</span><span class="mod">Dependency Analysis</span><span class="mod">Feedback Loops</span>
            </div>
          </div>
        </div>

        <div class="layer l1">
          <div class="layer-num">1</div>
          <div class="layer-body">
            <div class="layer-title">SENSING LAYER</div>
            <div class="layer-desc">Observe signals from digital and real-world systems — NLP, emotion detection, conflict escalation, misinformation, anomaly detection, social graph, environment, trends</div>
            <div class="modules">
              <span class="mod">NLP Analysis</span><span class="mod">Emotion Detection</span><span class="mod">Conflict Escalation</span><span class="mod">Misinformation Patterns</span><span class="mod">Anomaly Detection</span><span class="mod">Social Graph</span><span class="mod">Environmental Signals</span><span class="mod">Trend Monitoring</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="right-extensions">
      <div class="ext-card">
        <div class="ext-card-title">Multi-Channel</div>
        <div class="ext-card-body">Telegram, Discord, Matrix, Signal, WhatsApp, Email, Web — pluggable connectors</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Skill Ecosystem</div>
        <div class="ext-card-body">agentskills.io compliant, local + remote, versioned, lazy-loaded, evolving</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Swarm Agents</div>
        <div class="ext-card-body">Observer, Mediator, Ethics, Memory, Forecast, Simulation, Governance, Channel agents</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Equilibrium Engine</div>
        <div class="ext-card-body">Conflict reduction, info quality, emotional stability, diversity, resilience, coherence</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Self Memory</div>
        <div class="ext-card-body">Episodic, semantic, workflow, reflection memory — Icarus-inspired</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Meta-Skill Factory</div>
        <div class="ext-card-body">Workflow extraction, pattern detection, auto-documentation, self-improving</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">Skill Registries</div>
        <div class="ext-card-body">HermesHub, SkillDock, OpenClaw — semantic retrieval, trust scores</div>
      </div>
      <div class="ext-card">
        <div class="ext-card-title">6 Skill Categories</div>
        <div class="ext-card-body">Observation, Harmonization, Knowledge, Memory, Evolution, Governance, Diagram</div>
      </div>
    </div>
  </div>

  <div class="legend">
    <div class="legend-item"><div class="legend-dot" style="background:#d6b75d"></div>Human Oversight</div>
    <div class="legend-item"><div class="legend-dot" style="background:#c7ba93"></div>Ethics</div>
    <div class="legend-item"><div class="legend-dot" style="background:#75b189"></div>Harmonization</div>
    <div class="legend-item"><div class="legend-dot" style="background:#7b96b1"></div>Prediction</div>
    <div class="legend-item"><div class="legend-dot" style="background:#8672c3"></div>Modeling</div>
    <div class="legend-item"><div class="legend-dot" style="background:#b69e6f"></div>Sensing</div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/01-full-architecture.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 1 done');
})();
