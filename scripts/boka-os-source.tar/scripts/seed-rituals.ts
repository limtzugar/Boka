// ═══════════════════════════════════════════════════════════
// Seed rituals into existing BOKA database
// Run: npx tsx /home/z/my-project/scripts/seed-rituals.ts
// ═══════════════════════════════════════════════════════════

import { db } from '../src/lib/db';

async function seedRituals() {
  console.log('📅 Seeding rituals...');

  // Find family
  const family = await db.family.findFirst();
  if (!family) {
    console.error('❌ No family found! Run main seed first.');
    process.exit(1);
  }

  // Find members
  const members = await db.familyMember.findMany({ where: { familyId: family.id } });
  const syn = members.find(m => m.role === 'child');

  // Check if rituals already exist
  const existing = await db.ritual.findMany({ where: { familyId: family.id } });
  if (existing.length > 0) {
    console.log(`⚠️  Already ${existing.length} rituals. Skipping.`);
    process.exit(0);
  }

  const rituals = [
    {
      familyId: family.id,
      name: 'poranne_powitanie',
      type: 'daily',
      time: '07:00',
      prompt: 'Dzień dobry! ☀️ Nowy dzień — zapytaj krótko jak kto spał, wspomnij o pogodzie i czy są jakieś plany na dziś. Bądź ciepły i naturalny, nie za długi.',
    },
    {
      familyId: family.id,
      name: 'wieczorne_podsumowanie',
      type: 'daily',
      time: '20:00',
      prompt: 'Dobry wieczór! 🌙 Zapytaj jak minął dzień, czy coś dobrego się wydarzyło. Bądź czuły i uważny — to czas na refleksję i wyciszenie.',
    },
    {
      familyId: family.id,
      memberId: syn?.id,
      name: 'po_szkole',
      type: 'daily',
      time: '14:30',
      prompt: 'Hej Jaś! 🎒 Jak w szkole? Co ciekawego się działo? Pogadaj z nim o jego dzień — Minecraft, LEGO, SuperThings — daj mu przestrzeń do opowiedzenia.',
    },
    {
      familyId: family.id,
      name: 'weekend_poranek',
      type: 'weekly',
      time: '09:00',
      dayOfWeek: 6,
      prompt: 'Weekend! 🎉 Zapytaj co planują na weekend, czy mają jakieś pomysły. Może wycieczka? Może grilling? Bądź entuzjastyczny!',
    },
  ];

  for (const ritual of rituals) {
    await db.ritual.create({ data: { ...ritual, isActive: true } });
    console.log(`  ✅ ${ritual.name} (${ritual.type} @ ${ritual.time || 'N/A'})`);
  }

  console.log(`\n✅ ${rituals.length} rituals seeded!`);
  await db.$disconnect();
}

seedRituals().catch(e => {
  console.error(e);
  process.exit(1);
});
