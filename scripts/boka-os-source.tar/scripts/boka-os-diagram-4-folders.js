// Diagram: Folder Structure + Agent Layer + Open Source Integration
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Liberation Mono', monospace; width: 1600px; padding: 40px; font-size: 12px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 4px; font-family: 'Inter', sans-serif; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 30px; font-family: 'Inter', sans-serif; }

  .cols { display: flex; gap: 16px; }

  /* Folder tree */
  .folder-tree {
    width: 460px; padding: 16px; border-radius: 10px; background: #161614;
    border: 1px solid #4b4636; font-family: 'Liberation Mono', monospace;
    line-height: 1.5; white-space: pre; overflow-x: auto; font-size: 11px; color: #97948e;
  }
  .ft-dir { color: #7b96b1; font-weight: 600; }
  .ft-new { color: #d6b75d; }
  .ft-existing { color: #75b189; }
  .ft-file { color: #c7ba93; }

  /* Agent grid */
  .agent-grid {
    flex: 1; display: grid; grid-template-columns: 1fr 1fr; gap: 8px; align-content: start;
  }
  .ag-card {
    padding: 10px 12px; border-radius: 6px; background: #161614; border: 1px solid #4b4636;
  }
  .ag-name { font-size: 11px; font-weight: 700; font-family: 'Inter', sans-serif; margin-bottom: 2px; }
  .ag-model { font-size: 9px; padding: 1px 5px; border-radius: 2px; display: inline-block; margin-bottom: 2px; }
  .ag-desc { font-size: 10px; color: #97948e; line-height: 1.3; font-family: 'Inter', sans-serif; }

  .ag-existing { border-left: 3px solid #75b189; }
  .ag-existing .ag-name { color: #75b189; }
  .ag-existing .ag-model { background: rgba(117,177,137,0.15); color: #75b189; }
  .ag-new { border-left: 3px solid #d6b75d; }
  .ag-new .ag-name { color: #d6b75d; }
  .ag-new .ag-model { background: rgba(214,183,93,0.15); color: #d6b75d; }
  .ag-ahi { border-left: 3px solid #8672c3; }
  .ag-ahi .ag-name { color: #8672c3; }
  .ag-ahi .ag-model { background: rgba(134,114,195,0.15); color: #8672c3; }

  /* Repos */
  .repos { margin-top: 16px; }
  .repo-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 10px; }
  .repo-card {
    padding: 10px; border-radius: 6px; background: #161614; border: 1px solid #4b4636;
  }
  .repo-name { font-size: 11px; font-weight: 700; color: #d6b75d; margin-bottom: 2px; font-family: 'Inter', sans-serif; }
  .repo-desc { font-size: 9px; color: #97948e; line-height: 1.3; font-family: 'Inter', sans-serif; }
  .repo-url { font-size: 8px; color: #4b4636; margin-top: 2px; }
  .repo-diff { font-size: 8px; margin-top: 2px; }
  .repo-diff.easy { color: #75b189; }
  .repo-diff.medium { color: #b69e6f; }
  .repo-diff.hard { color: #be766f; }

  .section-label { font-size: 14px; font-weight: 700; color: #d6b75d; font-family: 'Inter', sans-serif; margin-bottom: 8px; }
</style></head><body>
  <div class="title">BOKA OS Extended Architecture</div>
  <div class="subtitle">Folder Structure + Agent Layer + Open Source Repositories</div>

  <div class="cols">
    <div class="folder-tree"><span class="ft-dir">boka-os/</span>
<span class="ft-existing">├── src/                    # EXISTING - Next.js app</span>
<span class="ft-existing">│   ├── app/                # API routes + pages</span>
<span class="ft-existing">│   ├── components/         # React components</span>
<span class="ft-existing">│   ├── hooks/              # 14 custom hooks</span>
<span class="ft-existing">│   └── lib/                # agent-system, store, etc.</span>
<span class="ft-new">├── boka_os/                # NEW - Python orchestration</span>
<span class="ft-new">│   ├── langgraph/          # LangGraph nervous system</span>
<span class="ft-new">│   │   ├── graph.py        # Main StateGraph</span>
<span class="ft-new">│   │   ├── state.py        # BokaState TypedDict</span>
<span class="ft-new">│   │   └── nodes/          # Graph nodes</span>
<span class="ft-new">│   ├── agents/             # Specialized agents</span>
<span class="ft-new">│   │   ├── family/         # Family OS agents</span>
<span class="ft-new">│   │   └── ahi/            # AHI Official agents</span>
<span class="ft-new">│   ├── memory/             # Memory management</span>
<span class="ft-new">│   │   ├── qdrant_client.py</span>
<span class="ft-new">│   │   ├── obsidian_sync.py</span>
<span class="ft-new">│   │   └── postgres_client.py</span>
<span class="ft-new">│   ├── skills/             # Dynamic skill system</span>
<span class="ft-new">│   │   ├── registry.py     # Skill registry</span>
<span class="ft-new">│   │   ├── loader.py       # Dynamic loader</span>
<span class="ft-new">│   │   └── factory.py      # Meta-Skill Factory</span>
<span class="ft-new">│   ├── robot/              # ROS2 integration</span>
<span class="ft-new">│   │   ├── bridge.py       # ROS2 bridge</span>
<span class="ft-new">│   │   └── safety.py       # Human approval gate</span>
<span class="ft-new">│   └── api/                # FastAPI bridge</span>
<span class="ft-new">│       └── main.py         # Connects to Next.js</span>
<span class="ft-new">├── obsidian-vault/         # NEW - Human-readable memory</span>
<span class="ft-new">│   ├── Daily/              # Daily notes</span>
<span class="ft-new">│   ├── People/             # Per-member notes</span>
<span class="ft-new">│   ├── Legal/              # Act critiques</span>
<span class="ft-new">│   ├── Projects/           # Project tracking</span>
<span class="ft-new">│   └── Templates/          # Note templates</span>
<span class="ft-new">├── docker/                 # NEW - Container config</span>
<span class="ft-new">│   ├── docker-compose.yml</span>
<span class="ft-new">│   ├── postgres.yml</span>
<span class="ft-new">│   ├── qdrant.yml</span>
<span class="ft-new">│   └── langgraph.yml</span>
<span class="ft-existing">├── prisma/                 # EXISTING - DB schema</span>
<span class="ft-existing">├── electron/               # EXISTING - Desktop</span>
<span class="ft-existing">└── public/                 # EXISTING - Static</span></div>

    <div>
      <div class="section-label">Agent Layer — 26 Agents</div>
      <div class="agent-grid">
        <div class="ag-card ag-existing"><div class="ag-name">Observer</div><div class="ag-model">existing</div><div class="ag-desc">Monitor channels, detect signals</div></div>
        <div class="ag-card ag-existing"><div class="ag-name">Mediator</div><div class="ag-model">existing</div><div class="ag-desc">De-escalation, reflective dialogue</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Decision</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Multi-factor decision analysis</div></div>
        <div class="ag-card ag-ahi"><div class="ag-name">Legal</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Act critique, compliance, precedent</div></div>
        <div class="ag-card ag-ahi"><div class="ag-name">Administrative</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Gov/corp policy analysis</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Finance</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Budget, forecasting, harmony score</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Education</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Learning, curriculum, Jaś focus</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Mathematics</div><div class="ag-model">DeepSeek</div><div class="ag-desc">Step-by-step math reasoning</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Art</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Creative generation, art history</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Movies</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Film analysis, recommendations</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Story</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Storytelling, family lore, kids</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Cartoon & Lore</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Pop culture, animation, lore</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Minecraft</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Game guides, building ideas</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Sprunki</div><div class="ag-model">GPT-4o-mini</div><div class="ag-desc">Music creation, character lore</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Poppy Playtime</div><div class="ag-model">GPT-4o-mini</div><div class="ag-desc">Game lore, safety-aware</div></div>
        <div class="ag-card ag-new"><div class="ag-name">GitHub Monitor</div><div class="ag-model">Gemini Flash</div><div class="ag-desc">Repo tracking, PR analysis</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Research</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Deep research, paper analysis</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Health</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Wellbeing, nutrition, exercise</div></div>
        <div class="ag-card ag-existing"><div class="ag-name">Safety</div><div class="ag-model">existing</div><div class="ag-desc">Child safety, content filter</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Robot Control</div><div class="ag-model">local</div><div class="ag-desc">ROS2 commands, navigation</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Robot Perception</div><div class="ag-model">local</div><div class="ag-desc">Vision, SLAM, object detection</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Memory Curator</div><div class="ag-model">GPT-4o-mini</div><div class="ag-desc">Memory cleanup, linking, archival</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Planner</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Multi-step planning, scheduling</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Reflection</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Self-evaluation, learning</div></div>
        <div class="ag-card ag-new"><div class="ag-name">Harmony</div><div class="ag-model">Claude 3.5</div><div class="ag-desc">Equilibrium engine, balance</div></div>
        <div class="ag-card ag-ahi"><div class="ag-name">Forecast</div><div class="ag-model">GPT-4o</div><div class="ag-desc">Impact prediction, scenarios</div></div>
      </div>
    </div>
  </div>

  <div class="repos">
    <div class="section-label">Open Source Repository Recommendations</div>
    <div class="repo-grid">
      <div class="repo-card"><div class="repo-name">LangGraph</div><div class="repo-desc">Stateful agent orchestration</div><div class="repo-url">github.com/langchain-ai/langgraph</div><div class="repo-diff medium">Medium | Core orchestration</div></div>
      <div class="repo-card"><div class="repo-name">Qdrant</div><div class="repo-desc">Vector similarity search engine</div><div class="repo-url">github.com/qdrant/qdrant</div><div class="repo-diff easy">Easy | Memory backend</div></div>
      <div class="repo-card"><div class="repo-name">Mem0</div><div class="repo-desc">Long-term memory layer for AI</div><div class="repo-url">github.com/mem0ai/mem0</div><div class="repo-diff easy">Easy | Memory mgmt</div></div>
      <div class="repo-card"><div class="repo-name">LlamaIndex</div><div class="repo-desc">Data framework for LLM apps</div><div class="repo-url">github.com/run-llama/llama_index</div><div class="repo-diff medium">Medium | RAG pipeline</div></div>
      <div class="repo-card"><div class="repo-name">CrewAI</div><div class="repo-desc">Multi-agent orchestration</div><div class="repo-url">github.com/crewAIInc/crewAI</div><div class="repo-diff medium">Medium | Agent framework</div></div>
      <div class="repo-card"><div class="repo-name">Open WebUI</div><div class="repo-desc">Chat UI for Ollama/OpenAI</div><div class="repo-url">github.com/open-webui/open-webui</div><div class="repo-diff easy">Easy | Alt UI</div></div>
      <div class="repo-card"><div class="repo-name">Whisper</div><div class="repo-desc">OpenAI speech recognition</div><div class="repo-url">github.com/openai/whisper</div><div class="repo-diff easy">Easy | ASR upgrade</div></div>
      <div class="repo-card"><div class="repo-name">Kokoro</div><div class="repo-desc">Lightweight TTS, fast, natural</div><div class="repo-url">github.com/hexgrad/kokoro</div><div class="repo-diff medium">Medium | TTS upgrade</div></div>
      <div class="repo-card"><div class="repo-name">XTTS v2</div><div class="repo-desc">Voice cloning + multilingual TTS</div><div class="repo-url">github.com/coqui-ai/TTS</div><div class="repo-diff hard">Hard | Voice cloning</div></div>
      <div class="repo-card"><div class="repo-name">ROS2</div><div class="repo-desc">Robot Operating System 2</div><div class="repo-url">github.com/ros2</div><div class="repo-diff hard">Hard | Robot bridge</div></div>
      <div class="repo-card"><div class="repo-name">Ollama</div><div class="repo-desc">Run LLMs locally</div><div class="repo-url">github.com/ollama/ollama</div><div class="repo-diff easy">Easy | Local models</div></div>
      <div class="repo-card"><div class="repo-name">AnythingLLM</div><div class="repo-desc">All-in-one document chatbot</div><div class="repo-url">github.com/Mintplex-Labs/anything-llm</div><div class="repo-diff medium">Medium | Doc RAG</div></div>
      <div class="repo-card"><div class="repo-name">Obsidian Plugin API</div><div class="repo-desc">Vault integration API</div><div class="repo-url">github.com/obsidianmd/obsidian-api</div><div class="repo-diff medium">Medium | Memory sync</div></div>
      <div class="repo-card"><div class="repo-name">AutoGen</div><div class="repo-desc">Multi-agent conversation</div><div class="repo-url">github.com/microsoft/autogen</div><div class="repo-diff medium">Medium | Agent research</div></div>
      <div class="repo-card"><div class="repo-name">Big-AGI</div><div class="repo-desc">Full-stack AI, many models</div><div class="repo-url">github.com/enricoros/big-AGI</div><div class="repo-diff medium">Medium | UI patterns</div></div>
      <div class="repo-card"><div class="repo-name">Open Interpreter</div><div class="repo-desc">Code-interpreting AI agent</div><div class="repo-url">github.com/OpenInterpreter/open-interpreter</div><div class="repo-diff hard">Hard | Code exec</div></div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/boka-os-diagrams/04-folder-agents-repos.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 4 done');
})();
