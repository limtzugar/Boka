// Diagram: LangGraph Nervous System Flow
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 40px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 4px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 30px; }

  .langgraph { display: flex; gap: 20px; }

  /* Flow diagram */
  .flow { flex: 1; display: flex; flex-direction: column; gap: 10px; }

  .node-row { display: flex; gap: 10px; justify-content: center; }
  .node {
    padding: 12px 16px; border-radius: 8px; text-align: center; min-width: 130px;
    border: 1px solid #4b4636; position: relative;
  }
  .node-title { font-size: 11px; font-weight: 700; margin-bottom: 3px; }
  .node-desc { font-size: 9px; color: #97948e; line-height: 1.3; }

  .n-input { background: rgba(182,158,111,0.06); border-color: rgba(182,158,111,0.2); }
  .n-input .node-title { color: #b69e6f; }
  .n-memory { background: rgba(134,114,195,0.06); border-color: rgba(134,114,195,0.2); }
  .n-memory .node-title { color: #8672c3; }
  .n-plan { background: rgba(123,150,177,0.06); border-color: rgba(123,150,177,0.2); }
  .n-plan .node-title { color: #7b96b1; }
  .n-route { background: rgba(214,183,93,0.06); border-color: rgba(214,183,93,0.2); }
  .n-route .node-title { color: #d6b75d; }
  .n-tool { background: rgba(117,177,137,0.06); border-color: rgba(117,177,137,0.2); }
  .n-tool .node-title { color: #75b189; }
  .n-reflect { background: rgba(190,118,111,0.06); border-color: rgba(190,118,111,0.2); }
  .n-reflect .node-title { color: #be766f; }
  .n-output { background: rgba(199,186,147,0.06); border-color: rgba(199,186,147,0.2); }
  .n-output .node-title { color: #c7ba93; }

  .arrow-down { text-align: center; color: #4b4636; font-size: 18px; padding: 2px 0; }
  .arrow-side { color: #4b4636; font-size: 14px; align-self: center; }

  /* Right panel: integration plan */
  .plan-panel { width: 340px; display: flex; flex-direction: column; gap: 10px; }
  .plan-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .plan-title { font-size: 13px; font-weight: 700; color: #d6b75d; margin-bottom: 6px; }
  .plan-body { font-size: 11px; color: #97948e; line-height: 1.6; }
  .plan-code { font-size: 10px; color: #4b4636; font-family: monospace; margin-top: 6px; line-height: 1.4; }

  /* Existing bridge */
  .bridge {
    margin-top: 14px; padding: 14px; border-radius: 8px;
    background: rgba(117,177,137,0.04); border: 1px solid rgba(117,177,137,0.15);
  }
  .bridge-title { font-size: 13px; font-weight: 700; color: #75b189; margin-bottom: 6px; }
  .bridge-body { font-size: 11px; color: #97948e; line-height: 1.6; }
</style></head><body>
  <div class="title">LangGraph Nervous System</div>
  <div class="subtitle">Central orchestration layer bridging existing BOKA with the new agent/memory architecture</div>

  <div class="langgraph">
    <div class="flow">
      <div class="node-row">
        <div class="node n-input">
          <div class="node-title">INPUT</div>
          <div class="node-desc">User message, voice, image, sensor data, scheduled trigger</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-memory">
          <div class="node-title">MEMORY RETRIEVAL</div>
          <div class="node-desc">Qdrant semantic search + PostgreSQL relational + Obsidian context</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-plan">
          <div class="node-title">PLANNING</div>
          <div class="node-desc">Decide approach: direct answer, multi-step, agent delegation, tool use</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-route">
          <div class="node-title">AGENT ROUTING</div>
          <div class="node-desc">Dispatch to specialized agent based on domain and context</div>
        </div>
        <span class="arrow-side">→</span>
        <div class="node n-route">
          <div class="node-title">MODE SWITCH</div>
          <div class="node-desc">Family OS or AHI Official? Persona, vocabulary, depth</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-tool">
          <div class="node-title">TOOL EXECUTION</div>
          <div class="node-desc">Search, image gen, reminders, expenses, legal DB, vision, TTS</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-reflect">
          <div class="node-title">REFLECTION</div>
          <div class="node-desc">Self-check: Is this harmonious? Accurate? Minimal? Safe?</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-output">
          <div class="node-title">RESPONSE</div>
          <div class="node-desc">Text, voice, image, graph update, robot command</div>
        </div>
        <span class="arrow-side">→</span>
        <div class="node n-memory">
          <div class="node-title">MEMORY UPDATE</div>
          <div class="node-desc">Store new episodic, update semantic, extract facts</div>
        </div>
      </div>
      <div class="arrow-down">↓</div>
      <div class="node-row">
        <div class="node n-reflect">
          <div class="node-title">SELF-EVALUATION</div>
          <div class="node-desc">Score response quality, log for future improvement</div>
        </div>
      </div>
    </div>

    <div class="plan-panel">
      <div class="plan-card">
        <div class="plan-title">Integration Strategy</div>
        <div class="plan-body">LangGraph wraps the EXISTING agent-system.ts, not replaces it. The current tag-based function calling ([ZAPAMIĘTAJ:], [SZUKAM:], etc.) becomes a Tool node in the LangGraph graph.</div>
        <div class="plan-code">boka_os/langgraph/
  graph.py          # Main StateGraph
  nodes/
    memory_retrieve.py
    planner.py
    agent_router.py
    tool_executor.py
    reflector.py
    memory_update.py
    evaluator.py
  state.py          # TypedDict state
  tools/
    search.py       # wraps /api/search
    reminder.py     # wraps /api/reminders
    expense.py      # wraps /api/family
    legal.py        # NEW: legal act analysis
    vision.py       # wraps /api/vision</div>
      </div>

      <div class="plan-card">
        <div class="plan-title">State Definition</div>
        <div class="plan-code">class BokaState(TypedDict):
  messages: list[dict]
  mode: str            # "family" | "ahi"
  active_member: str
  child_nearby: bool
  retrieved_memories: list
  plan: str
  agent_id: str
  tool_results: list
  reflection: dict
  emotion: str
  confidence: float
  safety_flags: list</div>
      </div>

      <div class="plan-card">
        <div class="plan-title">Migration Path</div>
        <div class="plan-body">
Phase 1: LangGraph as thin wrapper over existing /api/chat<br/>
Phase 2: Move memory retrieval into LangGraph node<br/>
Phase 3: Add reflection and self-evaluation nodes<br/>
Phase 4: Full agent routing through LangGraph<br/>
Phase 5: AHI Official mode as parallel graph
        </div>
      </div>

      <div class="bridge">
        <div class="bridge-title">Existing Code Bridge</div>
        <div class="bridge-body">
<b>agent-system.ts</b> → becomes LangGraph's agent_router node<br/>
<b>memory-extractor.ts</b> → becomes memory_update node<br/>
<b>buildSystemPrompt()</b> → becomes planner node context<br/>
<b>routeToAgent()</b> → becomes agent_router dispatch<br/>
<b>All [TAG:] extraction</b> → becomes tool_executor parsing<br/>
<b>/api/chat-stream</b> → becomes LangGraph's streaming output
        </div>
      </div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/boka-os-diagrams/03-langgraph-nervous.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 3 done');
})();
