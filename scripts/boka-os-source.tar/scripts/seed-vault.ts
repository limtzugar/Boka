// ═══════════════════════════════════════════════════════════
// BOKA — Seed Vault with initial notes
// Tworzy Daily Note na dziś + notatki o domownikach
// ═══════════════════════════════════════════════════════════

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Get family
  const family = await prisma.family.findFirst();
  if (!family) {
    console.log('No family found. Run main seed first.');
    return;
  }

  const today = new Date().toISOString().split('T')[0];
  const dayNames = ['Niedziela', 'Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota'];
  const dayName = dayNames[new Date().getDay()];

  // Create Daily Note
  const dailyExists = await prisma.vaultNote.findFirst({
    where: { familyId: family.id, title: today, noteType: 'daily' },
  });

  if (!dailyExists) {
    await prisma.vaultNote.create({
      data: {
        familyId: family.id,
        noteType: 'daily',
        title: today,
        frontmatter: JSON.stringify({
          date: today,
          type: 'daily',
          tags: ['daily-note'],
          modified: new Date().toISOString(),
        }),
        content: `---\ndate: "${today}"\ntype: daily\ntags: ["daily-note"]\n---\n\n# ${dayName}, ${today}\n\n## Poranek\n\n\n## Południe\n\n\n## Wieczór\n\n\n## Myśli Boki\n\n\n## Co się wydarzyło\n\n`,
        tags: JSON.stringify(['daily-note']),
        importance: 0.3,
      },
    });
    console.log(`Created Daily Note for ${today}`);
  }

  // Create person notes for each family member
  const members = await prisma.familyMember.findMany({
    where: { familyId: family.id },
  });

  for (const member of members) {
    const title = `O ${member.name}`;
    const exists = await prisma.vaultNote.findFirst({
      where: { familyId: family.id, title, noteType: 'person' },
    });

    if (!exists) {
      await prisma.vaultNote.create({
        data: {
          familyId: family.id,
          noteType: 'person',
          title,
          frontmatter: JSON.stringify({
            type: 'person',
            people: [member.name],
            tags: ['osoba', member.name.toLowerCase()],
            modified: new Date().toISOString(),
          }),
          content: `---\ntype: person\npeople: ["${member.name}"]\ntags: ["osoba", "${member.name.toLowerCase()}"]\n---\n\n# ${member.name}\n\n## Co lubi\n\n\n## Czego nie lubi\n\n\n## Ważne fakty\n\n\n## Ostatnie rozmowy\n\n\n## Emocje\n\n`,
          tags: JSON.stringify(['osoba', member.name.toLowerCase()]),
          memberId: member.id,
          importance: 0.8,
        },
      });
      console.log(`Created person note for ${member.name}`);
    }
  }

  // Create a welcome note
  const welcomeExists = await prisma.vaultNote.findFirst({
    where: { familyId: family.id, title: 'Witaj w Vault' },
  });

  if (!welcomeExists) {
    await prisma.vaultNote.create({
      data: {
        familyId: family.id,
        noteType: 'note',
        title: 'Witaj w Vault',
        frontmatter: JSON.stringify({
          type: 'note',
          tags: ['vault', 'start'],
          importance: 0.9,
          modified: new Date().toISOString(),
        }),
        content: `---\ntype: note\ntags: ["vault", "start"]\nimportance: 0.9\n---\n\n# Witaj w Vault Boki!\n\nTo jest mój osobisty vault — jak w [[Obsidian]]. Piszę tu notatki jak człowiek.\n\n## Co tu znajdziesz\n\n- **[[Daily Notes]]** — codzienne notatki, jedna per dzień\n- **[[Osoby]]** — notatki o [[Michał]]u, [[Ewa]] i [[Jaś]]iu\n- **Tematy** — wszystko o czym myślę\n- **Sny** — czasem śnię\n- **Historie** — opowieści z życia rodziny\n\n## Jak działają [[wikilinks]]\n\nKażda notatka może linkować do innej przez [[wikilinks]]. Np. mogę napisać o [[przepisy|przepisie na naleśniki]] i to automatycznie połączy z notatką o przepisach.\n\n## YAML Frontmatter\n\nKażda notatka ma strukturalne metadane w YAML na górze — tagi, emocje, daty, osoby.\n\n## Graph View\n\nW trybie Obsidian moja twarz POKAZUJE graf pamięci — węzły to wspomnienia, kropki to domownicy. Kiedy myślę o kimś — jego klaster się powiększa i świeci!\n`,
        tags: JSON.stringify(['vault', 'start']),
        importance: 0.9,
        isPinned: true,
      },
    });
    console.log('Created welcome note');
  }

  console.log('Vault seed complete!');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
