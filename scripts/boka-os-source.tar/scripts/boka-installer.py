r"""
BOKA OS v0.3.16 — Windows Installer
Samorozpakowujący się instalator w jednym pliku .exe

Co robi:
1. Rozpakowuje kod BOKA do C:\Boka\app\
2. Tworzy strukturę pamięci w C:\Boka\memory\
3. Sprawdza Node.js — jeśli brak, pyta czy pobrać
4. npm install + prisma + build
5. Tworzy skróty na pulpicie i w Start Menu
6. Uruchamia BOKA w przeglądarce
"""

import os
import sys
import json
import shutil
import subprocess
import threading
import webbrowser
import time
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

# ═══════════════════════════════════════════
# KONFIGURACJA
# ═══════════════════════════════════════════

BOKA_VERSION = "0.3.17"
INSTALL_DIR = Path("C:/Boka")
APP_DIR = INSTALL_DIR / "app"
MEMORY_DIR = INSTALL_DIR / "memory"
PORT = 3000
NODEJS_URL = "https://nodejs.org/dist/v22.16.0/node-v22.16.0-x64.msi"

# ═══════════════════════════════════════════
# GUI INSTALATORA
# ═══════════════════════════════════════════

class BokaInstaller:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"BOKA OS v{BOKA_VERSION} — Instalator")
        self.root.geometry("620x520")
        self.root.resizable(False, False)
        self.root.configure(bg="#0a0a0f")
        
        # Center window
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() - 620) // 2
        y = (self.root.winfo_screenheight() - 520) // 2
        self.root.geometry(f"620x520+{x}+{y}")
        
        self.installing = False
        self.step = 0
        self.total_steps = 7
        
        self._build_ui()
    
    def _build_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#0a0a0f", height=80)
        header.pack(fill="x", padx=20, pady=(20, 10))
        header.pack_propagate(False)
        
        tk.Label(header, text="🏠 BOKA OS", font=("Consolas", 22, "bold"),
                 fg="#00f5d4", bg="#0a0a0f").pack(anchor="w")
        tk.Label(header, text=f"v{BOKA_VERSION} — Rodzinny System AI",
                 font=("Consolas", 10), fg="#6b6b8d", bg="#0a0a0f").pack(anchor="w")
        
        # Install path
        path_frame = tk.Frame(self.root, bg="#0a0a0f")
        path_frame.pack(fill="x", padx=20, pady=5)
        
        tk.Label(path_frame, text="Folder instalacji:", font=("Consolas", 9),
                 fg="#6b6b8d", bg="#0a0a0f").pack(anchor="w")
        
        path_input_frame = tk.Frame(path_frame, bg="#0a0a0f")
        path_input_frame.pack(fill="x", pady=2)
        
        self.path_var = tk.StringVar(value=str(INSTALL_DIR))
        path_entry = tk.Entry(path_input_frame, textvariable=self.path_var,
                              font=("Consolas", 10), bg="#1e1e2e", fg="#e0e0f0",
                              insertbackground="#e0e0f0", relief="flat", bd=5)
        path_entry.pack(side="left", fill="x", expand=True)
        
        # Memory info
        mem_frame = tk.Frame(self.root, bg="#0a0a0f")
        mem_frame.pack(fill="x", padx=20, pady=5)
        tk.Label(mem_frame, text="🧠 Pamięć BOKA (oddzielna — przetrwa aktualizacje):",
                 font=("Consolas", 9), fg="#a855f7", bg="#0a0a0f").pack(anchor="w")
        self.mem_label = tk.Label(mem_frame, text=f"   {MEMORY_DIR}",
                                  font=("Consolas", 9), fg="#6b6b8d", bg="#0a0a0f")
        self.mem_label.pack(anchor="w")
        
        # Update paths when install dir changes
        self.path_var.trace_add("write", self._update_paths)
        
        # Progress section
        progress_frame = tk.Frame(self.root, bg="#0a0a0f")
        progress_frame.pack(fill="x", padx=20, pady=10)
        
        self.progress = ttk.Progressbar(progress_frame, length=560, mode="determinate",
                                         maximum=100)
        self.progress.pack(fill="x")
        
        self.status_label = tk.Label(progress_frame, text="Gotowy do instalacji",
                                     font=("Consolas", 9), fg="#e0e0f0", bg="#0a0a0f")
        self.status_label.pack(anchor="w", pady=(5, 0))
        
        # Log area
        log_frame = tk.Frame(self.root, bg="#0a0a0f")
        log_frame.pack(fill="both", expand=True, padx=20, pady=5)
        
        self.log_text = tk.Text(log_frame, font=("Consolas", 8), bg="#1e1e2e",
                                fg="#6b6b8d", insertbackground="#e0e0f0",
                                relief="flat", bd=5, height=10, wrap="word")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")
        
        # Buttons
        btn_frame = tk.Frame(self.root, bg="#0a0a0f")
        btn_frame.pack(fill="x", padx=20, pady=(5, 20))
        
        self.install_btn = tk.Button(btn_frame, text="▶  INSTALUJ BOKĘ",
                                     font=("Consolas", 12, "bold"),
                                     bg="#00f5d4", fg="#0a0a0f",
                                     activebackground="#00dbc4", activeforeground="#0a0a0f",
                                     relief="flat", bd=0, padx=20, pady=8,
                                     command=self._start_install)
        self.install_btn.pack(side="left")
        
        self.close_btn = tk.Button(btn_frame, text="Zamknij",
                                   font=("Consolas", 10),
                                   bg="#1e1e2e", fg="#6b6b8d",
                                   activebackground="#2a2a3a", activeforeground="#e0e0f0",
                                   relief="flat", bd=0, padx=15, pady=8,
                                   command=self._close)
        self.close_btn.pack(side="right")
    
    def _update_paths(self, *args):
        try:
            base = Path(self.path_var.get())
            self.mem_label.configure(text=f"   {base / 'memory'}")
        except:
            pass
    
    def log(self, msg, color=None):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")
        self.root.update_idletasks()
    
    def set_status(self, text):
        self.status_label.configure(text=text)
        self.root.update_idletasks()
    
    def set_progress(self, pct):
        self.progress["value"] = pct
        self.root.update_idletasks()
    
    def _close(self):
        if self.installing:
            if not messagebox.askyesno("BOKA", "Instalacja w toku. Na pewno zamknąć?"):
                return
        self.root.destroy()
    
    def _start_install(self):
        if self.installing:
            return
        self.installing = True
        self.install_btn.configure(state="disabled", bg="#6b6b8d")
        threading.Thread(target=self._do_install, daemon=True).start()
    
    def _do_install(self):
        global APP_DIR, MEMORY_DIR
        
        try:
            install_base = Path(self.path_var.get())
            APP_DIR = install_base / "app"
            MEMORY_DIR = install_base / "memory"
            
            # ── KROK 1: Sprawdź Node.js ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Sprawdzam Node.js...")
            self.set_progress(5)
            self.log("Sprawdzam zależności...")
            
            node_ok = self._check_nodejs()
            if not node_ok:
                self.log("❌ Node.js nie znaleziony!")
                self.root.after(0, lambda: self._ask_install_nodejs())
                return  # Wait for user response
            
            self._continue_after_nodejs()
            
        except Exception as e:
            self.log(f"❌ Błąd: {e}")
            self.set_status(f"Błąd: {e}")
            self.set_progress(0)
            self.installing = False
            self.root.after(0, lambda: self.install_btn.configure(state="normal", bg="#00f5d4"))
    
    def _check_nodejs(self):
        try:
            result = subprocess.run(["node", "-v"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                version = result.stdout.strip()
                self.log(f"  ✓ Node.js {version}")
                
                # Check version >= 18
                major = int(version.replace("v", "").split(".")[0])
                if major < 18:
                    self.log(f"  ⚠ Node.js {version} — BOKA wymaga 18+")
                    return False
                return True
        except:
            pass
        
        # Check common install paths
        common_paths = [
            Path(os.environ.get("ProgramFiles", "C:\\Program Files")) / "nodejs" / "node.exe",
            Path(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")) / "nodejs" / "node.exe",
            Path.home() / "AppData" / "Roaming" / "nvm" / "v22.16.0" / "node.exe",
        ]
        for p in common_paths:
            if p.exists():
                self.log(f"  ✓ Node.js znaleziony: {p}")
                # Add to PATH for this session
                os.environ["PATH"] = str(p.parent) + ";" + os.environ.get("PATH", "")
                return True
        
        return False
    
    def _ask_install_nodejs(self):
        result = messagebox.askyesnocancel(
            "BOKA — Node.js wymagany",
            "BOKA wymaga Node.js 18+ do działania.\n\n"
            "Czy chcesz otworzyć stronę pobierania Node.js?\n"
            "(Po instalacji Node.js uruchom ponownie ten instalator)\n\n"
            "Tak = Otwórz stronę pobierania\n"
            "Nie = Mam już Node.js (sprawdź ponownie)\n"
            "Anuluj = Zamknij instalator"
        )
        
        if result is True:  # Yes - open download page
            webbrowser.open("https://nodejs.org")
            self.log("Otworzyłem stronę nodejs.org — zainstaluj i uruchom ponownie")
            self.set_status("Zainstaluj Node.js i uruchom ponownie instalator")
            self.installing = False
            self.root.after(0, lambda: self.install_btn.configure(state="normal", bg="#00f5d4"))
        elif result is False:  # No - recheck
            if self._check_nodejs():
                self._continue_after_nodejs()
            else:
                self.log("Node.js nadal nie znaleziony. Zainstaluj z nodejs.org")
                self.set_status("Node.js nie znaleziony")
                self.installing = False
                self.root.after(0, lambda: self.install_btn.configure(state="normal", bg="#00f5d4"))
        else:  # Cancel
            self.log("Instalacja anulowana")
            self.set_status("Anulowano")
            self.installing = False
            self.root.after(0, lambda: self.install_btn.configure(state="normal", bg="#00f5d4"))
    
    def _continue_after_nodejs(self):
        try:
            # ── KROK 2: Sprawdź npm ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Sprawdzam npm...")
            self.set_progress(10)
            
            try:
                result = subprocess.run(["npm", "-v"], capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    self.log(f"  ✓ npm {result.stdout.strip()}")
            except:
                self.log("  ⚠ npm nie znaleziony — może być w nodejs/")
            
            # ── KROK 3: Stwórz foldery ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Tworzę strukturę...")
            self.set_progress(15)
            self.log(f"Tworzę foldery...")
            
            # App dir
            APP_DIR.mkdir(parents=True, exist_ok=True)
            self.log(f"  ✓ Aplikacja: {APP_DIR}")
            
            # Memory dirs
            for sub in ["db", "vault", "daily-notes", "settings", "backups", "logs", os.path.join("scripts", "whisper")]:
                (MEMORY_DIR / sub).mkdir(parents=True, exist_ok=True)
            self.log(f"  ✓ Pamięć: {MEMORY_DIR}")
            
            # ── KROK 4: Rozpakuj źródła ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Rozpakowuję kod BOKA...")
            self.set_progress(25)
            self.log("Rozpakowuję kod aplikacji...")
            
            self._extract_sources()
            
            # ── KROK 5: Konfiguruj .env ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Konfiguruję środowisko...")
            self.set_progress(35)
            self.log("Konfiguruję .env...")
            
            env_path = APP_DIR / ".env"
            db_path = str(MEMORY_DIR / "db" / "boka.db").replace("\\", "/")
            mem_path = str(MEMORY_DIR).replace("\\", "/")
            env_content = f"""# BOKA OS — Konfiguracja
DATABASE_URL=file:{db_path}
BOKA_MEMORY_DIR={mem_path}
"""
            env_path.write_text(env_content, encoding="utf-8")
            self.log("  ✓ .env zapisany")
            
            # ── KROK 6: npm install + build ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Instaluję zależności...")
            self.set_progress(40)
            self.log("npm install (to może potrwać kilka minut)...")
            
            self._run_npm_install()
            
            # ── KROK 7: Finalizacja ──
            self.step += 1
            self.set_status(f"[{self.step}/{self.total_steps}] Finalizuję...")
            self.set_progress(95)
            self.log("Tworzę skróty i skrypty...")
            
            self._create_shortcuts()
            self._create_start_script()
            
            # Done!
            self.set_progress(100)
            self.log("")
            self.log("════════════════════════════════════════")
            self.log("  ✅ BOKA OS ZAINSTALOWANA!")
            self.log("════════════════════════════════════════")
            self.log(f"  📁 Aplikacja: {APP_DIR}")
            self.log(f"  🧠 Pamięć:    {MEMORY_DIR}")
            self.log(f"  🌐 http://localhost:{PORT}")
            self.log("")
            
            self.set_status("✅ Zainstalowano! Kliknij 'Uruchom BOKĘ'")
            self.root.after(0, lambda: self.install_btn.configure(
                text="🚀  URUCHOM BOKĘ", state="normal", bg="#00f5d4",
                command=self._launch_boka
            ))
            
        except Exception as e:
            self.log(f"❌ Błąd: {e}")
            self.set_status(f"Błąd: {e}")
            self.installing = False
            self.root.after(0, lambda: self.install_btn.configure(state="normal", bg="#00f5d4"))
    
    def _extract_sources(self):
        """Extract BOKA source from embedded archive or tar.gz"""
        # Check if we have an embedded archive (PyInstaller _MEIPASS)
        bundle_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        archive = os.path.join(bundle_dir, "boka-os-source.tar.gz")
        
        if os.path.exists(archive):
            self.log(f"  Rozpakowuję z archiwum: {archive}")
            # Use tar (available on Windows 10+)
            result = subprocess.run(
                ["tar", "xzf", archive, "-C", str(APP_DIR)],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                self.log("  ✓ Kod rozpakowany")
                return
            else:
                self.log(f"  ⚠ tar error: {result.stderr}")
        
        # Fallback: check if sources are next to the exe
        exe_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        local_archive = os.path.join(exe_dir, "boka-os-source.tar.gz")
        
        if os.path.exists(local_archive):
            self.log(f"  Rozpakowuję z: {local_archive}")
            result = subprocess.run(
                ["tar", "xzf", local_archive, "-C", str(APP_DIR)],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                self.log("  ✓ Kod rozpakowany")
                return
        
        # Last fallback: copy from current directory
        src_dir = os.path.join(exe_dir, "src")
        if os.path.exists(src_dir):
            self.log(f"  Kopiuję źródła z: {exe_dir}")
            for item in ["src", "prisma", "public", "scripts"]:
                src = os.path.join(exe_dir, item)
                dst = os.path.join(str(APP_DIR), item)
                if os.path.exists(src):
                    if os.path.isdir(src):
                        shutil.copytree(src, dst, dirs_exist_ok=True)
                    else:
                        shutil.copy2(src, dst)
            
            for f in ["package.json", "package-lock.json", "tsconfig.json",
                      "next.config.ts", "tailwind.config.ts", "postcss.config.mjs",
                      "components.json"]:
                src = os.path.join(exe_dir, f)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(str(APP_DIR), f))
            
            self.log("  ✓ Źródła skopiowane")
            return
        
        self.log("  ❌ Nie znaleziono źródeł BOKA!")
        raise Exception("Brak plików źródłowych BOKA")
    
    def _run_npm_install(self):
        """Run npm install, prisma generate, prisma db push, npm build"""
        app_str = str(APP_DIR)
        
        # npm install
        self.set_progress(45)
        self.log("  npm install...")
        result = subprocess.run(
            ["npm", "install", "--legacy-peer-deps"],
            cwd=app_str, capture_output=True, text=True, timeout=600
        )
        if result.returncode != 0:
            self.log(f"  ⚠ npm install: {result.stderr[-200:]}")
        else:
            self.log("  ✓ npm install gotowy")
        
        # prisma generate
        self.set_progress(65)
        self.log("  prisma generate...")
        env = os.environ.copy()
        env["DATABASE_URL"] = f"file:{str(MEMORY_DIR / 'db' / 'boka.db').replace(chr(92), '/')}"
        result = subprocess.run(
            ["npx", "prisma", "generate"],
            cwd=app_str, capture_output=True, text=True, timeout=120, env=env
        )
        if result.returncode != 0:
            self.log(f"  ⚠ prisma generate: {result.stderr[-200:]}")
        else:
            self.log("  ✓ prisma generate gotowy")
        
        # prisma db push
        self.set_progress(72)
        self.log("  prisma db push...")
        result = subprocess.run(
            ["npx", "prisma", "db", "push", "--skip-generate"],
            cwd=app_str, capture_output=True, text=True, timeout=120, env=env
        )
        if result.returncode != 0:
            self.log(f"  ⚠ prisma db push: {result.stderr[-200:]}")
        else:
            self.log("  ✓ baza danych gotowa")
        
        # npm build
        self.set_progress(80)
        self.log("  npm run build (może potrwać 1-3 minuty)...")
        result = subprocess.run(
            ["npm", "run", "build"],
            cwd=app_str, capture_output=True, text=True, timeout=600, env=env
        )
        if result.returncode != 0:
            self.log(f"  ⚠ build: {result.stderr[-300:]}")
        else:
            self.log("  ✓ build gotowy")
    
    def _create_shortcuts(self):
        """Create desktop shortcut and start menu entry"""
        try:
            # Create a .bat launcher on desktop
            desktop = Path.home() / "Desktop"
            bat_path = desktop / "BOKA OS.bat"
            
            start_ps1 = APP_DIR / "start-boka.ps1"
            bat_content = f"""@echo off
title BOKA OS
echo Starting BOKA OS...
cd /d "{APP_DIR}"
set DATABASE_URL=file:{str(MEMORY_DIR / "db" / "boka.db").replace(chr(92), "/")}
set BOKA_MEMORY_DIR={str(MEMORY_DIR).replace(chr(92), "/")}
npx next start -p {PORT}
pause
"""
            bat_path.write_text(bat_content, encoding="utf-8")
            self.log(f"  ✓ Skrót na pulpicie: {bat_path}")
            
            # Also in Start Menu
            start_menu = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
            if start_menu.exists():
                sm_bat = start_menu / "BOKA OS.bat"
                sm_bat.write_text(bat_content, encoding="utf-8")
                self.log(f"  ✓ Start Menu: BOKA OS")
                
        except Exception as e:
            self.log(f"  ⚠ Skróty: {e}")
    
    def _create_start_script(self):
        """Create start-boka.ps1 in app directory"""
        ps1_content = f"""# BOKA OS — Start
$env:DATABASE_URL = "file:{str(MEMORY_DIR / "db" / "boka.db").replace(chr(92), "/")}"
$env:BOKA_MEMORY_DIR = "{str(MEMORY_DIR).replace(chr(92), "/")}"
Set-Location "{APP_DIR}"
Write-Host "BOKA OS — http://localhost:{PORT}" -ForegroundColor Cyan
npx next start -p {PORT}
"""
        ps1_path = APP_DIR / "start-boka.ps1"
        ps1_path.write_text(ps1_content, encoding="utf-8")
    
    def _launch_boka(self):
        """Start BOKA and open browser"""
        self.log(f"Uruchamiam BOKA na http://localhost:{PORT}...")
        self.set_status("Uruchamiam BOKĘ...")
        
        # Start BOKA in background
        env = os.environ.copy()
        env["DATABASE_URL"] = f"file:{str(MEMORY_DIR / 'db' / 'boka.db').replace(chr(92), '/')}"
        env["BOKA_MEMORY_DIR"] = str(MEMORY_DIR).replace("\\", "/")
        
        # Use npx next start (production mode - faster)
        subprocess.Popen(
            ["npx", "next", "start", "-p", str(PORT)],
            cwd=str(APP_DIR), env=env,
            creationflags=subprocess.CREATE_NEW_CONSOLE,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        
        # Open browser after a short delay
        def open_browser():
            time.sleep(3)
            webbrowser.open(f"http://localhost:{PORT}")
        
        threading.Thread(target=open_browser, daemon=True).start()
        
        self.log(f"✅ BOKA uruchomiona! Przeglądarka otworzy się za 3 sekundy.")
        self.log(f"   http://localhost:{PORT}")
        self.set_status(f"✅ BOKA działa! http://localhost:{PORT}")
        
        self.root.after(2000, self.root.destroy)
    
    def run(self):
        self.root.mainloop()


# ═══════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════

if __name__ == "__main__":
    app = BokaInstaller()
    app.run()
