// Diagram 2: Layer Interaction Flowchart - Phased Vertical
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1200px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .flow { display: flex; flex-direction: column; align-items: center; gap: 0; }

  .phase {
    width: 100%; border-radius: 10px; padding: 18px 24px; margin-bottom: 0;
    border: 1px solid #4b4636; position: relative;
  }
  .phase-header { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
  .phase-num {
    width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-size: 16px; font-weight: 800; flex-shrink: 0;
  }
  .phase-title { font-size: 16px; font-weight: 700; }
  .phase-flow { display: flex; gap: 10px; flex-wrap: wrap; }
  .step {
    padding: 8px 14px; border-radius: 6px; font-size: 11px; font-weight: 500;
    background: rgba(214,183,93,0.06); border: 1px solid rgba(214,183,93,0.15);
  }

  .p1 .phase-num { background: #b69e6f; color: #0b0b0a; }
  .p1 { background: rgba(182,158,111,0.04); }
  .p1 .step { color: #b69e6f; border-color: rgba(182,158,111,0.2); background: rgba(182,158,111,0.06); }

  .p2 .phase-num { background: #8672c3; color: #0b0b0a; }
  .p2 { background: rgba(134,114,195,0.04); }
  .p2 .step { color: #8672c3; border-color: rgba(134,114,195,0.2); background: rgba(134,114,195,0.06); }

  .p3 .phase-num { background: #7b96b1; color: #0b0b0a; }
  .p3 { background: rgba(123,150,177,0.04); }
  .p3 .step { color: #7b96b1; border-color: rgba(123,150,177,0.2); background: rgba(123,150,177,0.06); }

  .p4 .phase-num { background: #75b189; color: #0b0b0a; }
  .p4 { background: rgba(117,177,137,0.04); }
  .p4 .step { color: #75b189; border-color: rgba(117,177,137,0.2); background: rgba(117,177,137,0.06); }

  .p5 .phase-num { background: #c7ba93; color: #0b0b0a; }
  .p5 { background: rgba(199,186,147,0.04); }
  .p5 .step { color: #c7ba93; border-color: rgba(199,186,147,0.2); background: rgba(199,186,147,0.06); }

  .p6 .phase-num { background: #d6b75d; color: #0b0b0a; }
  .p6 { background: rgba(214,183,93,0.04); }
  .p6 .step { color: #d6b75d; border-color: rgba(214,183,93,0.2); background: rgba(214,183,93,0.06); }

  .arrow-row { display: flex; align-items: center; justify-content: center; padding: 6px 0; }
  .arrow-row svg { width: 40px; height: 28px; }

  .output-label { font-size: 10px; color: #97948e; text-align: right; width: 100%; margin-top: 4px; font-style: italic; }
</style></head><body>
  <div class="title">Layer Interaction Flowchart</div>
  <div class="subtitle">How signals flow through AHI from sensing to harmonization, governed by ethics and human oversight</div>

  <div class="flow">
    <div class="phase p1">
      <div class="phase-header">
        <div class="phase-num">1</div>
        <div class="phase-title">SENSING — Observe & Collect</div>
      </div>
      <div class="phase-flow">
        <div class="step">Social Media</div><div class="step">Family Chats</div><div class="step">News</div>
        <div class="step">IoT / Environment</div><div class="step">Voice / Tone</div><div class="step">Behavior Patterns</div>
      </div>
      <div class="output-label">Outputs: stress indicators, polarization maps, escalation metrics</div>
    </div>

    <div class="arrow-row"><svg viewBox="0 0 40 28"><path d="M20 0 L20 20 M12 14 L20 22 L28 14" stroke="#4b4636" stroke-width="2" fill="none"/></svg></div>

    <div class="phase p2">
      <div class="phase-header">
        <div class="phase-num">2</div>
        <div class="phase-title">MODELING — Understand Why</div>
      </div>
      <div class="phase-flow">
        <div class="step">Causal Inference</div><div class="step">Graph Dynamics</div><div class="step">Narrative Mapping</div>
        <div class="step">Tension Maps</div><div class="step">Dependency Analysis</div>
      </div>
      <div class="output-label">Outputs: root cause analysis, destabilization vectors, risk assessment</div>
    </div>

    <div class="arrow-row"><svg viewBox="0 0 40 28"><path d="M20 0 L20 20 M12 14 L20 22 L28 14" stroke="#4b4636" stroke-width="2" fill="none"/></svg></div>

    <div class="phase p3">
      <div class="phase-header">
        <div class="phase-num">3</div>
        <div class="phase-title">PREDICTION — Simulate Futures</div>
      </div>
      <div class="phase-flow">
        <div class="step">Multi-Agent Sim</div><div class="step">Behavior Forecast</div><div class="step">Intervention Sim</div>
        <div class="step">Cascade Analysis</div>
      </div>
      <div class="output-label">Outputs: stability trajectories, escalation scenarios, intervention forecasts</div>
    </div>

    <div class="arrow-row"><svg viewBox="0 0 40 28"><path d="M20 0 L20 20 M12 14 L20 22 L28 14" stroke="#4b4636" stroke-width="2" fill="none"/></svg></div>

    <div class="phase p4">
      <div class="phase-header">
        <div class="phase-num">4</div>
        <div class="phase-title">HARMONIZATION — Subtle Stabilization</div>
      </div>
      <div class="phase-flow">
        <div class="step">Slow Escalation</div><div class="step">Contextualize</div><div class="step">Highlight Uncertainty</div>
        <div class="step">De-escalate</div><div class="step">Detect Manipulation</div><div class="step">Reflective Dialogue</div>
      </div>
      <div class="output-label">Actions: soft stabilization, informational resilience, NOT control</div>
    </div>

    <div class="arrow-row"><svg viewBox="0 0 40 28"><path d="M20 0 L20 20 M12 14 L20 22 L28 14" stroke="#4b4636" stroke-width="2" fill="none"/></svg></div>

    <div class="phase p5">
      <div class="phase-header">
        <div class="phase-num">5</div>
        <div class="phase-title">ETHICS & ALIGNMENT — Guard Rails</div>
      </div>
      <div class="phase-flow">
        <div class="step">Audit Trail</div><div class="step">Explainability</div><div class="step">Human Veto</div>
        <div class="step">Privacy</div><div class="step">Disagreement Protection</div>
      </div>
      <div class="output-label">Gate: every action must pass ethical review before execution</div>
    </div>

    <div class="arrow-row"><svg viewBox="0 0 40 28"><path d="M20 0 L20 20 M12 14 L20 22 L28 14" stroke="#4b4636" stroke-width="2" fill="none"/></svg></div>

    <div class="phase p6">
      <div class="phase-header">
        <div class="phase-num">6</div>
        <div class="phase-title">HUMAN OVERSIGHT — Final Authority</div>
      </div>
      <div class="phase-flow">
        <div class="step">Define Values</div><div class="step">Approve Interventions</div><div class="step">Audit Behavior</div>
        <div class="step">Tune Thresholds</div><div class="step">Supervise Boundaries</div>
      </div>
      <div class="output-label">Feedback: human decisions loop back to tune sensing & harmonization</div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/02-layer-interaction.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 2 done');
})();
