const { PrismaClient } = require('@prisma/client');
const path = require('path');
process.env.DATABASE_URL = `file:${path.resolve('/home/z/boka-memory/db/boka.db')}`;
const db = new PrismaClient();
(async () => {
  const families = await db.family.findMany();
  console.log('Families:', families.length);
  families.forEach(f => console.log(' -', f.id, f.name));
  const members = await db.familyMember.findMany();
  console.log('Members:', members.length);
  members.forEach(m => console.log(' -', m.id, m.name, m.role, 'familyId:', m.familyId));
  await db.$disconnect();
})();
