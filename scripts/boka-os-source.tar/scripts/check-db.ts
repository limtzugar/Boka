import { db } from '../src/lib/db';
async function main() {
  const tables = await db.$queryRaw`SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;`;
  console.log('Tables in DB:', tables);
  try {
    const count = await db.mcpServer.count();
    console.log('McpServer count:', count);
  } catch (e) {
    console.log('McpServer error:', e instanceof Error ? e.message : String(e));
  }
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
