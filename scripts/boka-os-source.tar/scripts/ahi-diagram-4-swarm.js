// Diagram 4: Multi-Agent Coordination Map (Swarm Architecture)
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .swarm { display: flex; gap: 24px; }

  /* Agent grid */
  .agents { flex: 1; display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .agent {
    padding: 16px; border-radius: 10px; background: #161614; border: 1px solid #4b4636;
    position: relative;
  }
  .agent-icon { font-size: 24px; margin-bottom: 6px; }
  .agent-name { font-size: 14px; font-weight: 700; margin-bottom: 4px; }
  .agent-role { font-size: 11px; color: #97948e; line-height: 1.5; margin-bottom: 8px; }
  .agent-model { font-size: 10px; padding: 3px 8px; border-radius: 3px; display: inline-block; }
  .agent-skills { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px; }
  .agent-skill { font-size: 9px; padding: 2px 6px; border-radius: 2px; background: rgba(214,183,93,0.06); border: 1px solid rgba(214,183,93,0.12); color: #c7ba93; }

  .a-observer .agent-name { color: #b69e6f; }
  .a-observer .agent-model { background: rgba(182,158,111,0.15); color: #b69e6f; }
  .a-mediator .agent-name { color: #75b189; }
  .a-mediator .agent-model { background: rgba(117,177,137,0.15); color: #75b189; }
  .a-ethics .agent-name { color: #c7ba93; }
  .a-ethics .agent-model { background: rgba(199,186,147,0.15); color: #c7ba93; }
  .a-memory .agent-name { color: #8672c3; }
  .a-memory .agent-model { background: rgba(134,114,195,0.15); color: #8672c3; }
  .a-forecast .agent-name { color: #7b96b1; }
  .a-forecast .agent-model { background: rgba(123,150,177,0.15); color: #7b96b1; }
  .a-simulation .agent-name { color: #7b96b1; }
  .a-simulation .agent-model { background: rgba(123,150,177,0.15); color: #7b96b1; }
  .a-governance .agent-name { color: #d6b75d; }
  .a-governance .agent-model { background: rgba(214,183,93,0.15); color: #d6b75d; }
  .a-channel .agent-name { color: #b69e6f; }
  .a-channel .agent-model { background: rgba(182,158,111,0.15); color: #b69e6f; }
  .a-diagram .agent-name { color: #c7ba93; }
  .a-diagram .agent-model { background: rgba(199,186,147,0.15); color: #c7ba93; }
  .a-knowledge .agent-name { color: #8672c3; }
  .a-knowledge .agent-model { background: rgba(134,114,195,0.15); color: #8672c3; }

  /* Communication bus */
  .comm-bus {
    width: 280px; display: flex; flex-direction: column; gap: 14px;
  }
  .bus-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .bus-title { font-size: 13px; font-weight: 700; color: #d6b75d; margin-bottom: 8px; }
  .bus-items { font-size: 11px; color: #97948e; line-height: 1.7; }
  .bus-item { padding: 3px 0; border-bottom: 1px solid rgba(75,70,54,0.4); }
  .bus-item:last-child { border-bottom: none; }

  .principle {
    margin-top: 16px; padding: 14px; border-radius: 8px; background: rgba(214,183,93,0.06); border: 1px solid rgba(214,183,93,0.15);
    font-size: 12px; color: #d6b75d; text-align: center; line-height: 1.6;
  }
</style></head><body>
  <div class="title">Swarm Agent Coordination Map</div>
  <div class="subtitle">Specialized agents communicate via event bus — no single agent possesses global authority</div>

  <div class="swarm">
    <div class="agents">
      <div class="agent a-observer">
        <div class="agent-name">Observer Agent</div>
        <div class="agent-role">Monitors all channels for signals, anomalies, emotional shifts, and systemic stress. Runs continuously on streaming data.</div>
        <div class="agent-model">Gemini Flash 2.0</div>
        <div class="agent-skills"><span class="agent-skill">sentiment</span><span class="agent-skill">anomaly</span><span class="agent-skill">polarization</span></div>
      </div>

      <div class="agent a-mediator">
        <div class="agent-name">Mediator Agent</div>
        <div class="agent-role">Facilitates de-escalation, encourages reflective dialogue, and reduces conflict between family members through gentle intervention.</div>
        <div class="agent-model">Claude 3.5 Sonnet</div>
        <div class="agent-skills"><span class="agent-skill">mediation</span><span class="agent-skill">de-escalation</span><span class="agent-skill">dialogue</span></div>
      </div>

      <div class="agent a-ethics">
        <div class="agent-name">Ethics Agent</div>
        <div class="agent-role">Reviews every proposed action against ethical policy, privacy rules, and alignment constraints. Can veto any intervention.</div>
        <div class="agent-model">Claude 3.5 Sonnet</div>
        <div class="agent-skills"><span class="agent-skill">ethics-check</span><span class="agent-skill">privacy</span><span class="agent-skill">veto</span></div>
      </div>

      <div class="agent a-memory">
        <div class="agent-name">Memory Agent</div>
        <div class="agent-role">Maintains episodic, semantic, and workflow memory for each family member. Powers the Icarus-style self-reflection loop.</div>
        <div class="agent-model">Local (privacy)</div>
        <div class="agent-skills"><span class="agent-skill">episodic</span><span class="agent-skill">semantic</span><span class="agent-skill">reflection</span></div>
      </div>

      <div class="agent a-forecast">
        <div class="agent-name">Forecast Agent</div>
        <div class="agent-role">Predicts emotional trajectories, conflict likelihood, and stability scenarios using probabilistic models and historical patterns.</div>
        <div class="agent-model">GPT-4o</div>
        <div class="agent-skills"><span class="agent-skill">forecasting</span><span class="agent-skill">cascade</span><span class="agent-skill">probability</span></div>
      </div>

      <div class="agent a-simulation">
        <div class="agent-name">Simulation Agent</div>
        <div class="agent-role">Runs multi-agent simulations to test intervention outcomes before deployment. What-if analysis for family dynamics.</div>
        <div class="agent-model">GPT-4o</div>
        <div class="agent-skills"><span class="agent-skill">multi-agent</span><span class="agent-skill">what-if</span><span class="agent-skill">outcome</span></div>
      </div>

      <div class="agent a-governance">
        <div class="agent-name">Governance Agent</div>
        <div class="agent-role">Tracks audit logs, manages intervention transparency, handles human approval workflows, and maintains policy compliance.</div>
        <div class="agent-model">GPT-4o-mini</div>
        <div class="agent-skills"><span class="agent-skill">audit</span><span class="agent-skill">compliance</span><span class="agent-skill">approval</span></div>
      </div>

      <div class="agent a-channel">
        <div class="agent-name">Channel Agent</div>
        <div class="agent-role">Manages pluggable communication connectors (Telegram, Discord, Matrix, etc.). Handles channel-specific policies and routing.</div>
        <div class="agent-model">Gemini Flash 2.0</div>
        <div class="agent-skills"><span class="agent-skill">telegram</span><span class="agent-skill">discord</span><span class="agent-skill">matrix</span></div>
      </div>

      <div class="agent a-knowledge">
        <div class="agent-name">Knowledge Agent</div>
        <div class="agent-role">Searches web, YouTube transcripts, scientific papers, and provides summarization and context enrichment for family queries.</div>
        <div class="agent-model">GPT-4o + local</div>
        <div class="agent-skills"><span class="agent-skill">web-search</span><span class="agent-skill">summarize</span><span class="agent-skill">papers</span></div>
      </div>

      <div class="agent a-diagram">
        <div class="agent-name">Diagram Agent</div>
        <div class="agent-role">Generates architecture diagrams, system maps, causal loops, and flowcharts via drawio-skill integration.</div>
        <div class="agent-model">GPT-4o</div>
        <div class="agent-skills"><span class="agent-skill">flowchart</span><span class="agent-skill">architecture</span><span class="agent-skill">causal-loop</span></div>
      </div>
    </div>

    <div class="comm-bus">
      <div class="bus-card">
        <div class="bus-title">Event Bus (NATS)</div>
        <div class="bus-items">
          <div class="bus-item">signal.detected</div>
          <div class="bus-item">anomaly.triggered</div>
          <div class="bus-item">escalation.warning</div>
          <div class="bus-item">intervention.proposed</div>
          <div class="bus-item">intervention.approved</div>
          <div class="bus-item">intervention.vetoed</div>
          <div class="bus-item">memory.updated</div>
          <div class="bus-item">forecast.published</div>
          <div class="bus-item">simulation.complete</div>
        </div>
      </div>

      <div class="bus-card">
        <div class="bus-title">Consensus Protocol</div>
        <div class="bus-items">
          <div class="bus-item">1. Agent proposes action</div>
          <div class="bus-item">2. Ethics Agent reviews</div>
          <div class="bus-item">3. Relevant agents vote</div>
          <div class="bus-item">4. Human oversight confirms</div>
          <div class="bus-item">5. Action executed + logged</div>
        </div>
      </div>

      <div class="bus-card">
        <div class="bus-title">Model Selection Logic</div>
        <div class="bus-items">
          <div class="bus-item">Reasoning: GPT-4o class</div>
          <div class="bus-item">Mediation: Claude class</div>
          <div class="bus-item">Monitoring: Gemini Flash</div>
          <div class="bus-item">Privacy: Local models</div>
          <div class="bus-item">Speed: Flash / Mini</div>
        </div>
      </div>

      <div class="principle">
        No single agent possesses global authority.<br/>
        Consensus mechanisms preferred over centralized decisions.
      </div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/04-swarm-agents.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 4 done');
})();
