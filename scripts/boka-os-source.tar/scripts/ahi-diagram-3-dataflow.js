// Diagram 3: Data Flow Map
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .map { display: flex; gap: 20px; }

  /* Source column */
  .sources { width: 220px; display: flex; flex-direction: column; gap: 10px; }
  .src-card {
    padding: 12px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
    font-size: 12px;
  }
  .src-label { color: #b69e6f; font-weight: 600; font-size: 11px; text-transform: uppercase; margin-bottom: 4px; }
  .src-items { color: #97948e; font-size: 11px; line-height: 1.6; }

  /* Center pipeline */
  .pipeline { flex: 1; display: flex; flex-direction: column; gap: 12px; }
  .pipe-stage {
    padding: 14px 18px; border-radius: 8px; border: 1px solid #4b4636; position: relative;
  }
  .pipe-label { font-weight: 700; font-size: 13px; margin-bottom: 6px; }
  .pipe-items { display: flex; gap: 6px; flex-wrap: wrap; }
  .pipe-item { font-size: 10px; padding: 3px 8px; border-radius: 3px; }
  .pipe-output { font-size: 10px; color: #97948e; margin-top: 6px; font-style: italic; }

  .s1 { background: rgba(182,158,111,0.06); } .s1 .pipe-label { color: #b69e6f; }
  .s1 .pipe-item { background: rgba(182,158,111,0.1); color: #b69e6f; border: 1px solid rgba(182,158,111,0.2); }
  .s2 { background: rgba(134,114,195,0.06); } .s2 .pipe-label { color: #8672c3; }
  .s2 .pipe-item { background: rgba(134,114,195,0.1); color: #8672c3; border: 1px solid rgba(134,114,195,0.2); }
  .s3 { background: rgba(123,150,177,0.06); } .s3 .pipe-label { color: #7b96b1; }
  .s3 .pipe-item { background: rgba(123,150,177,0.1); color: #7b96b1; border: 1px solid rgba(123,150,177,0.2); }
  .s4 { background: rgba(117,177,137,0.06); } .s4 .pipe-label { color: #75b189; }
  .s4 .pipe-item { background: rgba(117,177,137,0.1); color: #75b189; border: 1px solid rgba(117,177,137,0.2); }

  .arrow-between { text-align: center; color: #4b4636; font-size: 20px; padding: 2px 0; }

  /* Storage column */
  .storages { width: 200px; display: flex; flex-direction: column; gap: 10px; }
  .store-card {
    padding: 12px; border-radius: 8px; background: #161614; border: 1px solid #4b4636; font-size: 11px;
  }
  .store-label { color: #d6b75d; font-weight: 600; font-size: 11px; margin-bottom: 4px; }
  .store-items { color: #97948e; line-height: 1.6; }

  .tech-bar {
    margin-top: 20px; padding: 12px 18px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
    display: flex; gap: 24px; justify-content: center;
  }
  .tech-item { font-size: 11px; color: #97948e; }
  .tech-item span { color: #d6b75d; font-weight: 600; }
</style></head><body>
  <div class="title">Data Flow Map</div>
  <div class="subtitle">How information flows from sources through processing to storage and action</div>

  <div class="map">
    <div class="sources">
      <div class="src-card"><div class="src-label">Social Media</div><div class="src-items">Twitter/X, Reddit, Forums, Comments</div></div>
      <div class="src-card"><div class="src-label">Messaging</div><div class="src-items">Telegram, Discord, WhatsApp, Signal, Matrix</div></div>
      <div class="src-card"><div class="src-label">Family Data</div><div class="src-items">Chat history, Voice memos, Emotions, Calendar</div></div>
      <div class="src-card"><div class="src-label">News & Media</div><div class="src-items">RSS, News APIs, YouTube transcripts</div></div>
      <div class="src-card"><div class="src-label">Environment</div><div class="src-items">IoT sensors, Weather, Air quality, Noise</div></div>
      <div class="src-card"><div class="src-label">Public Data</div><div class="src-items">Government datasets, Open data, Research</div></div>
    </div>

    <div class="pipeline">
      <div class="pipe-stage s1">
        <div class="pipe-label">Ingest & Parse</div>
        <div class="pipe-items">
          <span class="pipe-item">NLP Tokenizer</span><span class="pipe-item">Emotion Tagger</span><span class="pipe-item">Entity Extractor</span>
          <span class="pipe-item">Language Detector</span><span class="pipe-item">Channel Router</span>
        </div>
        <div class="pipe-output">Structured signals + metadata</div>
      </div>
      <div class="arrow-between">↓</div>
      <div class="pipe-stage s2">
        <div class="pipe-label">Analyze & Model</div>
        <div class="pipe-items">
          <span class="pipe-item">Causal Graph</span><span class="pipe-item">Tension Mapper</span><span class="pipe-item">Narrative Tracker</span>
          <span class="pipe-item">Anomaly Detector</span><span class="pipe-item">Dependency Builder</span>
        </div>
        <div class="pipe-output">Root causes + risk vectors + system state</div>
      </div>
      <div class="arrow-between">↓</div>
      <div class="pipe-stage s3">
        <div class="pipe-label">Predict & Simulate</div>
        <div class="pipe-items">
          <span class="pipe-item">Monte Carlo</span><span class="pipe-item">Agent Simulation</span><span class="pipe-item">Cascade Model</span>
          <span class="pipe-item">Forecast Engine</span>
        </div>
        <div class="pipe-output">Stability trajectories + escalation scenarios</div>
      </div>
      <div class="arrow-between">↓</div>
      <div class="pipe-stage s4">
        <div class="pipe-label">Harmonize & Act</div>
        <div class="pipe-items">
          <span class="pipe-item">De-escalation</span><span class="pipe-item">Context Enrichment</span><span class="pipe-item">Reflective Prompt</span>
          <span class="pipe-item">Manipulation Alert</span>
        </div>
        <div class="pipe-output">Soft interventions + audit records</div>
      </div>
    </div>

    <div class="storages">
      <div class="store-card"><div class="store-label">Graph Database</div><div class="store-items">Neo4j — Entities, relationships, causal chains, family connections</div></div>
      <div class="store-card"><div class="store-label">Vector Store</div><div class="store-items">Pinecone/Qdrant — Embeddings, semantic memory, episode recall</div></div>
      <div class="store-card"><div class="store-label">Event Bus</div><div class="store-items">Kafka/NATS — Real-time events, inter-agent communication</div></div>
      <div class="store-card"><div class="store-label">Skill Registry</div><div class="store-items">HermesHub — Versioned skills, trust scores, provenance</div></div>
      <div class="store-card"><div class="store-label">Audit Log</div><div class="store-items">Immutable store — All interventions, decisions, vetoes</div></div>
      <div class="store-card"><div class="store-label">Family Memory</div><div class="store-items">SQLite/Prisma — Episodic, semantic, workflow, reflection per person</div></div>
    </div>
  </div>

  <div class="tech-bar">
    <div class="tech-item"><span>LLM:</span> GPT-4o, Claude, Gemini Flash</div>
    <div class="tech-item"><span>Graph:</span> Neo4j + NetworkX</div>
    <div class="tech-item"><span>Vector:</span> Qdrant + Embeddings</div>
    <div class="tech-item"><span>Events:</span> NATS JetStream</div>
    <div class="tech-item"><span>Runtime:</span> Bun + Next.js</div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/03-data-flow.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 3 done');
})();
