// Diagram 5: Ethical Safeguard Diagram
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1200px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .safeguards { display: flex; flex-direction: column; gap: 16px; }

  .safeguard-row { display: flex; gap: 14px; }

  .sg-card {
    flex: 1; padding: 16px; border-radius: 10px; background: #161614; border: 1px solid #4b4636;
  }
  .sg-header { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
  .sg-icon {
    width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
    font-size: 16px; font-weight: 800;
  }
  .sg-title { font-size: 14px; font-weight: 700; }
  .sg-desc { font-size: 11px; color: #97948e; line-height: 1.6; margin-bottom: 8px; }
  .sg-mechanisms { display: flex; flex-wrap: wrap; gap: 4px; }
  .sg-mech { font-size: 10px; padding: 3px 8px; border-radius: 3px; background: rgba(199,186,147,0.08); border: 1px solid rgba(199,186,147,0.15); color: #c7ba93; }

  .sg-prevention .sg-icon { background: rgba(190,118,111,0.2); color: #be766f; }
  .sg-prevention .sg-title { color: #be766f; }
  .sg-transparency .sg-icon { background: rgba(123,150,177,0.2); color: #7b96b1; }
  .sg-transparency .sg-title { color: #7b96b1; }
  .sg-autonomy .sg-icon { background: rgba(117,177,137,0.2); color: #75b189; }
  .sg-autonomy .sg-title { color: #75b189; }
  .sg-oversight .sg-icon { background: rgba(214,183,93,0.2); color: #d6b75d; }
  .sg-oversight .sg-title { color: #d6b75d; }
  .sg-privacy .sg-icon { background: rgba(134,114,195,0.2); color: #8672c3; }
  .sg-privacy .sg-title { color: #8672c3; }
  .sg-decentralized .sg-icon { background: rgba(182,158,111,0.2); color: #b69e6f; }
  .sg-decentralized .sg-title { color: #b69e6f; }

  /* Decision gate */
  .decision-gate {
    padding: 18px 24px; border-radius: 10px; background: rgba(214,183,93,0.06);
    border: 2px solid rgba(214,183,93,0.3); margin-top: 8px;
  }
  .dg-title { font-size: 16px; font-weight: 700; color: #d6b75d; text-align: center; margin-bottom: 14px; }
  .dg-flow { display: flex; align-items: center; justify-content: center; gap: 10px; }
  .dg-step {
    padding: 10px 16px; border-radius: 8px; background: #272520; border: 1px solid #4b4636;
    font-size: 11px; text-align: center; min-width: 120px;
  }
  .dg-step-title { font-weight: 700; color: #d6b75d; margin-bottom: 3px; font-size: 12px; }
  .dg-step-desc { color: #97948e; font-size: 10px; }
  .dg-arrow { color: #4b4636; font-size: 20px; }
  .dg-reject {
    padding: 10px 16px; border-radius: 8px; background: rgba(190,118,111,0.1);
    border: 1px solid rgba(190,118,111,0.3); font-size: 11px; text-align: center; color: #be766f;
  }
</style></head><body>
  <div class="title">Ethical Safeguard System</div>
  <div class="subtitle">Six pillars preventing authoritarian misuse — every action passes through multiple ethical gates</div>

  <div class="safeguards">
    <div class="safeguard-row">
      <div class="sg-card sg-prevention">
        <div class="sg-header"><div class="sg-icon">!</div><div class="sg-title">Anti-Authoritarian Prevention</div></div>
        <div class="sg-desc">No single point of control. No optimization for engagement, surveillance, or profit. The system architecture itself prevents concentration of power.</div>
        <div class="sg-mechanisms"><span class="sg-mech">No Central Controller</span><span class="sg-mech">Engagement Decoupling</span><span class="sg-mech">Surveillance Ban</span><span class="sg-mech">Profit Neutrality</span></div>
      </div>

      <div class="sg-card sg-transparency">
        <div class="sg-header"><div class="sg-icon">E</div><div class="sg-title">Explainability & Transparency</div></div>
        <div class="sg-desc">Every AI decision is traceable. The system explains WHY it proposed an action, WHAT data it used, and HOW it reached its conclusion. No black boxes.</div>
        <div class="sg-mechanisms"><span class="sg-mech">Decision Traces</span><span class="sg-mech">Data Provenance</span><span class="sg-mech">Reasoning Chain</span><span class="sg-mech">Open Audit</span></div>
      </div>

      <div class="sg-card sg-autonomy">
        <div class="sg-header"><div class="sg-icon">A</div><div class="sg-title">Autonomy Protection</div></div>
        <div class="sg-desc">The system must preserve human agency. Interventions are suggestions, not commands. Disagreement is a feature, not a bug. Dissent is protected.</div>
        <div class="sg-mechanisms"><span class="sg-mech">Suggestion Mode</span><span class="sg-mech">Disagreement Protection</span><span class="sg-mech">Opt-Out Right</span><span class="sg-mech">Consent Required</span></div>
      </div>
    </div>

    <div class="safeguard-row">
      <div class="sg-card sg-oversight">
        <div class="sg-header"><div class="sg-icon">V</div><div class="sg-title">Human Veto System</div></div>
        <div class="sg-desc">Any family member can veto any AI action. Critical interventions require explicit human approval. The human always has the final word.</div>
        <div class="sg-mechanisms"><span class="sg-mech">Instant Veto</span><span class="sg-mech">Approval Workflow</span><span class="sg-mech">Rollback Capability</span><span class="sg-mech">Override Rights</span></div>
      </div>

      <div class="sg-card sg-privacy">
        <div class="sg-header"><div class="sg-icon">P</div><div class="sg-title">Privacy-Preserving Mechanisms</div></div>
        <div class="sg-desc">Family data stays local. Privacy-sensitive processing uses local models. No data leaves the home without explicit consent. PII is encrypted at rest.</div>
        <div class="sg-mechanisms"><span class="sg-mech">Local-First Processing</span><span class="sg-mech">Data Encryption</span><span class="sg-mech">Consent Gateway</span><span class="sg-mech">Right to Delete</span></div>
      </div>

      <div class="sg-card sg-decentralized">
        <div class="sg-header"><div class="sg-icon">D</div><div class="sg-title">Decentralized Governance</div></div>
        <div class="sg-desc">Family members collectively define values and policies. No single person controls the system. Changes require consensus. Rules evolve democratically.</div>
        <div class="sg-mechanisms"><span class="sg-mech">Family Council</span><span class="sg-mech">Consensus Voting</span><span class="sg-mech">Policy Evolution</span><span class="sg-mech">Equal Voice</span></div>
      </div>
    </div>
  </div>

  <div class="decision-gate">
    <div class="dg-title">Intervention Decision Gate — Every Proposed Action Must Pass</div>
    <div class="dg-flow">
      <div class="dg-step"><div class="dg-step-title">Propose</div><div class="dg-step-desc">Agent suggests action</div></div>
      <div class="dg-arrow">→</div>
      <div class="dg-step"><div class="dg-step-title">Ethics Check</div><div class="dg-step-desc">Policy + privacy review</div></div>
      <div class="dg-arrow">→</div>
      <div class="dg-step"><div class="dg-step-title">Explain</div><div class="dg-step-desc">Generate reasoning trace</div></div>
      <div class="dg-arrow">→</div>
      <div class="dg-step"><div class="dg-step-title">Human Approve</div><div class="dg-step-desc">Family member confirms</div></div>
      <div class="dg-arrow">→</div>
      <div class="dg-step"><div class="dg-step-title">Execute + Log</div><div class="dg-step-desc">Action + immutable audit</div></div>
      <div style="display:flex;flex-direction:column;gap:4px;margin-left:10px;">
        <div class="dg-reject">VETO — Action blocked</div>
        <div class="dg-reject">REJECT — Ethics fail</div>
      </div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/05-ethical-safeguards.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 5 done');
})();
