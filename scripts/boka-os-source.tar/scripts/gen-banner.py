#!/usr/bin/env python3
"""Generate ASCII art banner with home icon + BOKA wordmark."""

WIDTH = 62  # total width including borders

def pad(line):
    inner = WIDTH - 2
    if len(line) > inner:
        line = line[:inner]
    return "|" + line.ljust(inner) + "|"

def hr_top():
    return "+" + "=" * (WIDTH - 2) + "+"

def empty():
    return "|" + " " * (WIDTH - 2) + "|"

# House roof (small, centered)
house = [
    "                          /\\                              ",
    "                         /  \\                             ",
    "                        /____\\                            ",
    "                       /      \\                           ",
    "                      /________\\                          ",
    "                      |        |                          ",
    "                      |  BOKA  |                          ",
    "                      |   OS   |                          ",
    "                      |________|                          ",
]

# BOKA OS figlet-style ASCII art (5 lines)
boka = [
    "  ____  ___  ____ ___ ___    ___  ____  ",
    " | __ )/ _ \\| __/ __|_ _|  / _ \\/ ___| ",
    " |  _ \\| | | | _| (_ || |  | | | \\___ \\ ",
    " | |_) | |_| |__\\___||___| | |_| |___) |",
    " |____/ \\___/|_|            \\___/|____/ ",
]

# Version A: house only (smaller, cleaner)
lines_a = [""]
lines_a.append(hr_top())
lines_a.append(empty())
for h in house:
    lines_a.append(pad(h))
lines_a.append(empty())
lines_a.append(pad("                   Rodzinny System AI                       "))
lines_a.append(pad("                        v0.2.0                              "))
lines_a.append(empty())
lines_a.append(hr_top())
lines_a.append("")

# Version B: figlet BOKA OS (more "OS-like")
lines_b = [""]
lines_b.append(hr_top())
lines_b.append(empty())
for b in boka:
    lines_b.append(pad(b))
lines_b.append(empty())
lines_b.append(pad("                   Rodzinny System AI                       "))
lines_b.append(pad("                        v0.2.0                              "))
lines_b.append(empty())
lines_b.append(hr_top())
lines_b.append("")

# Version C: combined — small house above figlet
lines_c = [""]
lines_c.append(hr_top())
lines_c.append(empty())
# Small roof only (4 lines) for combined version
small_roof = [
    "                       /\\                                  ",
    "                      /  \\                                 ",
    "                     /____\\                                ",
]
for h in small_roof:
    lines_c.append(pad(h))
lines_c.append(empty())
for b in boka:
    lines_c.append(pad(b))
lines_c.append(empty())
lines_c.append(pad("                   Rodzinny System AI                       "))
lines_c.append(pad("                        v0.2.0                              "))
lines_c.append(empty())
lines_c.append(hr_top())
lines_c.append("")

print("=== VERSION A: House only ===")
print("\n".join(lines_a))
print("\n\n=== VERSION B: Figlet BOKA OS ===")
print("\n".join(lines_b))
print("\n\n=== VERSION C: Combined (roof + figlet) ===")
print("\n".join(lines_c))

# Verify all lines are WIDTH chars
for name, lines in [("A", lines_a), ("B", lines_b), ("C", lines_c)]:
    bad = [i for i, l in enumerate(lines) if l and len(l) != WIDTH]
    if bad:
        print(f"\n⚠ Version {name} has bad lines: {bad}")
    else:
        print(f"✓ Version {name} all aligned")

# Save all versions
for name, lines in [("a", lines_a), ("b", lines_b), ("c", lines_c)]:
    with open(f"/home/z/my-project/scripts/banner-{name}.txt", "w") as f:
        f.write("\n".join(lines))
print("\nSaved banner-a.txt, banner-b.txt, banner-c.txt")
