#!/usr/bin/env python3
"""
BOKA OS — Whisper Local ASR Bridge
Uruchamiany jako subprocess z Node.js

UŻYCIE:
  echo "<base64_audio>" | python3 whisper-bridge.py --model medium --language pl
  python3 whisper-bridge.py --file audio.wav --model small --language pl

MODELE:
  - tiny    (~75MB)  — najszybszy, najniższa jakość
  - base    (~150MB) — szybki, podstawowa jakość
  - small   (~500MB) — dobry kompromis
  - medium  (~1.5GB) — najlepsza jakość PL ← ZALECANY
  - large   (~3GB)   — najlepszy, najwolniejszy
"""

import sys
import json
import base64
import argparse
import tempfile
import os

def main():
    parser = argparse.ArgumentParser(description='BOKA Whisper ASR Bridge')
    parser.add_argument('--model', default='medium', 
                        choices=['tiny', 'base', 'small', 'medium', 'large'],
                        help='Whisper model size (default: medium)')
    parser.add_argument('--language', default='pl',
                        help='Language code (default: pl)')
    parser.add_argument('--file', default=None,
                        help='Audio file path (if not using stdin)')
    parser.add_argument('--compute-type', default='int8',
                        choices=['float32', 'float16', 'int8'],
                        help='Compute type (default: int8)')
    parser.add_argument('--device', default='cpu',
                        choices=['cpu', 'cuda'],
                        help='Device (default: cpu)')
    
    args = parser.parse_args()
    
    try:
        from faster_whisper import WhisperModel
        
        # Load model
        print(f"LOADING:{args.model}", file=sys.stderr, flush=True)
        model = WhisperModel(
            args.model, 
            device=args.device, 
            compute_type=args.compute_type
        )
        print(f"LOADED:{args.model}", file=sys.stderr, flush=True)
        
        # Get audio input
        if args.file:
            audio_path = args.file
        else:
            # Read base64 from stdin
            print("READING_STDIN", file=sys.stderr, flush=True)
            b64_data = sys.stdin.read().strip()
            if not b64_data:
                result = {"error": "No audio data provided", "text": "", "segments": []}
                print(json.dumps(result, ensure_ascii=False))
                sys.exit(1)
            
            # Decode base64 to temp file
            audio_bytes = base64.b64decode(b64_data)
            tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            tmp.write(audio_bytes)
            tmp.close()
            audio_path = tmp.name
        
        # Transcribe
        print("TRANSCRIBING", file=sys.stderr, flush=True)
        segments_iter, info = model.transcribe(
            audio_path,
            language=args.language,
            beam_size=5,
            vad_filter=True,  # Voice Activity Detection
            vad_parameters=dict(
                min_silence_duration_ms=500,
                speech_pad_ms=200
            )
        )
        
        # Collect segments
        segments = []
        full_text = []
        for segment in segments_iter:
            seg = {
                "start": round(segment.start, 2),
                "end": round(segment.end, 2),
                "text": segment.text.strip()
            }
            segments.append(seg)
            full_text.append(segment.text.strip())
        
        # Clean up temp file
        if not args.file and audio_path.startswith(tempfile.gettempdir()):
            try:
                os.unlink(audio_path)
            except:
                pass
        
        # Output JSON result
        result = {
            "text": " ".join(full_text),
            "segments": segments,
            "language": info.language,
            "language_probability": round(info.language_probability, 3),
            "duration": round(info.duration, 2),
            "model": args.model
        }
        
        print(json.dumps(result, ensure_ascii=False))
        
    except ImportError:
        result = {
            "error": "faster-whisper not installed. Run: pip install faster-whisper",
            "text": "",
            "segments": []
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        result = {
            "error": str(e),
            "text": "",
            "segments": []
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)

if __name__ == "__main__":
    main()
