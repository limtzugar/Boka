#!/usr/bin/env python3
"""
BOKA OS — Whisper Local Server
Lekki HTTP server dla lokalnego Whisper ASR

Uruchomienie:
  python3 whisper-server.py --port 5100 --model medium

Endpoints:
  GET  /health        → {"status": "ok", "model": "medium"}
  POST /transcribe    → {"text": "...", "language": "pl", ...}
  POST /transcribe    body: audio=<base64>&language=pl
"""

import sys
import json
import base64
import argparse
import tempfile
import os
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs

# Global model — ładuj raz, używaj wielokrotnie
whisper_model = None
model_name = "medium"

class WhisperHandler(BaseHTTPRequestHandler):
    """HTTP handler dla Whisper ASR"""
    
    def log_message(self, format, *args):
        """Ciche logowanie"""
        print(f"[Whisper] {format % args}", flush=True)
    
    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def do_OPTIONS(self):
        """CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        """Health check"""
        if self.path == '/health':
            self._send_json({
                "status": "ok" if whisper_model else "loading",
                "model": model_name,
                "device": "cpu",
                "compute_type": "int8",
                "uptime": round(time.time() - start_time, 1)
            })
        else:
            self._send_json({"error": "Unknown endpoint"}, 404)
    
    def do_POST(self):
        """Transcribe audio"""
        if self.path != '/transcribe':
            self._send_json({"error": "Unknown endpoint"}, 404)
            return
        
        if not whisper_model:
            self._send_json({"error": "Model still loading"}, 503)
            return
        
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length).decode('utf-8')
            
            # Parse form data or JSON
            language = 'pl'
            base64_data = ''
            
            content_type = self.headers.get('Content-Type', '')
            
            if 'application/json' in content_type:
                data = json.loads(body)
                base64_data = data.get('audio', '')
                language = data.get('language', 'pl')
            else:
                # Form-encoded
                params = parse_qs(body)
                base64_data = params.get('audio', [''])[0]
                language = params.get('language', ['pl'])[0]
            
            # Strip data URL prefix
            if ',' in base64_data:
                base64_data = base64_data.split(',', 1)[1]
            
            if not base64_data or len(base64_data) < 100:
                self._send_json({"error": "Audio too short", "text": ""}, 400)
                return
            
            # Decode base64 → temp file
            audio_bytes = base64.b64decode(base64_data)
            tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            tmp.write(audio_bytes)
            tmp.close()
            audio_path = tmp.name
            
            # Transcribe
            t_start = time.time()
            segments_iter, info = whisper_model.transcribe(
                audio_path,
                language=language,
                beam_size=5,
                vad_filter=True,
                vad_parameters=dict(
                    min_silence_duration_ms=500,
                    speech_pad_ms=200
                )
            )
            
            segments = []
            full_text = []
            for segment in segments_iter:
                segments.append({
                    "start": round(segment.start, 2),
                    "end": round(segment.end, 2),
                    "text": segment.text.strip()
                })
                full_text.append(segment.text.strip())
            
            t_end = time.time()
            
            # Cleanup
            try:
                os.unlink(audio_path)
            except:
                pass
            
            result = {
                "text": " ".join(full_text),
                "segments": segments,
                "language": info.language,
                "language_probability": round(info.language_probability, 3),
                "duration_seconds": round(info.duration, 2),
                "processing_time": round(t_end - t_start, 2),
                "model": model_name
            }
            
            text_preview = result["text"][:80] + "..." if len(result["text"]) > 80 else result["text"]
            print(f"  → [{language}] {text_preview} ({result['duration_seconds']}s audio, {result['processing_time']}s process)", flush=True)
            
            self._send_json(result)
            
        except Exception as e:
            print(f"  ✗ Error: {e}", flush=True)
            self._send_json({"error": str(e), "text": ""}, 500)


def main():
    global whisper_model, model_name, start_time
    
    parser = argparse.ArgumentParser(description='BOKA Whisper Local Server')
    parser.add_argument('--port', type=int, default=5100, help='Port (default: 5100)')
    parser.add_argument('--model', default='medium',
                        choices=['tiny', 'base', 'small', 'medium', 'large'],
                        help='Whisper model (default: medium)')
    parser.add_argument('--language', default='pl', help='Default language (default: pl)')
    parser.add_argument('--compute-type', default='int8',
                        choices=['float32', 'float16', 'int8'],
                        help='Compute type (default: int8)')
    parser.add_argument('--device', default='cpu',
                        choices=['cpu', 'cuda'],
                        help='Device (default: cpu)')
    
    args = parser.parse_args()
    model_name = args.model
    start_time = time.time()
    
    print(f"╔══════════════════════════════════════════════╗", flush=True)
    print(f"║  🎤 BOKA Whisper Server                      ║", flush=True)
    print(f"║  Model: {args.model:<10}  Device: {args.device:<6}          ║", flush=True)
    print(f"║  Port: {args.port:<6}   Language: {args.language:<4}          ║", flush=True)
    print(f"╚══════════════════════════════════════════════╝", flush=True)
    
    # Load model
    print(f"Ładuję model Whisper {args.model}...", flush=True)
    try:
        from faster_whisper import WhisperModel
        whisper_model = WhisperModel(
            args.model,
            device=args.device,
            compute_type=args.compute_type
        )
        print(f"✓ Model {args.model} załadowany!", flush=True)
    except ImportError:
        print("✗ faster-whisper nie zainstalowany! Uruchom: pip install faster-whisper", flush=True)
        sys.exit(1)
    except Exception as e:
        print(f"✗ Błąd ładowania modelu: {e}", flush=True)
        sys.exit(1)
    
    # Start server
    server = HTTPServer(('0.0.0.0', args.port), WhisperHandler)
    print(f"✓ Serwer nasłuchuje na http://0.0.0.0:{args.port}", flush=True)
    print(f"  GET  /health      → status", flush=True)
    print(f"  POST /transcribe  → transkrypcja audio", flush=True)
    print(f"", flush=True)
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nZatrzymuję serwer...", flush=True)
        server.server_close()


if __name__ == "__main__":
    main()
