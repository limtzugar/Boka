// Diagram 7: Equilibrium Feedback Cycle
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1200px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .cycle-container { display: flex; gap: 24px; }

  .cycle-visual { flex: 1; position: relative; height: 700px; }

  /* Central equilibrium engine */
  .eq-engine {
    position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
    width: 200px; height: 200px; border-radius: 50%;
    background: radial-gradient(circle, rgba(214,183,93,0.12) 0%, rgba(214,183,93,0.03) 70%);
    border: 2px solid rgba(214,183,93,0.4);
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    text-align: center;
  }
  .eq-title { font-size: 14px; font-weight: 800; color: #d6b75d; margin-bottom: 4px; }
  .eq-sub { font-size: 10px; color: #97948e; line-height: 1.4; }

  /* Orbit nodes */
  .orbit-node {
    position: absolute; width: 140px; padding: 12px; border-radius: 10px;
    background: #161614; border: 1px solid #4b4636; text-align: center;
  }
  .on-icon { font-size: 18px; font-weight: 800; margin-bottom: 4px; }
  .on-title { font-size: 12px; font-weight: 700; margin-bottom: 3px; }
  .on-desc { font-size: 10px; color: #97948e; line-height: 1.3; }

  .o1 { top: 30px; left: 50%; transform: translateX(-50%); }
  .o1 .on-icon { color: #be766f; } .o1 .on-title { color: #be766f; }
  .o2 { top: 160px; right: 50px; }
  .o2 .on-icon { color: #b69e6f; } .o2 .on-title { color: #b69e6f; }
  .o3 { bottom: 160px; right: 50px; }
  .o3 .on-icon { color: #7b96b1; } .o3 .on-title { color: #7b96b1; }
  .o4 { bottom: 30px; left: 50%; transform: translateX(-50%); }
  .o4 .on-icon { color: #75b189; } .o4 .on-title { color: #75b189; }
  .o5 { bottom: 160px; left: 50px; }
  .o5 .on-icon { color: #8672c3; } .o5 .on-title { color: #8672c3; }
  .o6 { top: 160px; left: 50px; }
  .o6 .on-icon { color: #c7ba93; } .o6 .on-title { color: #c7ba93; }

  /* Metrics panel */
  .metrics-panel { width: 300px; display: flex; flex-direction: column; gap: 10px; }
  .metric-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .metric-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
  .metric-name { font-size: 12px; font-weight: 600; color: #e3e3e1; }
  .metric-value { font-size: 18px; font-weight: 800; color: #d6b75d; }
  .metric-bar { height: 4px; border-radius: 2px; background: #272520; margin-bottom: 4px; }
  .metric-fill { height: 100%; border-radius: 2px; }
  .metric-desc { font-size: 10px; color: #97948e; }

  .m-conflict .metric-fill { background: #75b189; width: 78%; }
  .m-quality .metric-fill { background: #7b96b1; width: 85%; }
  .m-emotion .metric-fill { background: #8672c3; width: 72%; }
  .m-diversity .metric-fill { background: #b69e6f; width: 91%; }
  .m-resilience .metric-fill { background: #d6b75d; width: 83%; }
  .m-coherence .metric-fill { background: #c7ba93; width: 76%; }
  .m-ecology .metric-fill { background: #75b189; width: 68%; }

  .insight-box {
    padding: 14px; border-radius: 8px; background: rgba(214,183,93,0.06);
    border: 1px solid rgba(214,183,93,0.2); margin-top: 6px;
  }
  .insight-title { font-size: 12px; font-weight: 700; color: #d6b75d; margin-bottom: 6px; }
  .insight-text { font-size: 11px; color: #97948e; line-height: 1.6; }

  /* SVG arrows */
  .arrows-svg {
    position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none;
  }
</style></head><body>
  <div class="title">Equilibrium Feedback Cycle</div>
  <div class="subtitle">Dynamic balance — the system seeks equilibrium, not maximization</div>

  <div class="cycle-container">
    <div class="cycle-visual">
      <svg class="arrows-svg" viewBox="0 0 860 700">
        <defs>
          <marker id="arr" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="#4b4636"/>
          </marker>
        </defs>
        <!-- Outer cycle: o1→o2→o3→o4→o5→o6→o1 -->
        <path d="M 500 110 Q 620 130 680 220" stroke="#4b4636" stroke-width="1.5" fill="none" marker-end="url(#arr)" stroke-dasharray="4,3"/>
        <path d="M 750 380 Q 760 500 700 570" stroke="#4b4636" stroke-width="1.5" fill="none" marker-end="url(#arr)" stroke-dasharray="4,3"/>
        <path d="M 560 630 Q 440 660 360 630" stroke="#4b4636" stroke-width="1.5" fill="none" marker-end="url(#arr)" stroke-dasharray="4,3"/>
        <path d="M 200 570 Q 130 500 120 380" stroke="#4b4636" stroke-width="1.5" fill="none" marker-end="url(#arr)" stroke-dasharray="4,3"/>
        <path d="M 180 220 Q 220 130 350 100" stroke="#4b4636" stroke-width="1.5" fill="none" marker-end="url(#arr)" stroke-dasharray="4,3"/>

        <!-- Inner connections to center -->
        <line x1="430" y1="145" x2="430" y2="270" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
        <line x1="680" y1="310" x2="530" y2="340" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
        <line x1="680" y1="480" x2="530" y2="410" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
        <line x1="430" y1="600" x2="430" y2="470" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
        <line x1="180" y1="480" x2="330" y2="410" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
        <line x1="180" y1="310" x2="330" y2="340" stroke="rgba(214,183,93,0.15)" stroke-width="1" stroke-dasharray="3,4"/>
      </svg>

      <div class="eq-engine">
        <div class="eq-title">EQUILIBRIUM<br/>ENGINE</div>
        <div class="eq-sub">Balance, not<br/>maximization</div>
      </div>

      <div class="orbit-node o1">
        <div class="on-icon">D</div>
        <div class="on-title">Detect Imbalance</div>
        <div class="on-desc">Sensors identify stress, conflict, instability</div>
      </div>
      <div class="orbit-node o2">
        <div class="on-icon">A</div>
        <div class="on-title">Analyze Cause</div>
        <div class="on-desc">Root cause analysis and causal inference</div>
      </div>
      <div class="orbit-node o3">
        <div class="on-icon">S</div>
        <div class="on-title">Simulate Options</div>
        <div class="on-desc">Predict outcomes of possible interventions</div>
      </div>
      <div class="orbit-node o4">
        <div class="on-icon">H</div>
        <div class="on-title">Harmonize</div>
        <div class="on-desc">Apply minimal, soft intervention</div>
      </div>
      <div class="orbit-node o5">
        <div class="on-icon">M</div>
        <div class="on-title">Measure Effect</div>
        <div class="on-desc">Evaluate impact on equilibrium metrics</div>
      </div>
      <div class="orbit-node o6">
        <div class="on-icon">L</div>
        <div class="on-title">Learn & Adapt</div>
        <div class="on-desc">Update models based on outcomes</div>
      </div>
    </div>

    <div class="metrics-panel">
      <div class="metric-card m-conflict">
        <div class="metric-header"><div class="metric-name">Conflict Reduction</div><div class="metric-value">78%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Family disputes de-escalated successfully</div>
      </div>
      <div class="metric-card m-quality">
        <div class="metric-header"><div class="metric-name">Information Quality</div><div class="metric-value">85%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Verified, contextualized information ratio</div>
      </div>
      <div class="metric-card m-emotion">
        <div class="metric-header"><div class="metric-name">Emotional Stability</div><div class="metric-value">72%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Calm, balanced emotional state frequency</div>
      </div>
      <div class="metric-card m-diversity">
        <div class="metric-header"><div class="metric-name">Viewpoint Diversity</div><div class="metric-value">91%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Multiple perspectives preserved in dialogue</div>
      </div>
      <div class="metric-card m-resilience">
        <div class="metric-header"><div class="metric-name">Manipulation Resilience</div><div class="metric-value">83%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Detected and neutralized influence attempts</div>
      </div>
      <div class="metric-card m-coherence">
        <div class="metric-header"><div class="metric-name">Social Coherence</div><div class="metric-value">76%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Family bond and connection strength</div>
      </div>
      <div class="metric-card m-ecology">
        <div class="metric-header"><div class="metric-name">Ecological Awareness</div><div class="metric-value">68%</div></div>
        <div class="metric-bar"><div class="metric-fill"></div></div>
        <div class="metric-desc">Environmental sensitivity in decisions</div>
      </div>

      <div class="insight-box">
        <div class="insight-title">Key Insight</div>
        <div class="insight-text">Unlike traditional AI optimized for performance, AHI optimizes for dynamic equilibrium. Higher scores mean the system needs LESS intervention, not more.</div>
      </div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/07-equilibrium-cycle.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 7 done');
})();
