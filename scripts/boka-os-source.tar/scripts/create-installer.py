#!/usr/bin/env python3
"""
BOKA OS — Generator instalatora Windows .exe

Tworzy samorozpakowujący się .exe używając:
1. Minimalnego PE stub (napisanego w C i skompilowanego cross-platform)
2. Albo podejścia batch-in-exe (Windows .cmd wrapped in .exe shell)

Najlepsze podejście: Stworzyć PowerShell-based .exe installer.
Windows ma PowerShell wbudowany, więc tworzymy .exe który uruchamia PS.
"""

import os
import sys
import struct
import base64
import zlib
import shutil
from pathlib import Path

def create_boka_exe(output_path, archive_path):
    """
    Create a Windows .exe installer that:
    1. Self-extracts to temp directory  
    2. Runs the PowerShell installer
    
    Uses the "COMSPEC .exe" trick - a valid PE that launches cmd.exe
    which extracts embedded files and runs PowerShell.
    
    Actually, the simplest reliable approach:
    Create a .cmd file renamed to .exe won't work.
    
    Instead: Create a proper Windows .bat installer and 
    use a tiny .exe launcher that runs it.
    """
    
    # Read the archive
    with open(archive_path, 'rb') as f:
        archive_data = f.read()
    
    # Read the PowerShell installer
    ps1_path = Path(__file__).parent.parent / "download" / "install-boka.ps1"
    with open(ps1_path, 'r', encoding='utf-8') as f:
        ps1_content = f.read()
    
    # Create a self-extracting batch script
    # This approach: .cmd file with embedded base64 data
    # that extracts itself and runs the PowerShell installer
    
    archive_b64 = base64.b64encode(archive_data).decode('ascii')
    
    # Split base64 into lines of 76 chars
    b64_lines = [archive_b64[i:i+76] for i in range(0, len(archive_b64), 76)]
    
    bat_content = '''@echo off
setlocal enabledelayedexpansion
title BOKA OS v0.2.0 — Instalator
color 0A

echo.
echo ══════════════════════════════════════════════════════
echo   🏠 BOKA OS v0.2.0
echo   Rodzinny System AI
echo ══════════════════════════════════════════════════════
echo.

:: Check if this is first run or update
set "INSTALL_DIR=C:\\Boka"
set "APP_DIR=C:\\Boka\\app"
set "MEMORY_DIR=C:\\Boka\\memory"

:: ── KROK 1: Sprawdz Node.js ──
echo [1/7] Sprawdzam Node.js...
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo.
    echo ❌ Node.js nie jest zainstalowany!
    echo.
    echo BOKA wymaga Node.js 18+. Pobierz z:
    echo   https://nodejs.org
    echo.
    echo Wybierz wersje LTS i zainstaluj.
    echo Po instalacji uruchom ten instalator ponownie.
    echo.
    start https://nodejs.org
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo   ✓ Node.js %NODE_VER%

where npm >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo ❌ npm nie znaleziony
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('npm -v') do set NPM_VER=%%v
echo   ✓ npm %NPM_VER%

:: ── KROK 2: Rozpakuj archiwum ──
echo.
echo [2/7] Rozpakowuje kod BOKA...

:: Create directories
if not exist "%APP_DIR%" mkdir "%APP_DIR%"
if not exist "%MEMORY_DIR%\\db" mkdir "%MEMORY_DIR%\\db"
if not exist "%MEMORY_DIR%\\vault" mkdir "%MEMORY_DIR%\\vault"
if not exist "%MEMORY_DIR%\\daily-notes" mkdir "%MEMORY_DIR%\\daily-notes"
if not exist "%MEMORY_DIR%\\settings" mkdir "%MEMORY_DIR%\\settings"
if not exist "%MEMORY_DIR%\\backups" mkdir "%MEMORY_DIR%\\backups"
if not exist "%MEMORY_DIR%\\logs" mkdir "%MEMORY_DIR%\\logs"
if not exist "%MEMORY_DIR%\\scripts\\whisper" mkdir "%MEMORY_DIR%\\scripts\\whisper"

:: Decode embedded archive
set "TEMP_ARCHIVE=%TEMP%\\boka-os-source.tar.gz"
echo   Dekoduje archiwum...

:: Write base64 to temp file, then decode with certutil
set "B64_FILE=%TEMP%\\boka-archive.b64"
if exist "%B64_FILE%" del "%B64_FILE%"

'''
    
    # Add base64 data as echo commands (write to temp file)
    # certutil can decode base64 on Windows
    chunk_size = 4000
    for i in range(0, len(b64_lines), chunk_size // 76 + 1):
        chunk = '\n'.join(b64_lines[i:i + chunk_size // 76 + 1])
        bat_content += f'echo {chunk}>> "%B64_FILE%"\n'
    
    bat_content += '''
:: Decode base64 to binary using certutil (built into Windows)
certutil -decode "%B64_FILE%" "%TEMP_ARCHIVE%" >nul 2>nul
if not exist "%TEMP_ARCHIVE%" (
    echo ❌ Nie udalo sie zdekodowac archiwum
    pause
    exit /b 1
)
del "%B64_FILE%" >nul 2>nul

:: Extract using tar (built into Windows 10+)
echo   Rozpakowuje...
tar xzf "%TEMP_ARCHIVE%" -C "%APP_DIR%"
if %ERRORLEVEL% neq 0 (
    echo ❌ Nie udalo sie rozpakowac
    pause
    exit /b 1
)
del "%TEMP_ARCHIVE%" >nul 2>nul
echo   ✓ Kod rozpakowany do %APP_DIR%

:: ── KROK 3: Konfiguruj .env ──
echo.
echo [3/7] Konfiguruje srodowisko...

set "DB_PATH=%MEMORY_DIR:\\=/%/db/boka.db"
set "MEM_PATH=%MEMORY_DIR:\\=/%"

(
echo # BOKA OS - Konfiguracja
echo DATABASE_URL=file:%DB_PATH%
echo BOKA_MEMORY_DIR=%MEM_PATH%
) > "%APP_DIR%\\.env"

echo   ✓ .env skonfigurowany

:: ── KROK 4: npm install ──
echo.
echo [4/7] Instaluje zaleznosci (moze potrwac kilka minut)...
cd /d "%APP_DIR%"
call npm install --legacy-peer-deps
if %ERRORLEVEL% neq 0 (
    echo ⚠ npm install mial bledy, kontynuuje...
)

:: ── KROK 5: Prisma ──
echo.
echo [5/7] Baza danych...
set "DATABASE_URL=file:%DB_PATH%"
call npx prisma generate
call npx prisma db push --skip-generate
echo   ✓ Baza gotowa

:: ── KROK 6: Build ──
echo.
echo [6/7] Buduje BOKA (1-3 minuty)...
call npm run build
if %ERRORLEVEL% neq 0 (
    echo ⚠ Build mial bledy. Sprobuj: cd %APP_DIR% && npm run build
)

:: ── KROK 7: Skroty i start ──
echo.
echo [7/7] Tworze skroty...

:: Desktop shortcut
set "DESKTOP_BAT=%USERPROFILE%\\Desktop\\BOKA OS.bat"
(
echo @echo off
echo title BOKA OS
echo cd /d "%APP_DIR%"
echo set DATABASE_URL=file:%DB_PATH%
echo set BOKA_MEMORY_DIR=%MEM_PATH%
echo npx next start -p 3000
echo pause
) > "%DESKTOP_BAT%"

:: Start script in app dir
(
echo # BOKA OS - Start
echo $env:DATABASE_URL = "file:%DB_PATH%"
echo $env:BOKA_MEMORY_DIR = "%MEM_PATH%"
echo Set-Location "%APP_DIR%"
echo Write-Host "BOKA OS - http://localhost:3000" -ForegroundColor Cyan
echo npx next start -p 3000
) > "%APP_DIR%\\start-boka.ps1"

echo.
echo ══════════════════════════════════════════════════════
echo   ✅ BOKA OS ZAINSTALOWANA!
echo ══════════════════════════════════════════════════════
echo.
echo   📁 Aplikacja:  %APP_DIR%
echo   🧠 Pamiec:     %MEMORY_DIR%
echo   🌐 http://localhost:3000
echo.
echo   Skrot na pulpicie: BOKA OS.bat
echo.

:: Ask to start
set /p START="Uruchomic BOKA teraz? (T/n): "
if /i "%START%"=="n" exit /b 0

echo Uruchamiam BOKA...
start "" "http://localhost:3000"
set DATABASE_URL=file:%DB_PATH%
set BOKA_MEMORY_DIR=%MEM_PATH%
npx next start -p 3000
'''
    
    # Write the .cmd file
    cmd_path = output_path.replace('.exe', '.cmd')
    with open(cmd_path, 'w', encoding='utf-8', newline='\r\n') as f:
        f.write(bat_content)
    
    # Now create a minimal PE .exe wrapper that runs the .cmd
    # Using a tiny C program compiled for Windows
    exe_stub = create_exe_stub()
    
    if exe_stub:
        with open(output_path, 'wb') as f:
            f.write(exe_stub)
        print(f"✓ Created: {output_path} ({len(exe_stub)} bytes)")
    else:
        # Fallback: just use the .cmd file
        # On Windows, .cmd files can be double-clicked
        print(f"✓ Created: {cmd_path}")
        print("  (Windows .cmd installer — double-click to run)")
    
    return cmd_path


def create_exe_stub():
    """
    Create a minimal Windows PE .exe that runs a .cmd file.
    This is a hand-crafted PE that calls WinExec("cmd.exe /c BOKA-OS-Setup.cmd", 0)
    
    Actually, this is extremely complex to hand-craft.
    Better approach: Create a small .exe that's just a wrapper around cmd.exe
    """
    # We can't easily create a PE from scratch without a compiler
    # The practical solution: use the .cmd file directly
    # Windows users can double-click .cmd files
    return None


if __name__ == "__main__":
    archive = "/home/z/my-project/download/boka-os-source.tar.gz"
    output = "/home/z/my-project/download/BOKA-OS-Setup.exe"
    cmd_path = create_boka_exe(output, archive)
    print(f"\nInstalator: {cmd_path}")
