const path = require('path');
process.env.DATABASE_URL = `file:${path.resolve('/home/z/boka-memory/db/boka.db')}`;
process.env.BOKA_MEMORY_DIR = '/home/z/boka-memory';

(async () => {
  try {
    const { ensureFamilySeeded } = require('./src/lib/auto-seed.ts');
    // Need to compile TS — use ts-node
  } catch (e) {
    console.log('Direct import failed (TS), using npx tsx');
  }
})();
