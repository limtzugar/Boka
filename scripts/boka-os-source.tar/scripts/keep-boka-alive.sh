#!/bin/bash
# Watchdog: keeps BOKA server alive on ports 3112-3116
while true; do
  for port in 3112 3113 3114 3115 3116; do
    if ! ss -ltn 2>/dev/null | grep -q ":$port "; then
      cd /home/z/my-project/.next/standalone
      nohup setsid env PORT=$port HOSTNAME=0.0.0.0 node boka-runtime.js </dev/null >/tmp/boka-$port.log 2>&1 &
      disown
    fi
  done
  sleep 5
done
