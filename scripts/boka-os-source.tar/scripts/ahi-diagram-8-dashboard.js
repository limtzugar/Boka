// Diagram 8: Stability Metrics Dashboard Concept
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 40px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 30px; }

  /* Dashboard grid */
  .dashboard { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }

  .dash-card {
    padding: 16px; border-radius: 10px; background: #161614; border: 1px solid #4b4636;
  }
  .dc-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
  .dc-label { font-size: 11px; color: #97948e; text-transform: uppercase; letter-spacing: 0.5px; }
  .dc-trend { font-size: 10px; padding: 2px 6px; border-radius: 3px; }
  .dc-trend.up { background: rgba(117,177,137,0.15); color: #75b189; }
  .dc-trend.down { background: rgba(190,118,111,0.15); color: #be766f; }
  .dc-trend.stable { background: rgba(123,150,177,0.15); color: #7b96b1; }
  .dc-value { font-size: 32px; font-weight: 900; color: #d6b75d; margin-bottom: 6px; }
  .dc-bar { height: 6px; border-radius: 3px; background: #272520; margin-bottom: 4px; }
  .dc-fill { height: 100%; border-radius: 3px; }
  .dc-sub { font-size: 10px; color: #97948e; }

  /* Sparkline area (CSS only) */
  .sparkline { height: 40px; margin-top: 8px; display: flex; align-items: flex-end; gap: 2px; }
  .spark-bar { flex: 1; border-radius: 2px 2px 0 0; min-height: 3px; }

  .s1 .dc-fill { background: #75b189; } .s1 .spark-bar { background: rgba(117,177,137,0.4); }
  .s2 .dc-fill { background: #7b96b1; } .s2 .spark-bar { background: rgba(123,150,177,0.4); }
  .s3 .dc-fill { background: #8672c3; } .s3 .spark-bar { background: rgba(134,114,195,0.4); }
  .s4 .dc-fill { background: #d6b75d; } .s4 .spark-bar { background: rgba(214,183,93,0.4); }
  .s5 .dc-fill { background: #c7ba93; } .s5 .spark-bar { background: rgba(199,186,147,0.4); }
  .s6 .dc-fill { background: #b69e6f; } .s6 .spark-bar { background: rgba(182,158,111,0.4); }
  .s7 .dc-fill { background: #75b189; } .s7 .spark-bar { background: rgba(117,177,137,0.4); }
  .s8 .dc-fill { background: #7b96b1; } .s8 .spark-bar { background: rgba(123,150,177,0.4); }

  /* Wide cards */
  .wide { grid-column: span 2; }

  /* Family members */
  .family-row { display: flex; gap: 14px; margin-top: 14px; }
  .family-card {
    flex: 1; padding: 16px; border-radius: 10px; background: #161614; border: 1px solid #4b4636;
  }
  .fc-name { font-size: 14px; font-weight: 700; margin-bottom: 8px; }
  .fc-metrics { display: flex; gap: 12px; }
  .fc-metric { text-align: center; }
  .fc-metric-val { font-size: 20px; font-weight: 800; color: #d6b75d; }
  .fc-metric-label { font-size: 9px; color: #97948e; text-transform: uppercase; }

  .fm1 .fc-name { color: #75b189; }
  .fm2 .fc-name { color: #8672c3; }
  .fm3 .fc-name { color: #b69e6f; }

  /* Alerts section */
  .alerts {
    margin-top: 14px; padding: 16px; border-radius: 10px; background: #161614; border: 1px solid #4b4636;
  }
  .alerts-title { font-size: 13px; font-weight: 700; color: #d6b75d; margin-bottom: 10px; }
  .alert-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid rgba(75,70,54,0.3); }
  .alert-item:last-child { border-bottom: none; }
  .alert-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .alert-dot.green { background: #75b189; }
  .alert-dot.yellow { background: #b69e6f; }
  .alert-dot.red { background: #be766f; }
  .alert-text { font-size: 11px; color: #97948e; flex: 1; }
  .alert-time { font-size: 10px; color: #4b4636; }

  .status-bar {
    margin-top: 14px; padding: 12px 20px; border-radius: 8px;
    background: rgba(117,177,137,0.08); border: 1px solid rgba(117,177,137,0.2);
    display: flex; justify-content: space-between; align-items: center;
  }
  .status-text { font-size: 12px; color: #75b189; font-weight: 600; }
  .status-detail { font-size: 11px; color: #97948e; }
</style></head><body>
  <div class="title">Stability Metrics Dashboard</div>
  <div class="subtitle">Real-time family equilibrium monitoring — calm sail for the family</div>

  <div class="dashboard">
    <div class="dash-card s1">
      <div class="dc-header"><div class="dc-label">Conflict Level</div><div class="dc-trend down">-12%</div></div>
      <div class="dc-value">18%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:18%"></div></div>
      <div class="dc-sub">Low — No active disputes</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:60%"></div><div class="spark-bar" style="height:45%"></div>
        <div class="spark-bar" style="height:70%"></div><div class="spark-bar" style="height:35%"></div>
        <div class="spark-bar" style="height:50%"></div><div class="spark-bar" style="height:30%"></div>
        <div class="spark-bar" style="height:25%"></div><div class="spark-bar" style="height:20%"></div>
        <div class="spark-bar" style="height:18%"></div><div class="spark-bar" style="height:18%"></div>
      </div>
    </div>

    <div class="dash-card s2">
      <div class="dc-header"><div class="dc-label">Info Quality</div><div class="dc-trend up">+5%</div></div>
      <div class="dc-value">87%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:87%"></div></div>
      <div class="dc-sub">High — Verified sources</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:70%"></div><div class="spark-bar" style="height:75%"></div>
        <div class="spark-bar" style="height:72%"></div><div class="spark-bar" style="height:80%"></div>
        <div class="spark-bar" style="height:78%"></div><div class="spark-bar" style="height:82%"></div>
        <div class="spark-bar" style="height:85%"></div><div class="spark-bar" style="height:83%"></div>
        <div class="spark-bar" style="height:86%"></div><div class="spark-bar" style="height:87%"></div>
      </div>
    </div>

    <div class="dash-card s3">
      <div class="dc-header"><div class="dc-label">Emotional Balance</div><div class="dc-trend stable">+1%</div></div>
      <div class="dc-value">74%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:74%"></div></div>
      <div class="dc-sub">Stable — Calm atmosphere</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:65%"></div><div class="spark-bar" style="height:60%"></div>
        <div class="spark-bar" style="height:70%"></div><div class="spark-bar" style="height:72%"></div>
        <div class="spark-bar" style="height:68%"></div><div class="spark-bar" style="height:73%"></div>
        <div class="spark-bar" style="height:71%"></div><div class="spark-bar" style="height:74%"></div>
        <div class="spark-bar" style="height:73%"></div><div class="spark-bar" style="height:74%"></div>
      </div>
    </div>

    <div class="dash-card s4">
      <div class="dc-header"><div class="dc-label">System Health</div><div class="dc-trend up">+3%</div></div>
      <div class="dc-value">94%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:94%"></div></div>
      <div class="dc-sub">All agents operational</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:85%"></div><div class="spark-bar" style="height:88%"></div>
        <div class="spark-bar" style="height:90%"></div><div class="spark-bar" style="height:87%"></div>
        <div class="spark-bar" style="height:91%"></div><div class="spark-bar" style="height:89%"></div>
        <div class="spark-bar" style="height:92%"></div><div class="spark-bar" style="height:93%"></div>
        <div class="spark-bar" style="height:91%"></div><div class="spark-bar" style="height:94%"></div>
      </div>
    </div>

    <div class="dash-card s5 wide">
      <div class="dc-header"><div class="dc-label">Family Coherence Index</div><div class="dc-trend up">+8%</div></div>
      <div class="dc-value">82%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:82%"></div></div>
      <div class="dc-sub">Strong connections — Communication frequency healthy, shared activities trending up, emotional reciprocity high</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:55%"></div><div class="spark-bar" style="height:60%"></div>
        <div class="spark-bar" style="height:58%"></div><div class="spark-bar" style="height:65%"></div>
        <div class="spark-bar" style="height:70%"></div><div class="spark-bar" style="height:72%"></div>
        <div class="spark-bar" style="height:75%"></div><div class="spark-bar" style="height:78%"></div>
        <div class="spark-bar" style="height:80%"></div><div class="spark-bar" style="height:82%"></div>
        <div class="spark-bar" style="height:81%"></div><div class="spark-bar" style="height:82%"></div>
      </div>
    </div>

    <div class="dash-card s6 wide">
      <div class="dc-header"><div class="dc-label">Manipulation Shield</div><div class="dc-trend up">+15%</div></div>
      <div class="dc-value">89%</div>
      <div class="dc-bar"><div class="dc-fill" style="width:89%"></div></div>
      <div class="dc-sub">3 influence attempts detected and neutralized this week — misinformation resilience strong</div>
      <div class="sparkline">
        <div class="spark-bar" style="height:50%"></div><div class="spark-bar" style="height:55%"></div>
        <div class="spark-bar" style="height:60%"></div><div class="spark-bar" style="height:70%"></div>
        <div class="spark-bar" style="height:75%"></div><div class="spark-bar" style="height:80%"></div>
        <div class="spark-bar" style="height:83%"></div><div class="spark-bar" style="height:86%"></div>
        <div class="spark-bar" style="height:88%"></div><div class="spark-bar" style="height:89%"></div>
        <div class="spark-bar" style="height:89%"></div><div class="spark-bar" style="height:89%"></div>
      </div>
    </div>
  </div>

  <div class="family-row">
    <div class="family-card fm1">
      <div class="fc-name">Person A</div>
      <div class="fc-metrics">
        <div class="fc-metric"><div class="fc-metric-val">82%</div><div class="fc-metric-label">Mood</div></div>
        <div class="fc-metric"><div class="fc-metric-val">91%</div><div class="fc-metric-label">Engagement</div></div>
        <div class="fc-metric"><div class="fc-metric-val">Low</div><div class="fc-metric-label">Stress</div></div>
        <div class="fc-metric"><div class="fc-metric-val">24</div><div class="fc-metric-label">Interactions</div></div>
      </div>
    </div>
    <div class="family-card fm2">
      <div class="fc-name">Person B</div>
      <div class="fc-metrics">
        <div class="fc-metric"><div class="fc-metric-val">68%</div><div class="fc-metric-label">Mood</div></div>
        <div class="fc-metric"><div class="fc-metric-val">76%</div><div class="fc-metric-label">Engagement</div></div>
        <div class="fc-metric"><div class="fc-metric-val">Med</div><div class="fc-metric-label">Stress</div></div>
        <div class="fc-metric"><div class="fc-metric-val">18</div><div class="fc-metric-label">Interactions</div></div>
      </div>
    </div>
    <div class="family-card fm3">
      <div class="fc-name">Person C</div>
      <div class="fc-metrics">
        <div class="fc-metric"><div class="fc-metric-val">75%</div><div class="fc-metric-label">Mood</div></div>
        <div class="fc-metric"><div class="fc-metric-val">88%</div><div class="fc-metric-label">Engagement</div></div>
        <div class="fc-metric"><div class="fc-metric-val">Low</div><div class="fc-metric-label">Stress</div></div>
        <div class="fc-metric"><div class="fc-metric-val">21</div><div class="fc-metric-label">Interactions</div></div>
      </div>
    </div>
  </div>

  <div class="alerts">
    <div class="alerts-title">Recent Alerts</div>
    <div class="alert-item"><div class="alert-dot green"></div><div class="alert-text">Harmonization: De-escalation suggestion accepted by Person B — conversation redirected successfully</div><div class="alert-time">2h ago</div></div>
    <div class="alert-item"><div class="alert-dot yellow"></div><div class="alert-text">Sensing: Person B showing elevated stress indicators — monitoring closely</div><div class="alert-time">4h ago</div></div>
    <div class="alert-item"><div class="alert-dot green"></div><div class="alert-text">Manipulation: External misinformation detected in shared link — context enriched with counter-narrative</div><div class="alert-time">6h ago</div></div>
    <div class="alert-item"><div class="alert-dot green"></div><div class="alert-text">Memory: Weekly reflection completed — 3 new episodic memories stored</div><div class="alert-time">1d ago</div></div>
  </div>

  <div class="status-bar">
    <div class="status-text">System Status: EQUILIBRIUM MAINTAINED</div>
    <div class="status-detail">Last intervention: 2h ago | Next audit: 22h | Active agents: 10/10</div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/08-dashboard.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 8 done');
})();
