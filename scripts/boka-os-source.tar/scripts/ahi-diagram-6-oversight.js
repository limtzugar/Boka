// Diagram 6: Human Oversight Loop
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1200px; padding: 50px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 36px; }

  .loop-container { display: flex; gap: 24px; }

  .loop-visual { flex: 1; position: relative; height: 680px; }
  .loop-center {
    position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
    width: 180px; height: 180px; border-radius: 50%;
    background: rgba(214,183,93,0.08); border: 2px solid rgba(214,183,93,0.3);
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    text-align: center;
  }
  .loop-center-title { font-size: 16px; font-weight: 800; color: #d6b75d; margin-bottom: 4px; }
  .loop-center-sub { font-size: 10px; color: #97948e; }

  .loop-node {
    position: absolute; width: 160px; padding: 14px; border-radius: 10px;
    background: #161614; border: 1px solid #4b4636; text-align: center;
  }
  .ln-num { font-size: 20px; font-weight: 800; color: #d6b75d; margin-bottom: 4px; }
  .ln-title { font-size: 13px; font-weight: 700; margin-bottom: 4px; }
  .ln-desc { font-size: 10px; color: #97948e; line-height: 1.4; }

  .n1 { top: 20px; left: 50%; transform: translateX(-50%); }
  .n1 .ln-title { color: #b69e6f; }
  .n2 { top: 140px; right: 60px; }
  .n2 .ln-title { color: #8672c3; }
  .n3 { bottom: 140px; right: 60px; }
  .n3 .ln-title { color: #7b96b1; }
  .n4 { bottom: 20px; left: 50%; transform: translateX(-50%); }
  .n4 .ln-title { color: #75b189; }
  .n5 { bottom: 140px; left: 60px; }
  .n5 .ln-title { color: #c7ba93; }
  .n6 { top: 140px; left: 60px; }
  .n6 .ln-title { color: #be766f; }

  /* Arrow SVG overlay */
  .arrows-svg {
    position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none;
  }

  /* Right panel */
  .roles-panel { width: 320px; display: flex; flex-direction: column; gap: 12px; }
  .role-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .role-title { font-size: 13px; font-weight: 700; color: #d6b75d; margin-bottom: 6px; }
  .role-items { font-size: 11px; color: #97948e; line-height: 1.7; }
  .role-highlight { color: #d6b75d; font-weight: 600; }

  .principle-box {
    padding: 16px; border-radius: 8px; background: rgba(214,183,93,0.06);
    border: 1px solid rgba(214,183,93,0.2); margin-top: 8px;
  }
  .principle-text { font-size: 12px; color: #d6b75d; line-height: 1.7; text-align: center; }
</style></head><body>
  <div class="title">Human Oversight Loop</div>
  <div class="subtitle">The continuous cycle ensuring humans remain in control of AHI at all times</div>

  <div class="loop-container">
    <div class="loop-visual">
      <svg class="arrows-svg" viewBox="0 0 820 680">
        <!-- Circular flow arrows -->
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="#4b4636"/>
          </marker>
        </defs>
        <!-- N1 to N2 -->
        <path d="M 470 100 Q 560 100 590 170" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
        <!-- N2 to N3 -->
        <path d="M 680 280 Q 700 400 680 480" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
        <!-- N3 to N4 -->
        <path d="M 590 560 Q 560 620 470 640" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
        <!-- N4 to N5 -->
        <path d="M 350 640 Q 260 620 230 560" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
        <!-- N5 to N6 -->
        <path d="M 140 480 Q 120 400 140 280" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
        <!-- N6 to N1 -->
        <path d="M 230 170 Q 260 100 350 80" stroke="#4b4636" stroke-width="2" fill="none" marker-end="url(#arrowhead)"/>
      </svg>

      <div class="loop-center">
        <div class="loop-center-title">AHI</div>
        <div class="loop-center-sub">Equilibrium<br/>System</div>
      </div>

      <div class="loop-node n1">
        <div class="ln-num">1</div>
        <div class="ln-title">Define Values</div>
        <div class="ln-desc">Family sets core principles and boundaries</div>
      </div>
      <div class="loop-node n2">
        <div class="ln-num">2</div>
        <div class="ln-title">Observe & Detect</div>
        <div class="ln-desc">AHI monitors and surfaces patterns</div>
      </div>
      <div class="loop-node n3">
        <div class="ln-num">3</div>
        <div class="ln-title">Propose & Explain</div>
        <div class="ln-desc">AHI suggests with full reasoning</div>
      </div>
      <div class="loop-node n4">
        <div class="ln-num">4</div>
        <div class="ln-title">Human Decide</div>
        <div class="ln-desc">Family approves, modifies, or vetoes</div>
      </div>
      <div class="loop-node n5">
        <div class="ln-num">5</div>
        <div class="ln-title">Execute & Log</div>
        <div class="ln-desc">Action taken with immutable audit trail</div>
      </div>
      <div class="loop-node n6">
        <div class="ln-num">6</div>
        <div class="ln-title">Review & Tune</div>
        <div class="ln-desc">Audit results and adjust thresholds</div>
      </div>
    </div>

    <div class="roles-panel">
      <div class="role-card">
        <div class="role-title">Family Member Roles</div>
        <div class="role-items">
          <span class="role-highlight">Value Architect</span> — Defines what matters most<br/>
          <span class="role-highlight">Intervention Approver</span> — Green-lights or blocks actions<br/>
          <span class="role-highlight">Behavior Auditor</span> — Reviews AI decisions weekly<br/>
          <span class="role-highlight">Boundary Keeper</span> — Sets ethical red lines<br/>
          <span class="role-highlight">Threshold Tuner</span> — Adjusts sensitivity levels
        </div>
      </div>

      <div class="role-card">
        <div class="role-title">Oversight Mechanisms</div>
        <div class="role-items">
          <span class="role-highlight">Real-time Dashboard</span> — See all AI activity live<br/>
          <span class="role-highlight">Instant Veto Button</span> — One-tap action cancellation<br/>
          <span class="role-highlight">Weekly Audit Report</span> — Detailed behavior review<br/>
          <span class="role-highlight">Policy Editor</span> — Modify rules and constraints<br/>
          <span class="role-highlight">Consensus Voting</span> — Family decides together
        </div>
      </div>

      <div class="role-card">
        <div class="role-title">Emergency Controls</div>
        <div class="role-items">
          <span class="role-highlight">Kill Switch</span> — Immediately halt all AI activity<br/>
          <span class="role-highlight">Rollback</span> — Undo last N interventions<br/>
          <span class="role-highlight">Safe Mode</span> — Reduce to observation-only<br/>
          <span class="role-highlight">Data Export</span> — Download all personal data<br/>
          <span class="role-highlight">Data Delete</span> — Remove all stored memories
        </div>
      </div>

      <div class="principle-box">
        <div class="principle-text">
          Humans are not supervisors —<br/>they are participants.<br/><br/>
          AHI serves the family,<br/>not the other way around.
        </div>
      </div>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/ahi-diagrams/06-human-oversight.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 6 done');
})();
