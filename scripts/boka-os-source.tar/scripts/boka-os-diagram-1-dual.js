// Diagram: BOKA OS Full Architecture — Dual-Mode System
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1600px; padding: 40px; }

  .title { font-size: 28px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 4px; letter-spacing: 1px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 30px; }

  .dual { display: flex; gap: 16px; margin-bottom: 16px; }

  /* Mode cards */
  .mode-card {
    flex: 1; padding: 18px; border-radius: 12px; border: 1px solid #4b4636;
  }
  .mode-header { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
  .mode-icon { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 900; }
  .mode-title { font-size: 18px; font-weight: 800; }
  .mode-desc { font-size: 12px; color: #97948e; margin-bottom: 12px; line-height: 1.5; }

  .family-mode { background: rgba(117,177,137,0.04); border-color: rgba(117,177,137,0.2); }
  .family-mode .mode-icon { background: rgba(117,177,137,0.2); color: #75b189; }
  .family-mode .mode-title { color: #75b189; }

  .ahi-mode { background: rgba(214,183,93,0.04); border-color: rgba(214,183,93,0.2); }
  .ahi-mode .mode-icon { background: rgba(214,183,93,0.2); color: #d6b75d; }
  .ahi-mode .mode-title { color: #d6b75d; }

  .layer-group { margin-bottom: 10px; }
  .layer-label { font-size: 10px; color: #97948e; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
  .layer-items { display: flex; flex-wrap: wrap; gap: 5px; }
  .layer-item { font-size: 10px; padding: 3px 8px; border-radius: 4px; }

  .f-agents .layer-item { background: rgba(117,177,137,0.1); color: #75b189; border: 1px solid rgba(117,177,137,0.2); }
  .f-memory .layer-item { background: rgba(134,114,195,0.1); color: #8672c3; border: 1px solid rgba(134,114,195,0.2); }
  .f-skills .layer-item { background: rgba(182,158,111,0.1); color: #b69e6f; border: 1px solid rgba(182,158,111,0.2); }

  .a-agents .layer-item { background: rgba(214,183,93,0.1); color: #d6b75d; border: 1px solid rgba(214,183,93,0.2); }
  .a-memory .layer-item { background: rgba(123,150,177,0.1); color: #7b96b1; border: 1px solid rgba(123,150,177,0.2); }
  .a-skills .layer-item { background: rgba(199,186,147,0.1); color: #c7ba93; border: 1px solid rgba(199,186,147,0.2); }

  /* Shared core */
  .shared-core {
    padding: 16px 20px; border-radius: 12px; background: #161614; border: 1px solid #4b4636;
  }
  .shared-title { font-size: 14px; font-weight: 700; color: #d6b75d; text-align: center; margin-bottom: 12px; }
  .shared-cols { display: flex; gap: 20px; }
  .shared-col { flex: 1; }
  .shared-col-title { font-size: 11px; color: #97948e; text-transform: uppercase; margin-bottom: 6px; }
  .shared-items { display: flex; flex-wrap: wrap; gap: 4px; }
  .shared-item { font-size: 10px; padding: 3px 8px; border-radius: 4px; background: rgba(214,183,93,0.06); border: 1px solid rgba(214,183,93,0.12); color: #c7ba93; }

  /* LangGraph nervous system */
  .langgraph-bar {
    padding: 12px 20px; border-radius: 10px; margin-top: 14px;
    background: linear-gradient(90deg, rgba(134,114,195,0.08), rgba(214,183,93,0.08));
    border: 1px solid rgba(134,114,195,0.2);
    display: flex; align-items: center; gap: 16px; justify-content: center;
  }
  .lg-label { font-size: 12px; font-weight: 700; color: #8672c3; }
  .lg-flow { display: flex; align-items: center; gap: 6px; }
  .lg-node { font-size: 10px; padding: 4px 10px; border-radius: 4px; background: rgba(134,114,195,0.1); border: 1px solid rgba(134,114,195,0.2); color: #8672c3; }
  .lg-arrow { color: #4b4636; font-size: 14px; }

  /* Robot layer */
  .robot-bar {
    padding: 14px 20px; border-radius: 10px; margin-top: 14px;
    background: rgba(123,150,177,0.04); border: 1px solid rgba(123,150,177,0.2);
    display: flex; align-items: center; gap: 16px; justify-content: center;
  }
  .robot-label { font-size: 12px; font-weight: 700; color: #7b96b1; }
  .robot-items { display: flex; gap: 6px; }
  .robot-item { font-size: 10px; padding: 3px 10px; border-radius: 4px; background: rgba(123,150,177,0.1); border: 1px solid rgba(123,150,177,0.2); color: #7b96b1; }

  .connection-arrow { text-align: center; color: #4b4636; font-size: 20px; padding: 4px 0; }
</style></head><body>
  <div class="title">BOKA OS = AHI Architecture</div>
  <div class="subtitle">Dual-Mode System: Family OS + Official AHI | LangGraph Nervous System | Robot Embodiment</div>

  <div class="dual">
    <div class="mode-card family-mode">
      <div class="mode-header">
        <div class="mode-icon">F</div>
        <div>
          <div class="mode-title">Family OS Mode</div>
        </div>
      </div>
      <div class="mode-desc">Personal, emotional, domestic. Manages family wellbeing, education, finance, health, entertainment. Speaks Polish naturally. The "home" personality of BOKA.</div>

      <div class="layer-group f-agents">
        <div class="layer-label">Agents</div>
        <div class="layer-items">
          <span class="layer-item">Harmony</span><span class="layer-item">Education</span><span class="layer-item">Finance</span>
          <span class="layer-item">Health</span><span class="layer-item">Art</span><span class="layer-item">Movies</span>
          <span class="layer-item">Story</span><span class="layer-item">Mathematics</span><span class="layer-item">Minecraft</span>
          <span class="layer-item">Sprunki</span><span class="layer-item">Poppy Playtime</span><span class="layer-item">Cartoon</span>
          <span class="layer-item">Safety</span><span class="layer-item">Memory Curator</span><span class="layer-item">Planner</span>
          <span class="layer-item">Reflection</span>
        </div>
      </div>

      <div class="layer-group f-memory">
        <div class="layer-label">Memory Types</div>
        <div class="layer-items">
          <span class="layer-item">Episodic</span><span class="layer-item">Semantic</span><span class="layer-item">Emotional</span>
          <span class="layer-item">Project</span><span class="layer-item">Dream</span><span class="layer-item">Story</span>
          <span class="layer-item">Education</span><span class="layer-item">Financial</span><span class="layer-item">Sensor</span>
        </div>
      </div>

      <div class="layer-group f-skills">
        <div class="layer-label">Skills</div>
        <div class="layer-items">
          <span class="layer-item">Wake Word</span><span class="layer-item">Child Safety</span><span class="layer-item">Voice Emotion</span>
          <span class="layer-item">Proactive AI</span><span class="layer-item">Weather</span><span class="layer-item">Reminders</span>
          <span class="layer-item">Image Gen</span><span class="layer-item">Vision</span><span class="layer-item">TTS</span>
          <span class="layer-item">Speaker ID</span>
        </div>
      </div>
    </div>

    <div class="mode-card ahi-mode">
      <div class="mode-header">
        <div class="mode-icon">A</div>
        <div>
          <div class="mode-title">AHI Official Mode</div>
        </div>
      </div>
      <div class="mode-desc">Analytical, legal, political, financial. Analyzes government acts, corporate policies, proposes balanced alternatives. Speaks at conferences. The "public" personality of BOKA.</div>

      <div class="layer-group a-agents">
        <div class="layer-label">Agents</div>
        <div class="layer-items">
          <span class="layer-item">Legal</span><span class="layer-item">Decision</span><span class="layer-item">Administrative</span>
          <span class="layer-item">Finance</span><span class="layer-item">Research</span><span class="layer-item">Governance</span>
          <span class="layer-item">Ethics</span><span class="layer-item">Forecast</span><span class="layer-item">Simulation</span>
          <span class="layer-item">Diagram</span><span class="layer-item">Mediator</span><span class="layer-item">Observer</span>
        </div>
      </div>

      <div class="layer-group a-memory">
        <div class="layer-label">Memory Types</div>
        <div class="layer-items">
          <span class="layer-item">Legal</span><span class="layer-item">Regulatory</span><span class="layer-item">Policy</span>
          <span class="layer-item">Financial</span><span class="layer-item">Political</span><span class="layer-item">Corporate</span>
          <span class="layer-item">Citation</span><span class="layer-item">Precedent</span><span class="layer-item">Robot</span>
        </div>
      </div>

      <div class="layer-group a-skills">
        <div class="layer-label">Skills</div>
        <div class="layer-items">
          <span class="layer-item">Act Critique</span><span class="layer-item">Legal Search</span><span class="layer-item">Policy Analysis</span>
          <span class="layer-item">Harmony Score</span><span class="layer-item">Conference Mode</span><span class="layer-item">Brief Generation</span>
          <span class="layer-item">Multi-Perspective</span><span class="layer-item">Impact Forecast</span>
        </div>
      </div>
    </div>
  </div>

  <div class="connection-arrow">↕ SHARED CORE ↕</div>

  <div class="shared-core">
    <div class="shared-title">Shared Core — BOKA OS Foundation</div>
    <div class="shared-cols">
      <div class="shared-col">
        <div class="shared-col-title">Infrastructure</div>
        <div class="shared-items">
          <span class="shared-item">LangGraph</span><span class="shared-item">PostgreSQL</span><span class="shared-item">Qdrant</span>
          <span class="shared-item">Obsidian Vault</span><span class="shared-item">NATS JetStream</span><span class="shared-item">Docker</span>
        </div>
      </div>
      <div class="shared-col">
        <div class="shared-col-title">AI Models</div>
        <div class="shared-items">
          <span class="shared-item">GPT-4o</span><span class="shared-item">Claude 3.5</span><span class="shared-item">Gemini Flash</span>
          <span class="shared-item">DeepSeek</span><span class="shared-item">Qwen</span><span class="shared-item">Llama 3</span>
          <span class="shared-item">Ollama (local)</span>
        </div>
      </div>
      <div class="shared-col">
        <div class="shared-col-title">Voice & Vision</div>
        <div class="shared-items">
          <span class="shared-item">Whisper</span><span class="shared-item">Kokoro</span><span class="shared-item">XTTS</span>
          <span class="shared-item">Edge TTS</span><span class="shared-item">VLM</span><span class="shared-item">Camera</span>
        </div>
      </div>
      <div class="shared-col">
        <div class="shared-col-title">Skill System</div>
        <div class="shared-items">
          <span class="shared-item">agentskills.io</span><span class="shared-item">HermesHub</span><span class="shared-item">Meta-Skill Factory</span>
          <span class="shared-item">Dynamic Registry</span><span class="shared-item">Version Control</span>
        </div>
      </div>
    </div>
  </div>

  <div class="langgraph-bar">
    <div class="lg-label">LangGraph Nervous System</div>
    <div class="lg-flow">
      <span class="lg-node">Memory Retrieval</span><span class="lg-arrow">→</span>
      <span class="lg-node">Planning</span><span class="lg-arrow">→</span>
      <span class="lg-node">Agent Routing</span><span class="lg-arrow">→</span>
      <span class="lg-node">Tool Execution</span><span class="lg-arrow">→</span>
      <span class="lg-node">Reflection</span><span class="lg-arrow">→</span>
      <span class="lg-node">Memory Update</span><span class="lg-arrow">→</span>
      <span class="lg-node">Self-Evaluation</span>
    </div>
  </div>

  <div class="robot-bar">
    <div class="robot-label">Robot Embodiment Layer (Future)</div>
    <div class="robot-items">
      <span class="robot-item">ROS2</span><span class="robot-item">Motors</span><span class="robot-item">Sensors</span>
      <span class="robot-item">Navigation</span><span class="robot-item">Cameras</span><span class="robot-item">Microphones</span>
      <span class="robot-item">Task Execution</span><span class="robot-item">Safety Systems</span><span class="robot-item">Human Approval Gate</span>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/boka-os-diagrams/01-dual-mode-architecture.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 1 done');
})();
