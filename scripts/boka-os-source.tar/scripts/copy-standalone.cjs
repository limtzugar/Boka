// ═══════════════════════════════════════════════════════════
// BOKA OS — Copy static files to standalone build
// Cross-platform (Windows/Linux/Mac) replacement for:
//   cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/
// ═══════════════════════════════════════════════════════════

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const NEXT_DIR = path.join(ROOT, '.next');
const STANDALONE_DIR = path.join(NEXT_DIR, 'standalone');

console.log('📋 Kopiuję pliki statyczne do standalone build...');

// ── 1. .next/static → .next/standalone/.next/static ──
const staticSrc = path.join(NEXT_DIR, 'static');
const staticDst = path.join(STANDALONE_DIR, '.next', 'static');

if (fs.existsSync(staticSrc)) {
  fs.rmSync(staticDst, { recursive: true, force: true });
  fs.cpSync(staticSrc, staticDst, { recursive: true });
  console.log(`  ✓ .next/static → standalone/.next/static`);
} else {
  console.warn('  ⚠ .next/static nie istnieje — build mógł się nie udać?');
}

// ── 2. public → .next/standalone/public ──
const publicSrc = path.join(ROOT, 'public');
const publicDst = path.join(STANDALONE_DIR, 'public');

if (fs.existsSync(publicSrc)) {
  fs.rmSync(publicDst, { recursive: true, force: true });
  fs.cpSync(publicSrc, publicDst, { recursive: true });
  console.log(`  ✓ public → standalone/public`);
} else {
  console.warn('  ⚠ public/ nie istnieje — pomijam');
}

// ── 3. .env → .next/standalone/.env (jeśli istnieje) ──
const envSrc = path.join(ROOT, '.env');
const envDst = path.join(STANDALONE_DIR, '.env');
if (fs.existsSync(envSrc) && !fs.existsSync(envDst)) {
  fs.copyFileSync(envSrc, envDst);
  console.log(`  ✓ .env → standalone/.env`);
}

console.log('✅ Pliki statyczne gotowe');
