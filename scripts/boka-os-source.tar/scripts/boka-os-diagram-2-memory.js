// Diagram: Memory System Architecture — 13 Memory Types
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const html = `<!DOCTYPE html>
<html><head><style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0b0b0a; color: #e3e3e1; font-family: 'Inter', 'Noto Sans SC', sans-serif; width: 1400px; padding: 40px; }

  .title { font-size: 26px; font-weight: 800; color: #d6b75d; text-align: center; margin-bottom: 4px; }
  .subtitle { font-size: 13px; color: #97948e; text-align: center; margin-bottom: 30px; }

  .memory-map { display: flex; gap: 20px; }

  /* Memory types grid */
  .mem-types { flex: 1; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
  .mem-card {
    padding: 12px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .mem-icon { font-size: 16px; font-weight: 800; margin-bottom: 4px; }
  .mem-name { font-size: 12px; font-weight: 700; margin-bottom: 3px; }
  .mem-desc { font-size: 10px; color: #97948e; line-height: 1.4; }
  .mem-schema { font-size: 9px; color: #4b4636; margin-top: 4px; font-family: monospace; }

  .m-episodic .mem-icon { color: #75b189; } .m-episodic .mem-name { color: #75b189; }
  .m-semantic .mem-icon { color: #7b96b1; } .m-semantic .mem-name { color: #7b96b1; }
  .m-emotional .mem-icon { color: #be766f; } .m-emotional .mem-name { color: #be766f; }
  .m-project .mem-icon { color: #8672c3; } .m-project .mem-name { color: #8672c3; }
  .m-legal .mem-icon { color: #d6b75d; } .m-legal .mem-name { color: #d6b75d; }
  .m-education .mem-icon { color: #75b189; } .m-education .mem-name { color: #75b189; }
  .m-financial .mem-icon { color: #b69e6f; } .m-financial .mem-name { color: #b69e6f; }
  .m-dream .mem-icon { color: #8672c3; } .m-dream .mem-name { color: #8672c3; }
  .m-story .mem-icon { color: #c7ba93; } .m-story .mem-name { color: #c7ba93; }
  .m-robot .mem-icon { color: #7b96b1; } .m-robot .mem-name { color: #7b96b1; }
  .m-sensor .mem-icon { color: #b69e6f; } .m-sensor .mem-name { color: #b69e6f; }

  /* Storage panel */
  .storage-panel { width: 320px; display: flex; flex-direction: column; gap: 10px; }
  .store-card {
    padding: 14px; border-radius: 8px; background: #161614; border: 1px solid #4b4636;
  }
  .store-title { font-size: 13px; font-weight: 700; margin-bottom: 6px; }
  .store-body { font-size: 11px; color: #97948e; line-height: 1.6; }
  .store-schema { font-size: 10px; color: #4b4636; margin-top: 6px; font-family: monospace; line-height: 1.5; }

  .s-postgres .store-title { color: #7b96b1; }
  .s-qdrant .store-title { color: #8672c3; }
  .s-obsidian .store-title { color: #b69e6f; }
  .s-sqlite .store-title { color: #75b189; }

  /* Universal memory fields */
  .universal-fields {
    margin-top: 16px; padding: 14px; border-radius: 8px;
    background: rgba(214,183,93,0.04); border: 1px solid rgba(214,183,93,0.15);
  }
  .uf-title { font-size: 13px; font-weight: 700; color: #d6b75d; margin-bottom: 8px; text-align: center; }
  .uf-fields { display: flex; flex-wrap: wrap; gap: 4px; justify-content: center; }
  .uf-field { font-size: 10px; padding: 3px 8px; border-radius: 3px; background: rgba(214,183,93,0.08); border: 1px solid rgba(214,183,93,0.15); color: #d6b75d; }
</style></head><body>
  <div class="title">Memory System Architecture</div>
  <div class="subtitle">13 Memory Types × 4 Storage Backends × Universal Fields</div>

  <div class="memory-map">
    <div class="mem-types">
      <div class="mem-card m-episodic"><div class="mem-icon">E</div><div class="mem-name">Episodic Memory</div><div class="mem-desc">Specific events: arguments, celebrations, shared moments</div><div class="mem-schema">who, what, when, where, emotion, outcome</div></div>
      <div class="mem-card m-semantic"><div class="mem-icon">S</div><div class="mem-name">Semantic Memory</div><div class="mem-desc">General knowledge: values, preferences, styles, triggers</div><div class="mem-schema">concept, definition, relations, confidence</div></div>
      <div class="mem-card m-emotional"><div class="mem-icon">H</div><div class="mem-name">Emotional Memory</div><div class="mem-desc">Emotional patterns, mood trajectories, triggers, calming strategies</div><div class="mem-schema">emotion, intensity, trigger, context, valence</div></div>
      <div class="mem-card m-project"><div class="mem-icon">P</div><div class="mem-name">Project Memory</div><div class="mem-desc">Ongoing projects: tasks, deadlines, progress, dependencies</div><div class="mem-schema">project, status, tasks, milestones, blockers</div></div>
      <div class="mem-card m-legal"><div class="mem-icon">L</div><div class="mem-name">Legal Memory</div><div class="mem-desc">Acts, regulations, critiques, precedents, compliance status</div><div class="mem-schema">act_id, title, critique, impact, harmony_score</div></div>
      <div class="mem-card m-education"><div class="mem-icon">D</div><div class="mem-name">Education Memory</div><div class="mem-desc">Learning sessions, progress, strengths, weaknesses, curriculum</div><div class="mem-schema">subject, topic, score, difficulty, next_step</div></div>
      <div class="mem-card m-financial"><div class="mem-icon">F</div><div class="mem-name">Financial Memory</div><div class="mem-desc">Expenses, budgets, trends, goals, warnings, predictions</div><div class="mem-schema">amount, category, trend, budget_status, forecast</div></div>
      <div class="mem-card m-dream"><div class="mem-icon">R</div><div class="mem-name">Dream Memory</div><div class="mem-desc">Dreams recounted by family, symbols, patterns, emotional residue</div><div class="mem-schema">narrative, symbols, emotion, date, dreamer</div></div>
      <div class="mem-card m-story"><div class="mem-icon">T</div><div class="mem-name">Story Memory</div><div class="mem-desc">Family stories, lore, traditions, inside jokes, oral history</div><div class="mem-schema">story, teller, era, tags, moral, retell_count</div></div>
      <div class="mem-card m-robot"><div class="mem-icon">B</div><div class="mem-name">Robot Memory</div><div class="mem-desc">Robot tasks, environment map, interaction logs, safety events</div><div class="mem-schema">task, location, result, safety_flag, approval</div></div>
      <div class="mem-card m-sensor"><div class="mem-icon">N</div><div class="mem-name">Sensor Memory</div><div class="mem-desc">IoT data, environmental signals, noise levels, air quality</div><div class="mem-schema">sensor_type, value, threshold, alert, location</div></div>
    </div>

    <div class="storage-panel">
      <div class="store-card s-postgres">
        <div class="store-title">PostgreSQL — Primary Store</div>
        <div class="store-body">Relational data, ACID transactions, complex queries. Replaces SQLite for production scale.</div>
        <div class="store-schema">memories, conversations, messages, family, expenses, budgets, legal_acts, robot_logs, audit_trail</div>
      </div>
      <div class="store-card s-qdrant">
        <div class="store-title">Qdrant — Vector Store</div>
        <div class="store-body">Embeddings, semantic search, similarity retrieval. Powers memory recall and Obsidian graph.</div>
        <div class="store-schema">payload: { content, type, domain, tags[], importance, member_id, embedding_ref, timestamp }</div>
      </div>
      <div class="store-card s-obsidian">
        <div class="store-title">Obsidian Vault — Human-Readable</div>
        <div class="store-body">Markdown files, backlinks, tags. Human-editable memory that syncs with the system.</div>
        <div class="store-schema">Daily notes, person notes, topic notes, project notes, legal notes — with [[wiki-links]]</div>
      </div>
      <div class="store-card s-sqlite">
        <div class="store-title">SQLite — Legacy/Local</div>
        <div class="store-body">Current Prisma DB. Preserved for backward compat. Migration path to PostgreSQL.</div>
        <div class="store-schema">Existing 10 models preserved, new models added incrementally</div>
      </div>
    </div>
  </div>

  <div class="universal-fields">
    <div class="uf-title">Universal Memory Fields — Every Memory Entry Must Contain</div>
    <div class="uf-fields">
      <span class="uf-field">timestamp</span><span class="uf-field">importance (0-1)</span><span class="uf-field">linked_profiles[]</span>
      <span class="uf-field">tags[]</span><span class="uf-field">source</span><span class="uf-field">summary</span>
      <span class="uf-field">embedding_ref</span><span class="uf-field">memory_type</span><span class="uf-field">domain</span>
      <span class="uf-field">emotional_valence</span><span class="uf-field">valid_from</span><span class="uf-field">valid_until</span>
    </div>
  </div>
</body></html>`;

  await page.setContent(html, { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/home/z/my-project/download/boka-os-diagrams/02-memory-system.png', deviceScaleFactor: 2 });
  await browser.close();
  console.log('Diagram 2 done');
})();
