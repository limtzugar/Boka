#!/bin/bash
# Rebuild boka-os-source.tar.gz — source only (no node_modules, no .next)
# This is what gets embedded in the .exe installer

set -e

cd /home/z/my-project

# Files/dirs to include
INCLUDE=(
  "src/"
  "public/"
  "prisma/"
  "scripts/"
  "package.json"
  "package-lock.json"
  "tsconfig.json"
  "next.config.ts"
  "next.config.js"
  "postcss.config.mjs"
  "tailwind.config.ts"
  "components.json"
  ".env.example"
)

# Files to exclude
EXCLUDE=(
  "node_modules"
  ".next"
  ".git"
  "download"
  "worklog.md"
  "agent-ctx"
  "*.log"
  ".DS_Store"
)

# Build exclude args
EXCLUDE_ARGS=""
for ex in "${EXCLUDE[@]}"; do
  EXCLUDE_ARGS="$EXCLUDE_ARGS --exclude=$ex"
done

# Create tarball with just the source
OUTPUT="/home/z/my-project/download/boka-os-source.tar.gz"
rm -f "$OUTPUT"

# Use tar with explicit include + excludes
tar czf "$OUTPUT" \
  --exclude=node_modules \
  --exclude=.next \
  --exclude=.git \
  --exclude=download \
  --exclude=worklog.md \
  --exclude=agent-ctx \
  --exclude='*.log' \
  --exclude=.DS_Store \
  --exclude=skills \
  --exclude=examples \
  --exclude=.zscripts \
  --exclude=electron \
  --exclude=boka-memory \
  src/ public/ prisma/ scripts/ package.json package-lock.json tsconfig.json next.config.ts next.config.js postcss.config.mjs tailwind.config.ts components.json .env.example 2>/dev/null || true

ls -lh "$OUTPUT"
echo "---"
echo "File count in archive:"
tar tzf "$OUTPUT" | wc -l
echo "---"
echo "Sample top-level entries:"
tar tzf "$OUTPUT" | head -20
