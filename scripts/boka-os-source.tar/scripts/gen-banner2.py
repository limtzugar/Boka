#!/usr/bin/env python3
"""Generate simpler banner — just 'BOKA' in large ASCII art."""

WIDTH = 62

def pad(line):
    inner = WIDTH - 2
    if len(line) > inner:
        line = line[:inner]
    return "|" + line.ljust(inner) + "|"

def hr():
    return "+" + "=" * (WIDTH - 2) + "+"

def empty():
    return "|" + " " * (WIDTH - 2) + "|"

# BOKA only — large figlet (5 lines)
boka = [
    "  ____  ___  ____ ___ ",
    " | __ )/ _ \\| __/ __|_ _|  ",
    " |  _ \\| | | | _| (_ || |  ",
    " | |_) | |_| |__\\___||___| ",
    " |____/ \\___/|_|            ",
]

# Simple roof (4 lines)
roof = [
    "                       /\\                                   ",
    "                      /  \\                                  ",
    "                     /____\\                                 ",
]

# --- Opening banner ---
lines_a = [""]
lines_a.append(hr())
lines_a.append(empty())
for h in roof:
    lines_a.append(pad(h))
lines_a.append(empty())
for b in boka:
    lines_a.append(pad(b))
lines_a.append(empty())
lines_a.append(pad("                   Rodzinny System AI                       "))
lines_a.append(pad("                        v0.2.0                              "))
lines_a.append(empty())
lines_a.append(hr())
lines_a.append("")

# --- Success banner with OK in the house ---
house_ok = [
    "                       /\\                                   ",
    "                      /  \\                                  ",
    "                     /____\\                                 ",
    "                    |    |                                  ",
    "                    | OK |                                  ",
    "                    |____|                                  ",
]
lines_b = [""]
lines_b.append(hr())
lines_b.append(empty())
for h in house_ok:
    lines_b.append(pad(h))
lines_b.append(empty())
for b in boka:
    lines_b.append(pad(b))
lines_b.append(empty())
lines_b.append(pad("             BOKA OS ZAINSTALOWANA POMYŚLNIE!               "))
lines_b.append(empty())
lines_b.append(hr())
lines_b.append("")

print("=== OPENING ===")
print("\n".join(lines_a))
print("\n=== SUCCESS ===")
print("\n".join(lines_b))

# Verify widths
for name, lines in [("opening", lines_a), ("success", lines_b)]:
    for i, l in enumerate(lines):
        if l and len(l) != WIDTH:
            print(f"⚠ {name} line {i}: {len(l)} chars — '{l}'")
            break
    else:
        print(f"✓ {name} aligned")

with open("/home/z/my-project/scripts/banner-preview2.txt", "w") as f:
    f.write("=== OPENING ===\n")
    f.write("\n".join(lines_a))
    f.write("\n\n=== SUCCESS ===\n")
    f.write("\n".join(lines_b))
