"""
Generate a multi-resolution .ico for the BOKA Setup.exe installer
from the existing /home/z/my-project/public/boka-icon-512.png asset.

Multi-resolution ICO covers:
  - 16x16   (small list views / taskbar corner)
  - 32x32   (default Alt-Tab / desktop icon on small DPI)
  - 48x48   (Windows Explorer default large icon)
  - 64x64   (extra detail)
  - 128x128 (high-DPI Explorer)
  - 256x256 (Vista+ max size, used in file properties)

Lanczos resampling gives clean edges on the small sizes.
"""
from PIL import Image
import os

SRC = '/home/z/my-project/public/boka-icon-512.png'
DST_DIR = '/home/z/gopath/src/boka-installer'
DST_ICO = os.path.join(DST_DIR, 'boka.ico')

# Load at 512 (largest embedded in ICO)
src = Image.open(SRC).convert('RGBA')

# Build the ICO with multiple sizes
sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
src.save(DST_ICO, format='ICO', sizes=sizes)

# Verify by reopening
ico = Image.open(DST_ICO)
print(f"ICO saved: {DST_ICO}")
print(f"ICO file size: {os.path.getsize(DST_ICO)} bytes")
print(f"ICO sizes available: {ico.info.get('sizes', 'n/a')}")
